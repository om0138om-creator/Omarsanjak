"""
======================================
✅ Validators
======================================
دوال التحقق من صحة البيانات
"""

import re
from typing import Tuple, Optional
import phonenumbers
from email_validator import validate_email as email_validator, EmailNotValidError


def validate_email(email: str) -> Tuple[bool, Optional[str]]:
    """
    التحقق من صحة البريد الإلكتروني
    
    Returns:
        Tuple[is_valid, error_message]
    """
    if not email:
        return False, 'البريد الإلكتروني مطلوب'
    
    try:
        # التحقق والتطبيع
        valid = email_validator(email, check_deliverability=False)
        return True, None
    except EmailNotValidError as e:
        return False, 'البريد الإلكتروني غير صالح'


def validate_phone(phone: str, country: str = 'DZ') -> Tuple[bool, Optional[str], Optional[str]]:
    """
    التحقق من صحة رقم الهاتف
    
    Returns:
        Tuple[is_valid, error_message, formatted_phone]
    """
    if not phone:
        return False, 'رقم الهاتف مطلوب', None
    
    try:
        # تنظيف الرقم
        phone = re.sub(r'[\s\-\.\(\)]', '', phone)
        
        # إضافة رمز الدولة إذا لزم الأمر
        if not phone.startswith('+'):
            if phone.startswith('00'):
                phone = '+' + phone[2:]
            elif phone.startswith('0'):
                phone = '+213' + phone[1:]
            else:
                phone = '+213' + phone
        
        # التحقق
        parsed = phonenumbers.parse(phone, country)
        
        if not phonenumbers.is_valid_number(parsed):
            return False, 'رقم الهاتف غير صالح', None
        
        # التنسيق
        formatted = phonenumbers.format_number(
            parsed, 
            phonenumbers.PhoneNumberFormat.E164
        )
        
        return True, None, formatted
        
    except phonenumbers.NumberParseException:
        return False, 'رقم الهاتف غير صالح', None


def validate_password_strength(password: str) -> Tuple[bool, Optional[str], int]:
    """
    التحقق من قوة كلمة المرور
    
    Returns:
        Tuple[is_valid, error_message, strength_score]
    """
    if not password:
        return False, 'كلمة المرور مطلوبة', 0
    
    # الحد الأدنى للطول
    if len(password) < 8:
        return False, 'كلمة المرور يجب أن تكون 8 أحرف على الأقل', 0
    
    score = 0
    feedback = []
    
    # الطول
    if len(password) >= 8:
        score += 1
    if len(password) >= 12:
        score += 1
    if len(password) >= 16:
        score += 1
    
    # الأحرف الكبيرة
    if re.search(r'[A-Z]', password):
        score += 1
    else:
        feedback.append('أضف أحرف كبيرة')
    
    # الأحرف الصغيرة
    if re.search(r'[a-z]', password):
        score += 1
    else:
        feedback.append('أضف أحرف صغيرة')
    
    # الأرقام
    if re.search(r'\d', password):
        score += 1
    else:
        feedback.append('أضف أرقام')
    
    # الرموز
    if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        score += 1
    else:
        feedback.append('أضف رموز خاصة')
    
    # التحقق من كلمات المرور الشائعة
    common_passwords = [
        'password', '123456', '12345678', 'qwerty', 'abc123',
        'password123', 'admin', 'letmein', 'welcome'
    ]
    if password.lower() in common_passwords:
        return False, 'كلمة المرور شائعة جداً', 0
    
    # التقييم
    if score < 4:
        return False, 'كلمة المرور ضعيفة: ' + '، '.join(feedback), score
    
    return True, None, score


def validate_name(name: str, field_name: str = 'الاسم') -> Tuple[bool, Optional[str]]:
    """التحقق من صحة الاسم"""
    if not name:
        return False, f'{field_name} مطلوب'
    
    if len(name) < 2:
        return False, f'{field_name} يجب أن يكون حرفين على الأقل'
    
    if len(name) > 50:
        return False, f'{field_name} طويل جداً'
    
    # السماح بالعربية والإنجليزية والمسافات فقط
    if not re.match(r'^[\u0600-\u06FFa-zA-Z\s]+$', name):
        return False, f'{field_name} يحتوي على أحرف غير مسموحة'
    
    return True, None


def validate_address(address: str) -> Tuple[bool, Optional[str]]:
    """التحقق من صحة العنوان"""
    if not address:
        return False, 'العنوان مطلوب'
    
    if len(address) < 10:
        return False, 'العنوان قصير جداً'
    
    if len(address) > 255:
        return False, 'العنوان طويل جداً'
    
    return True, None


def validate_postal_code(code: str, country: str = 'DZ') -> Tuple[bool, Optional[str]]:
    """التحقق من الرمز البريدي"""
    if not code:
        return True, None  # اختياري
    
    # الجزائر: 5 أرقام
    if country == 'DZ':
        if not re.match(r'^\d{5}$', code):
            return False, 'الرمز البريدي يجب أن يكون 5 أرقام'
    
    return True, None


def validate_quantity(quantity: int, min_qty: int = 1, max_qty: int = 100) -> Tuple[bool, Optional[str]]:
    """التحقق من الكمية"""
    if quantity < min_qty:
        return False, f'الحد الأدنى للكمية هو {min_qty}'
    
    if quantity > max_qty:
        return False, f'الحد الأقصى للكمية هو {max_qty}'
    
    return True, None


def validate_price(price: float) -> Tuple[bool, Optional[str]]:
    """التحقق من السعر"""
    if price is None:
        return False, 'السعر مطلوب'
    
    if price < 0:
        return False, 'السعر لا يمكن أن يكون سالباً'
    
    if price > 10000000:  # 10 مليون
        return False, 'السعر مرتفع جداً'
    
    return True, None


def validate_coupon_code(code: str) -> Tuple[bool, Optional[str]]:
    """التحقق من رمز الكوبون"""
    if not code:
        return False, 'رمز الكوبون مطلوب'
    
    if len(code) < 3:
        return False, 'رمز الكوبون قصير جداً'
    
    if len(code) > 50:
        return False, 'رمز الكوبون طويل جداً'
    
    # أحرف وأرقام وشرطات فقط
    if not re.match(r'^[A-Za-z0-9_-]+$', code):
        return False, 'رمز الكوبون يحتوي على أحرف غير مسموحة'
    
    return True, None


def validate_image_file(file, max_size_mb: int = 5) -> Tuple[bool, Optional[str]]:
    """التحقق من ملف الصورة"""
    if not file:
        return False, 'الملف مطلوب'
    
    # التحقق من الامتداد
    allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
    filename = file.filename.lower()
    
    if '.' not in filename:
        return False, 'الملف ليس له امتداد'
    
    ext = filename.rsplit('.', 1)[1]
    if ext not in allowed_extensions:
        return False, f'الامتدادات المسموحة: {", ".join(allowed_extensions)}'
    
    # التحقق من الحجم
    file.seek(0, 2)  # الذهاب لنهاية الملف
    size = file.tell()
    file.seek(0)  # العودة للبداية
    
    max_size = max_size_mb * 1024 * 1024
    if size > max_size:
        return False, f'حجم الملف يتجاوز {max_size_mb}MB'
    
    return True, None