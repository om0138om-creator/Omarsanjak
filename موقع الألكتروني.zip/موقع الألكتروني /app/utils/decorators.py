"""
======================================
🎯 Custom Decorators
======================================
"""

from functools import wraps
from flask import abort, request, jsonify, flash, redirect, url_for
from flask_login import current_user


def admin_required(f):
    """
    Decorator للتحقق من صلاحيات المشرف
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            if request.is_json:
                return jsonify({'success': False, 'message': 'يرجى تسجيل الدخول'}), 401
            flash('يرجى تسجيل الدخول', 'warning')
            return redirect(url_for('auth.login', next=request.url))
        
        if not current_user.is_admin:
            if request.is_json:
                return jsonify({'success': False, 'message': 'غير مصرح لك بالوصول'}), 403
            abort(403)
        
        return f(*args, **kwargs)
    return decorated_function


def verified_required(f):
    """
    Decorator للتحقق من تأكيد البريد الإلكتروني
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            if request.is_json:
                return jsonify({'success': False, 'message': 'يرجى تسجيل الدخول'}), 401
            flash('يرجى تسجيل الدخول', 'warning')
            return redirect(url_for('auth.login', next=request.url))
        
        if not current_user.email_verified:
            if request.is_json:
                return jsonify({
                    'success': False, 
                    'message': 'يرجى تأكيد بريدك الإلكتروني أولاً',
                    'redirect': url_for('auth.unverified')
                }), 403
            flash('يرجى تأكيد بريدك الإلكتروني أولاً', 'warning')
            return redirect(url_for('auth.unverified'))
        
        if current_user.is_banned:
            if request.is_json:
                return jsonify({
                    'success': False,
                    'message': 'حسابك محظور'
                }), 403
            flash('حسابك محظور، تواصل مع الدعم', 'danger')
            return redirect(url_for('main.index'))
        
        return f(*args, **kwargs)
    return decorated_function


def ajax_required(f):
    """
    Decorator للتحقق من أن الطلب AJAX
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not request.is_json and not request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({
                'success': False,
                'message': 'طلب غير صالح'
            }), 400
        return f(*args, **kwargs)
    return decorated_function


def rate_limit_by_user(limit: str = "10 per minute"):
    """
    Decorator لتحديد معدل الطلبات للمستخدم
    """
    from flask_limiter import Limiter
    from flask_limiter.util import get_remote_address
    
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # يمكن تخصيص المعرف هنا
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def cache_response(timeout: int = 300, key_prefix: str = ''):
    """
    Decorator للتخزين المؤقت للاستجابة
    """
    from app.extensions import cache
    
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # إنشاء مفتاح التخزين
            cache_key = f"{key_prefix}:{request.path}:{request.query_string.decode()}"
            
            # البحث في الذاكرة المؤقتة
            cached = cache.get(cache_key)
            if cached:
                return cached
            
            # تنفيذ الدالة وتخزين النتيجة
            result = f(*args, **kwargs)
            cache.set(cache_key, result, timeout=timeout)
            
            return result
        return decorated_function
    return decorator


def log_activity(action: str):
    """
    Decorator لتسجيل النشاط
    """
    from flask import current_app
    
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            result = f(*args, **kwargs)
            
            # تسجيل النشاط
            user_id = current_user.id if current_user.is_authenticated else None
            current_app.logger.info(
                f"Activity: {action} | User: {user_id} | "
                f"IP: {request.remote_addr} | Path: {request.path}"
            )
            
            return result
        return decorated_function
    return decorator