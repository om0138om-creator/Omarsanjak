"""
======================================
🔧 Helper Functions
======================================
"""

import re
import secrets
import string
import unicodedata
from typing import Optional, List
from datetime import datetime
import bleach
from slugify import slugify as python_slugify


def generate_random_string(length: int = 32, include_special: bool = False) -> str:
    """توليد نص عشوائي"""
    characters = string.ascii_letters + string.digits
    if include_special:
        characters += string.punctuation
    return ''.join(secrets.choice(characters) for _ in range(length))


def generate_otp(length: int = 6) -> str:
    """توليد رمز OTP"""
    return ''.join(secrets.choice(string.digits) for _ in range(length))


def format_phone_number(phone: str, country_code: str = '+213') -> str:
    """
    تنسيق رقم الهاتف الجزائري
    
    Examples:
        0555123456 -> +213555123456
        +213555123456 -> +213555123456
        555123456 -> +213555123456
    """
    # إزالة المسافات والرموز
    phone = re.sub(r'[\s\-\.\(\)]', '', phone)
    
    # إزالة الصفر البادئ
    if phone.startswith('0'):
        phone = phone[1:]
    
    # إزالة رمز الدولة إذا موجود
    if phone.startswith(country_code):
        phone = phone[len(country_code):]
    elif phone.startswith(country_code.replace('+', '00')):
        phone = phone[len(country_code) + 1:]
    
    # إضافة رمز الدولة
    return f"{country_code}{phone}"


def validate_algerian_phone(phone: str) -> bool:
    """التحقق من صحة رقم هاتف جزائري"""
    # تنسيق الرقم أولاً
    formatted = format_phone_number(phone)
    
    # التحقق من النمط
    pattern = r'^\+213[567]\d{8}$'
    return bool(re.match(pattern, formatted))


def sanitize_html(html: str, allowed_tags: Optional[List[str]] = None) -> str:
    """تنظيف HTML من الأكواد الضارة"""
    if allowed_tags is None:
        allowed_tags = [
            'p', 'br', 'strong', 'em', 'u', 's',
            'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
            'ul', 'ol', 'li',
            'a', 'img',
            'blockquote', 'code', 'pre',
            'table', 'thead', 'tbody', 'tr', 'th', 'td'
        ]
    
    allowed_attrs = {
        'a': ['href', 'title', 'target'],
        'img': ['src', 'alt', 'title', 'width', 'height'],
        '*': ['class', 'style']
    }
    
    return bleach.clean(
        html,
        tags=allowed_tags,
        attributes=allowed_attrs,
        strip=True
    )


def slugify_arabic(text: str, max_length: int = 100) -> str:
    """
    تحويل النص إلى slug يدعم العربية
    """
    # إزالة التشكيل
    text = ''.join(
        c for c in unicodedata.normalize('NFD', text)
        if unicodedata.category(c) != 'Mn'
    )
    
    # استخدام slugify مع دعم Unicode
    slug = python_slugify(text, allow_unicode=True)
    
    # تقصير إذا لزم الأمر
    if len(slug) > max_length:
        slug = slug[:max_length].rsplit('-', 1)[0]
    
    return slug


def truncate_text(text: str, length: int = 100, suffix: str = '...') -> str:
    """اختصار النص"""
    if not text:
        return ''
    if len(text) <= length:
        return text
    return text[:length].rsplit(' ', 1)[0] + suffix


def format_price(amount, currency: str = 'د.ج', decimals: int = 2) -> str:
    """تنسيق السعر"""
    if amount is None:
        return f'0 {currency}'
    return f'{amount:,.{decimals}f} {currency}'


def format_file_size(size_bytes: int) -> str:
    """تنسيق حجم الملف"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def time_ago(dt: datetime) -> str:
    """حساب الوقت المنقضي"""
    if not dt:
        return ''
    
    now = datetime.utcnow()
    diff = now - dt
    seconds = diff.total_seconds()
    
    intervals = [
        (31536000, 'سنة', 'سنوات'),
        (2592000, 'شهر', 'أشهر'),
        (604800, 'أسبوع', 'أسابيع'),
        (86400, 'يوم', 'أيام'),
        (3600, 'ساعة', 'ساعات'),
        (60, 'دقيقة', 'دقائق'),
    ]
    
    for interval, singular, plural in intervals:
        count = int(seconds // interval)
        if count >= 1:
            unit = singular if count == 1 else plural
            return f'منذ {count} {unit}'
    
    return 'الآن'


def parse_tags(tags_string: str) -> List[str]:
    """تحويل نص الوسوم إلى قائمة"""
    if not tags_string:
        return []
    
    # الفصل بالفاصلة أو المسافة
    tags = re.split(r'[,،\s]+', tags_string)
    
    # تنظيف وإزالة الفارغة
    return [tag.strip() for tag in tags if tag.strip()]


def calculate_percentage_change(old_value: float, new_value: float) -> float:
    """حساب نسبة التغير"""
    if old_value == 0:
        return 100 if new_value > 0 else 0
    return ((new_value - old_value) / old_value) * 100


def mask_email(email: str) -> str:
    """إخفاء جزء من البريد الإلكتروني"""
    if '@' not in email:
        return email
    
    local, domain = email.split('@')
    if len(local) <= 2:
        masked_local = local[0] + '*'
    else:
        masked_local = local[0] + '*' * (len(local) - 2) + local[-1]
    
    return f"{masked_local}@{domain}"


def mask_phone(phone: str) -> str:
    """إخفاء جزء من رقم الهاتف"""
    if len(phone) < 6:
        return phone
    
    return phone[:4] + '*' * (len(phone) - 6) + phone[-2:]


def get_client_ip() -> str:
    """الحصول على IP العميل"""
    from flask import request
    
    # التحقق من الـ headers للـ proxy
    if request.headers.get('X-Forwarded-For'):
        return request.headers.get('X-Forwarded-For').split(',')[0].strip()
    elif request.headers.get('X-Real-IP'):
        return request.headers.get('X-Real-IP')
    else:
        return request.remote_addr or '127.0.0.1'