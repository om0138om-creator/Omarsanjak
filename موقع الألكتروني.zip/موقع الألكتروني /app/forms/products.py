"""
======================================
📦 Product Forms
======================================
نماذج المنتجات
"""

from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed, MultipleFileField
from wtforms import (
    StringField, TextAreaField, DecimalField, IntegerField,
    SelectField, BooleanField, SubmitField, HiddenField, 
    SelectMultipleField, DateTimeLocalField
)
from wtforms.validators import (
    DataRequired, Length, NumberRange, Optional, ValidationError
)


class ProductForm(FlaskForm):
    """نموذج إضافة/تعديل المنتج"""
    
    # المعلومات الأساسية
    name = StringField('اسم المنتج', validators=[
        DataRequired(message='اسم المنتج مطلوب'),
        Length(min=3, max=200, message='الاسم يجب أن يكون بين 3 و 200 حرف')
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'اسم المنتج'
    })
    
    name_ar = StringField('اسم المنتج (بالعربية)', validators=[
        Optional(),
        Length(max=200)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'اسم المنتج بالعربية'
    })
    
    sku = StringField('رمز المنتج (SKU)', validators=[
        Optional(),
        Length(max=50)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'PRD-001'
    })
    
    short_description = TextAreaField('وصف قصير', validators=[
        Optional(),
        Length(max=500)
    ], render_kw={
        'class': 'form-control',
        'rows': 2,
        'placeholder': 'وصف قصير للمنتج...'
    })
    
    description = TextAreaField('الوصف الكامل', validators=[
        Optional()
    ], render_kw={
        'class': 'form-control',
        'rows': 6,
        'placeholder': 'وصف تفصيلي للمنتج...'
    })
    
    # التصنيف
    category_id = SelectField('التصنيف', coerce=int, validators=[
        DataRequired(message='التصنيف مطلوب')
    ], render_kw={
        'class': 'form-select'
    })
    
    brand = StringField('العلامة التجارية', validators=[
        Optional(),
        Length(max=100)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'اسم العلامة التجارية'
    })
    
    tags = StringField('الوسوم', validators=[
        Optional(),
        Length(max=500)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'وسم1، وسم2، وسم3'
    })
    
    # التسعير
    price = DecimalField('السعر (د.ج)', validators=[
        DataRequired(message='السعر مطلوب'),
        NumberRange(min=0, message='السعر يجب أن يكون أكبر من صفر')
    ], render_kw={
        'class': 'form-control',
        'placeholder': '0.00',
        'step': '0.01'
    })
    
    compare_at_price = DecimalField('السعر قبل الخصم', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '0.00',
        'step': '0.01'
    })
    
    cost_price = DecimalField('سعر التكلفة', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '0.00',
        'step': '0.01'
    })
    
    # الخصم
    discount_type = SelectField('نوع الخصم', choices=[
        ('', 'بدون خصم'),
        ('percentage', 'نسبة مئوية %'),
        ('fixed', 'مبلغ ثابت')
    ], validators=[
        Optional()
    ], render_kw={
        'class': 'form-select'
    })
    
    discount_value = DecimalField('قيمة الخصم', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '0'
    })
    
    discount_start = DateTimeLocalField('بداية الخصم', validators=[
        Optional()
    ], render_kw={
        'class': 'form-control'
    })
    
    discount_end = DateTimeLocalField('نهاية الخصم', validators=[
        Optional()
    ], render_kw={
        'class': 'form-control'
    })
    
    # المخزون
    stock_quantity = IntegerField('الكمية المتوفرة', validators=[
        DataRequired(message='الكمية مطلوبة'),
        NumberRange(min=0, message='الكمية يجب أن تكون صفر أو أكثر')
    ], render_kw={
        'class': 'form-control',
        'placeholder': '0'
    })
    
    low_stock_threshold = IntegerField('حد المخزون المنخفض', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '5'
    })
    
    track_inventory = BooleanField('تتبع المخزون', render_kw={
        'class': 'form-check-input'
    })
    
    allow_backorder = BooleanField('السماح بالطلب المسبق', render_kw={
        'class': 'form-check-input'
    })
    
    # الكميات
    min_purchase_qty = IntegerField('الحد الأدنى للشراء', validators=[
        Optional(),
        NumberRange(min=1)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '1'
    })
    
    max_purchase_qty = IntegerField('الحد الأقصى للشراء', validators=[
        Optional(),
        NumberRange(min=1)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '10'
    })
    
    # الأبعاد والوزن
    weight = DecimalField('الوزن (كجم)', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '0.00'
    })
    
    length = DecimalField('الطول (سم)', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '0'
    })
    
    width = DecimalField('العرض (سم)', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '0'
    })
    
    height = DecimalField('الارتفاع (سم)', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '0'
    })
    
    # الصور
    main_image = FileField('الصورة الرئيسية', validators=[
        Optional(),
        FileAllowed(['jpg', 'jpeg', 'png', 'gif', 'webp'], 'صور فقط!')
    ], render_kw={
        'class': 'form-control',
        'accept': 'image/*'
    })
    
    additional_images = MultipleFileField('صور إضافية', validators=[
        Optional(),
        FileAllowed(['jpg', 'jpeg', 'png', 'gif', 'webp'], 'صور فقط!')
    ], render_kw={
        'class': 'form-control',
        'accept': 'image/*',
        'multiple': True
    })
    
    # الحالة
    is_active = BooleanField('نشط', default=True, render_kw={
        'class': 'form-check-input'
    })
    
    is_featured = BooleanField('مميز', render_kw={
        'class': 'form-check-input'
    })
    
    is_new = BooleanField('جديد', default=True, render_kw={
        'class': 'form-check-input'
    })
    
    # SEO
    meta_title = StringField('عنوان SEO', validators=[
        Optional(),
        Length(max=70)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'عنوان الصفحة في محركات البحث'
    })
    
    meta_description = TextAreaField('وصف SEO', validators=[
        Optional(),
        Length(max=160)
    ], render_kw={
        'class': 'form-control',
        'rows': 2,
        'placeholder': 'وصف الصفحة في محركات البحث'
    })
    
    submit = SubmitField('حفظ المنتج', render_kw={
        'class': 'btn btn-dark btn-lg'
    })


class ProductSearchForm(FlaskForm):
    """نموذج البحث في المنتجات"""
    
    q = StringField('البحث', validators=[
        Optional(),
        Length(max=100)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'ابحث عن منتج...'
    })
    
    category = SelectField('التصنيف', coerce=int, validators=[
        Optional()
    ], render_kw={
        'class': 'form-select'
    })
    
    min_price = DecimalField('السعر من', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'من'
    })
    
    max_price = DecimalField('السعر إلى', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'إلى'
    })
    
    in_stock = BooleanField('متوفر فقط', render_kw={
        'class': 'form-check-input'
    })
    
    on_sale = BooleanField('عروض فقط', render_kw={
        'class': 'form-check-input'
    })
    
    sort = SelectField('الترتيب', choices=[
        ('relevance', 'الأكثر صلة'),
        ('newest', 'الأحدث'),
        ('price_asc', 'السعر: من الأقل'),
        ('price_desc', 'السعر: من الأعلى'),
        ('bestselling', 'الأكثر مبيعاً'),
        ('rating', 'التقييم')
    ], render_kw={
        'class': 'form-select'
    })
    
    submit = SubmitField('بحث', render_kw={
        'class': 'btn btn-dark'
    })


class ReviewForm(FlaskForm):
    """نموذج تقييم المنتج"""
    
    rating = HiddenField('التقييم', validators=[
        DataRequired(message='التقييم مطلوب')
    ])
    
    title = StringField('عنوان التقييم', validators=[
        Optional(),
        Length(max=200)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'عنوان تقييمك'
    })
    
    comment = TextAreaField('تعليقك', validators=[
        DataRequired(message='التعليق مطلوب'),
        Length(min=10, max=2000, message='التعليق يجب أن يكون بين 10 و 2000 حرف')
    ], render_kw={
        'class': 'form-control',
        'rows': 4,
        'placeholder': 'شاركنا تجربتك مع هذا المنتج...'
    })
    
    pros = TextAreaField('الإيجابيات', validators=[
        Optional(),
        Length(max=500)
    ], render_kw={
        'class': 'form-control',
        'rows': 2,
        'placeholder': 'ما الذي أعجبك؟'
    })
    
    cons = TextAreaField('السلبيات', validators=[
        Optional(),
        Length(max=500)
    ], render_kw={
        'class': 'form-control',
        'rows': 2,
        'placeholder': 'ما الذي لم يعجبك؟'
    })
    
    submit = SubmitField('إرسال التقييم', render_kw={
        'class': 'btn btn-dark'
    })
    
    def validate_rating(self, field):
        """التحقق من قيمة التقييم"""
        try:
            rating = int(field.data)
            if rating < 1 or rating > 5:
                raise ValidationError('التقييم يجب أن يكون بين 1 و 5')
        except (ValueError, TypeError):
            raise ValidationError('التقييم غير صالح')