"""
======================================
🔐 Authentication Forms
======================================
نماذج المصادقة
"""

from flask_wtf import FlaskForm
from wtforms import (
    StringField, PasswordField, BooleanField, 
    SubmitField, TextAreaField, SelectField, DateField
)
from wtforms.validators import (
    DataRequired, Email, Length, EqualTo, 
    ValidationError, Optional, Regexp
)
from app.models.user import User


class LoginForm(FlaskForm):
    """نموذج تسجيل الدخول"""
    
    email = StringField('البريد الإلكتروني', validators=[
        DataRequired(message='البريد الإلكتروني مطلوب'),
        Email(message='البريد الإلكتروني غير صالح')
    ], render_kw={
        'placeholder': 'example@email.com',
        'class': 'form-control',
        'autocomplete': 'email'
    })
    
    password = PasswordField('كلمة المرور', validators=[
        DataRequired(message='كلمة المرور مطلوبة')
    ], render_kw={
        'placeholder': '••••••••',
        'class': 'form-control',
        'autocomplete': 'current-password'
    })
    
    remember_me = BooleanField('تذكرني', render_kw={
        'class': 'form-check-input'
    })
    
    submit = SubmitField('تسجيل الدخول', render_kw={
        'class': 'btn btn-dark w-100'
    })


class RegisterForm(FlaskForm):
    """نموذج التسجيل"""
    
    first_name = StringField('الاسم الأول', validators=[
        DataRequired(message='الاسم الأول مطلوب'),
        Length(min=2, max=50, message='الاسم يجب أن يكون بين 2 و 50 حرفاً')
    ], render_kw={
        'placeholder': 'محمد',
        'class': 'form-control',
        'autocomplete': 'given-name'
    })
    
    last_name = StringField('اسم العائلة', validators=[
        DataRequired(message='اسم العائلة مطلوب'),
        Length(min=2, max=50, message='الاسم يجب أن يكون بين 2 و 50 حرفاً')
    ], render_kw={
        'placeholder': 'أحمد',
        'class': 'form-control',
        'autocomplete': 'family-name'
    })
    
    email = StringField('البريد الإلكتروني', validators=[
        DataRequired(message='البريد الإلكتروني مطلوب'),
        Email(message='البريد الإلكتروني غير صالح'),
        Length(max=120)
    ], render_kw={
        'placeholder': 'example@email.com',
        'class': 'form-control',
        'autocomplete': 'email'
    })
    
    phone = StringField('رقم الهاتف', validators=[
        DataRequired(message='رقم الهاتف مطلوب'),
        Length(min=9, max=20, message='رقم الهاتف غير صالح'),
        Regexp(r'^[\d\+\-\s\(\)]+$', message='رقم الهاتف غير صالح')
    ], render_kw={
        'placeholder': '0555 12 34 56',
        'class': 'form-control',
        'autocomplete': 'tel',
        'dir': 'ltr'
    })
    
    password = PasswordField('كلمة المرور', validators=[
        DataRequired(message='كلمة المرور مطلوبة'),
        Length(min=8, message='كلمة المرور يجب أن تكون 8 أحرف على الأقل')
    ], render_kw={
        'placeholder': '••••••••',
        'class': 'form-control',
        'autocomplete': 'new-password'
    })
    
    password_confirm = PasswordField('تأكيد كلمة المرور', validators=[
        DataRequired(message='تأكيد كلمة المرور مطلوب'),
        EqualTo('password', message='كلمات المرور غير متطابقة')
    ], render_kw={
        'placeholder': '••••••••',
        'class': 'form-control',
        'autocomplete': 'new-password'
    })
    
    terms = BooleanField('أوافق على', validators=[
        DataRequired(message='يجب الموافقة على الشروط والأحكام')
    ], render_kw={
        'class': 'form-check-input'
    })
    
    submit = SubmitField('إنشاء حساب', render_kw={
        'class': 'btn btn-dark w-100'
    })
    
    def validate_email(self, field):
        """التحقق من عدم وجود البريد الإلكتروني"""
        user = User.query.filter_by(email=field.data.lower()).first()
        if user:
            raise ValidationError('البريد الإلكتروني مستخدم بالفعل')
    
    def validate_phone(self, field):
        """التحقق من عدم وجود رقم الهاتف"""
        from app.utils.helpers import format_phone_number
        formatted = format_phone_number(field.data)
        user = User.query.filter_by(phone=formatted).first()
        if user:
            raise ValidationError('رقم الهاتف مستخدم بالفعل')


class ForgotPasswordForm(FlaskForm):
    """نموذج نسيت كلمة المرور"""
    
    email = StringField('البريد الإلكتروني', validators=[
        DataRequired(message='البريد الإلكتروني مطلوب'),
        Email(message='البريد الإلكتروني غير صالح')
    ], render_kw={
        'placeholder': 'example@email.com',
        'class': 'form-control',
        'autocomplete': 'email'
    })
    
    submit = SubmitField('إرسال رابط الاستعادة', render_kw={
        'class': 'btn btn-dark w-100'
    })


class ResetPasswordForm(FlaskForm):
    """نموذج إعادة تعيين كلمة المرور"""
    
    password = PasswordField('كلمة المرور الجديدة', validators=[
        DataRequired(message='كلمة المرور مطلوبة'),
        Length(min=8, message='كلمة المرور يجب أن تكون 8 أحرف على الأقل')
    ], render_kw={
        'placeholder': '••••••••',
        'class': 'form-control',
        'autocomplete': 'new-password'
    })
    
    password_confirm = PasswordField('تأكيد كلمة المرور', validators=[
        DataRequired(message='تأكيد كلمة المرور مطلوب'),
        EqualTo('password', message='كلمات المرور غير متطابقة')
    ], render_kw={
        'placeholder': '••••••••',
        'class': 'form-control',
        'autocomplete': 'new-password'
    })
    
    submit = SubmitField('تعيين كلمة المرور', render_kw={
        'class': 'btn btn-dark w-100'
    })


class ChangePasswordForm(FlaskForm):
    """نموذج تغيير كلمة المرور"""
    
    current_password = PasswordField('كلمة المرور الحالية', validators=[
        DataRequired(message='كلمة المرور الحالية مطلوبة')
    ], render_kw={
        'placeholder': '••••••••',
        'class': 'form-control'
    })
    
    new_password = PasswordField('كلمة المرور الجديدة', validators=[
        DataRequired(message='كلمة المرور الجديدة مطلوبة'),
        Length(min=8, message='كلمة المرور يجب أن تكون 8 أحرف على الأقل')
    ], render_kw={
        'placeholder': '••••••••',
        'class': 'form-control'
    })
    
    confirm_password = PasswordField('تأكيد كلمة المرور', validators=[
        DataRequired(message='تأكيد كلمة المرور مطلوب'),
        EqualTo('new_password', message='كلمات المرور غير متطابقة')
    ], render_kw={
        'placeholder': '••••••••',
        'class': 'form-control'
    })
    
    submit = SubmitField('تغيير كلمة المرور', render_kw={
        'class': 'btn btn-dark'
    })


class ProfileForm(FlaskForm):
    """نموذج تعديل الملف الشخصي"""
    
    first_name = StringField('الاسم الأول', validators=[
        DataRequired(message='الاسم الأول مطلوب'),
        Length(min=2, max=50)
    ], render_kw={
        'class': 'form-control'
    })
    
    last_name = StringField('اسم العائلة', validators=[
        DataRequired(message='اسم العائلة مطلوب'),
        Length(min=2, max=50)
    ], render_kw={
        'class': 'form-control'
    })
    
    phone = StringField('رقم الهاتف', validators=[
        DataRequired(message='رقم الهاتف مطلوب'),
        Length(min=9, max=20)
    ], render_kw={
        'class': 'form-control',
        'dir': 'ltr'
    })
    
    date_of_birth = DateField('تاريخ الميلاد', validators=[
        Optional()
    ], render_kw={
        'class': 'form-control',
        'type': 'date'
    })
    
    gender = SelectField('الجنس', choices=[
        ('', 'اختر...'),
        ('male', 'ذكر'),
        ('female', 'أنثى')
    ], validators=[
        Optional()
    ], render_kw={
        'class': 'form-select'
    })
    
    submit = SubmitField('حفظ التغييرات', render_kw={
        'class': 'btn btn-dark'
    })