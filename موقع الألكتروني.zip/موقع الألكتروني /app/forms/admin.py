"""
======================================
🔧 Admin Forms
======================================
نماذج لوحة التحكم
"""

from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import (
    StringField, TextAreaField, DecimalField, IntegerField,
    SelectField, BooleanField, SubmitField, PasswordField,
    SelectMultipleField, DateTimeLocalField
)
from wtforms.validators import (
    DataRequired, Length, NumberRange, Optional,
    Email, ValidationError, URL
)


class CategoryForm(FlaskForm):
    """نموذج إضافة/تعديل الفئة"""
    
    name = StringField('الاسم (إنجليزي)', validators=[
        DataRequired(message='الاسم مطلوب'),
        Length(min=2, max=100)
    ], render_kw={'class': 'form-control'})
    
    name_ar = StringField('الاسم (عربي)', validators=[
        Optional(),
        Length(max=100)
    ], render_kw={'class': 'form-control'})
    
    description = TextAreaField('الوصف', validators=[
        Optional(),
        Length(max=1000)
    ], render_kw={'class': 'form-control', 'rows': 3})
    
    parent_id = SelectField('الفئة الأصلية', coerce=int, validators=[
        Optional()
    ], render_kw={'class': 'form-select'})
    
    image = FileField('الصورة', validators=[
        Optional(),
        FileAllowed(['jpg', 'jpeg', 'png', 'gif', 'webp'], 'صور فقط!')
    ], render_kw={'class': 'form-control', 'accept': 'image/*'})
    
    icon = StringField('الأيقونة (CSS Class)', validators=[
        Optional(),
        Length(max=50)
    ], render_kw={'class': 'form-control', 'placeholder': 'bi-laptop'})
    
    is_active = BooleanField('نشطة', default=True, render_kw={'class': 'form-check-input'})
    is_featured = BooleanField('مميزة', render_kw={'class': 'form-check-input'})
    show_in_menu = BooleanField('إظهار في القائمة', default=True, render_kw={'class': 'form-check-input'})
    
    sort_order = IntegerField('الترتيب', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={'class': 'form-control'})
    
    # SEO
    meta_title = StringField('عنوان SEO', validators=[
        Optional(),
        Length(max=70)
    ], render_kw={'class': 'form-control'})
    
    meta_description = TextAreaField('وصف SEO', validators=[
        Optional(),
        Length(max=160)
    ], render_kw={'class': 'form-control', 'rows': 2})
    
    submit = SubmitField('حفظ', render_kw={'class': 'btn btn-dark'})


class ShippingZoneForm(FlaskForm):
    """نموذج منطقة الشحن"""
    
    name = StringField('الاسم (إنجليزي)', validators=[
        DataRequired(message='الاسم مطلوب'),
        Length(max=100)
    ], render_kw={'class': 'form-control'})
    
    name_ar = StringField('الاسم (عربي)', validators=[
        DataRequired(message='الاسم بالعربية مطلوب'),
        Length(max=100)
    ], render_kw={'class': 'form-control'})
    
    code = StringField('الرمز', validators=[
        Optional(),
        Length(max=10)
    ], render_kw={'class': 'form-control'})
    
    shipping_cost = DecimalField('تكلفة الشحن (د.ج)', validators=[
        DataRequired(message='تكلفة الشحن مطلوبة'),
        NumberRange(min=0)
    ], render_kw={'class': 'form-control'})
    
    express_shipping_cost = DecimalField('تكلفة الشحن السريع (د.ج)', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={'class': 'form-control'})
    
    free_shipping_threshold = DecimalField('حد الشحن المجاني (د.ج)', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={'class': 'form-control', 'placeholder': 'اتركه فارغاً لتعطيل'})
    
    estimated_days_min = IntegerField('أيام التوصيل (من)', validators=[
        DataRequired(),
        NumberRange(min=1)
    ], render_kw={'class': 'form-control'})
    
    estimated_days_max = IntegerField('أيام التوصيل (إلى)', validators=[
        DataRequired(),
        NumberRange(min=1)
    ], render_kw={'class': 'form-control'})
    
    express_days = IntegerField('أيام التوصيل السريع', validators=[
        Optional(),
        NumberRange(min=1)
    ], render_kw={'class': 'form-control'})
    
    is_active = BooleanField('نشطة', default=True, render_kw={'class': 'form-check-input'})
    is_express_available = BooleanField('الشحن السريع متاح', default=True, render_kw={'class': 'form-check-input'})
    
    sort_order = IntegerField('الترتيب', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={'class': 'form-control'})
    
    submit = SubmitField('حفظ', render_kw={'class': 'btn btn-dark'})


class CouponAdminForm(FlaskForm):
    """نموذج كوبون الخصم (للمشرف)"""
    
    code = StringField('رمز الكوبون', validators=[
        DataRequired(message='الرمز مطلوب'),
        Length(min=3, max=50)
    ], render_kw={
        'class': 'form-control',
        'style': 'text-transform: uppercase;'
    })
    
    description = StringField('الوصف', validators=[
        Optional(),
        Length(max=255)
    ], render_kw={'class': 'form-control'})
    
    discount_type = SelectField('نوع الخصم', choices=[
        ('percentage', 'نسبة مئوية %'),
        ('fixed', 'مبلغ ثابت'),
        ('free_shipping', 'شحن مجاني')
    ], render_kw={'class': 'form-select'})
    
    discount_value = DecimalField('قيمة الخصم', validators=[
        DataRequired(message='قيمة الخصم مطلوبة'),
        NumberRange(min=0)
    ], render_kw={'class': 'form-control'})
    
    maximum_discount = DecimalField('الحد الأقصى للخصم', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={'class': 'form-control', 'placeholder': 'للنسبة المئوية فقط'})
    
    minimum_amount = DecimalField('الحد الأدنى للطلب', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={'class': 'form-control'})
    
    usage_limit = IntegerField('حد الاستخدام الكلي', validators=[
        Optional(),
        NumberRange(min=1)
    ], render_kw={'class': 'form-control', 'placeholder': 'اتركه فارغاً لغير محدود'})
    
    usage_limit_per_user = IntegerField('حد الاستخدام لكل مستخدم', validators=[
        Optional(),
        NumberRange(min=1)
    ], default=1, render_kw={'class': 'form-control'})
    
    starts_at = DateTimeLocalField('تاريخ البدء', validators=[
        Optional()
    ], render_kw={'class': 'form-control'})
    
    expires_at = DateTimeLocalField('تاريخ الانتهاء', validators=[
        Optional()
    ], render_kw={'class': 'form-control'})
    
    is_active = BooleanField('نشط', default=True, render_kw={'class': 'form-check-input'})
    is_public = BooleanField('عام (ظاهر للجميع)', default=True, render_kw={'class': 'form-check-input'})
    first_order_only = BooleanField('للطلب الأول فقط', render_kw={'class': 'form-check-input'})
    
    submit = SubmitField('حفظ الكوبون', render_kw={'class': 'btn btn-dark'})
    
    def validate_code(self, field):
        """التحقق من عدم تكرار الرمز"""
        from app.models.coupon import Coupon
        existing = Coupon.query.filter_by(code=field.data.upper()).first()
        # سنتحقق من هذا في الـ route لأننا نحتاج معرفة إذا كان تعديل أو إضافة


class SiteSettingsForm(FlaskForm):
    """نموذج إعدادات الموقع"""
    
    # معلومات المتجر
    store_name = StringField('اسم المتجر', validators=[
        DataRequired(),
        Length(max=100)
    ], render_kw={'class': 'form-control'})
    
    store_name_ar = StringField('اسم المتجر (عربي)', validators=[
        Optional(),
        Length(max=100)
    ], render_kw={'class': 'form-control'})
    
    tagline = StringField('الشعار', validators=[
        Optional(),
        Length(max=200)
    ], render_kw={'class': 'form-control'})
    
    description = TextAreaField('الوصف', validators=[
        Optional()
    ], render_kw={'class': 'form-control', 'rows': 3})
    
    # معلومات الاتصال
    email = StringField('البريد الإلكتروني', validators=[
        Optional(),
        Email()
    ], render_kw={'class': 'form-control'})
    
    phone = StringField('رقم الهاتف', validators=[
        Optional(),
        Length(max=20)
    ], render_kw={'class': 'form-control'})
    
    whatsapp = StringField('واتساب', validators=[
        Optional(),
        Length(max=20)
    ], render_kw={'class': 'form-control'})
    
    address = TextAreaField('العنوان', validators=[
        Optional()
    ], render_kw={'class': 'form-control', 'rows': 2})
    
    # وسائل التواصل
    facebook_url = StringField('فيسبوك', validators=[
        Optional(),
        URL(message='رابط غير صالح')
    ], render_kw={'class': 'form-control', 'placeholder': 'https://facebook.com/...'})
    
    instagram_url = StringField('انستغرام', validators=[
        Optional(),
        URL(message='رابط غير صالح')
    ], render_kw={'class': 'form-control', 'placeholder': 'https://instagram.com/...'})
    
    twitter_url = StringField('تويتر', validators=[
        Optional(),
        URL(message='رابط غير صالح')
    ], render_kw={'class': 'form-control', 'placeholder': 'https://twitter.com/...'})
    
    youtube_url = StringField('يوتيوب', validators=[
        Optional(),
        URL(message='رابط غير صالح')
    ], render_kw={'class': 'form-control', 'placeholder': 'https://youtube.com/...'})
    
    tiktok_url = StringField('تيك توك', validators=[
        Optional(),
        URL(message='رابط غير صالح')
    ], render_kw={'class': 'form-control', 'placeholder': 'https://tiktok.com/...'})
    
    # الشعار
    logo = FileField('الشعار', validators=[
        Optional(),
        FileAllowed(['jpg', 'jpeg', 'png', 'svg', 'webp'], 'صور فقط!')
    ], render_kw={'class': 'form-control', 'accept': 'image/*'})
    
    favicon = FileField('أيقونة الموقع', validators=[
        Optional(),
        FileAllowed(['ico', 'png', 'svg'], 'ICO أو PNG فقط!')
    ], render_kw={'class': 'form-control', 'accept': '.ico,.png,.svg'})
    
    # الضرائب
    tax_enabled = BooleanField('تفعيل الضرائب', render_kw={'class': 'form-check-input'})
    
    tax_rate = DecimalField('نسبة الضريبة %', validators=[
        Optional(),
        NumberRange(min=0, max=100)
    ], render_kw={'class': 'form-control'})
    
    tax_included_in_price = BooleanField('الضريبة مضمنة في السعر', render_kw={'class': 'form-check-input'})
    
    # الشحن
    free_shipping_enabled = BooleanField('تفعيل الشحن المجاني', render_kw={'class': 'form-check-input'})
    
    free_shipping_threshold = DecimalField('حد الشحن المجاني (د.ج)', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={'class': 'form-control'})
    
    default_shipping_cost = DecimalField('تكلفة الشحن الافتراضية (د.ج)', validators=[
        Optional(),
        NumberRange(min=0)
    ], render_kw={'class': 'form-control'})
    
    # الصيانة
    maintenance_mode = BooleanField('وضع الصيانة', render_kw={'class': 'form-check-input'})
    
    maintenance_message = TextAreaField('رسالة الصيانة', validators=[
        Optional()
    ], render_kw={'class': 'form-control', 'rows': 3})
    
    # SEO
    meta_title = StringField('عنوان SEO', validators=[
        Optional(),
        Length(max=70)
    ], render_kw={'class': 'form-control'})
    
    meta_description = TextAreaField('وصف SEO', validators=[
        Optional(),
        Length(max=160)
    ], render_kw={'class': 'form-control', 'rows': 2})
    
    google_analytics_id = StringField('Google Analytics ID', validators=[
        Optional(),
        Length(max=50)
    ], render_kw={'class': 'form-control', 'placeholder': 'G-XXXXXXXXXX'})
    
    facebook_pixel_id = StringField('Facebook Pixel ID', validators=[
        Optional(),
        Length(max=50)
    ], render_kw={'class': 'form-control'})
    
    submit = SubmitField('حفظ الإعدادات', render_kw={'class': 'btn btn-dark btn-lg'})


class OrderStatusForm(FlaskForm):
    """نموذج تغيير حالة الطلب"""
    
    status = SelectField('الحالة الجديدة', validators=[
        DataRequired()
    ], render_kw={'class': 'form-select'})
    
    notes = TextAreaField('ملاحظات', validators=[
        Optional(),
        Length(max=500)
    ], render_kw={'class': 'form-control', 'rows': 2})
    
    tracking_number = StringField('رقم التتبع', validators=[
        Optional(),
        Length(max=100)
    ], render_kw={'class': 'form-control'})
    
    carrier = StringField('شركة التوصيل', validators=[
        Optional(),
        Length(max=50)
    ], render_kw={'class': 'form-control'})
    
    notify_customer = BooleanField('إشعار العميل', default=True, render_kw={'class': 'form-check-input'})
    
    submit = SubmitField('تحديث الحالة', render_kw={'class': 'btn btn-dark'})


class AdminTicketReplyForm(FlaskForm):
    """نموذج رد المشرف على التذكرة"""
    
    content = TextAreaField('الرد', validators=[
        DataRequired(message='الرد مطلوب'),
        Length(min=5, max=5000)
    ], render_kw={'class': 'form-control', 'rows': 5})
    
    is_internal_note = BooleanField('ملاحظة داخلية (لا تظهر للعميل)', render_kw={'class': 'form-check-input'})
    
    status = SelectField('تغيير الحالة', choices=[
        ('', 'بدون تغيير'),
        ('in_progress', 'قيد المعالجة'),
        ('waiting_customer', 'بانتظار رد العميل'),
        ('resolved', 'تم الحل'),
        ('closed', 'مغلقة')
    ], render_kw={'class': 'form-select'})
    
    submit = SubmitField('إرسال الرد', render_kw={'class': 'btn btn-dark'})