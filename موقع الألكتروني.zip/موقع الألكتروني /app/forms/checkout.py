"""
======================================
🛒 Checkout Forms
======================================
نماذج الدفع والعناوين
"""

from flask_wtf import FlaskForm
from wtforms import (
    StringField, TextAreaField, SelectField, 
    BooleanField, SubmitField, HiddenField, RadioField
)
from wtforms.validators import (
    DataRequired, Length, Optional, ValidationError, Regexp
)


class AddressForm(FlaskForm):
    """نموذج العنوان"""
    
    label = SelectField('نوع العنوان', choices=[
        ('home', '🏠 المنزل'),
        ('work', '🏢 العمل'),
        ('other', '📍 آخر')
    ], render_kw={
        'class': 'form-select'
    })
    
    full_name = StringField('الاسم الكامل', validators=[
        DataRequired(message='الاسم مطلوب'),
        Length(min=3, max=100)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'الاسم الكامل'
    })
    
    phone = StringField('رقم الهاتف', validators=[
        DataRequired(message='رقم الهاتف مطلوب'),
        Length(min=9, max=20),
        Regexp(r'^[\d\+\-\s\(\)]+$', message='رقم الهاتف غير صالح')
    ], render_kw={
        'class': 'form-control',
        'placeholder': '0555 12 34 56',
        'dir': 'ltr'
    })
    
    state = SelectField('الولاية', validators=[
        DataRequired(message='الولاية مطلوبة')
    ], render_kw={
        'class': 'form-select'
    })
    
    city = StringField('المدينة/البلدية', validators=[
        DataRequired(message='المدينة مطلوبة'),
        Length(min=2, max=100)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'اسم المدينة أو البلدية'
    })
    
    street_address = StringField('العنوان', validators=[
        DataRequired(message='العنوان مطلوب'),
        Length(min=10, max=255)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'الشارع، الحي، رقم البناية...'
    })
    
    street_address_2 = StringField('تفاصيل إضافية', validators=[
        Optional(),
        Length(max=255)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'شقة، طابق، علامة مميزة... (اختياري)'
    })
    
    postal_code = StringField('الرمز البريدي', validators=[
        Optional(),
        Length(max=20)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '16000',
        'dir': 'ltr'
    })
    
    # الإحداثيات (مخفية)
    latitude = HiddenField('latitude')
    longitude = HiddenField('longitude')
    
    is_default = BooleanField('تعيين كعنوان افتراضي', render_kw={
        'class': 'form-check-input'
    })
    
    submit = SubmitField('حفظ العنوان', render_kw={
        'class': 'btn btn-dark'
    })


class CheckoutForm(FlaskForm):
    """نموذج إتمام الطلب"""
    
    # اختيار العنوان
    address_id = RadioField('عنوان التوصيل', coerce=int, validators=[
        Optional()
    ])
    
    use_new_address = BooleanField('استخدام عنوان جديد', render_kw={
        'class': 'form-check-input'
    })
    
    # العنوان الجديد
    new_full_name = StringField('الاسم الكامل', validators=[
        Optional(),
        Length(min=3, max=100)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'الاسم الكامل'
    })
    
    new_phone = StringField('رقم الهاتف', validators=[
        Optional(),
        Length(min=9, max=20)
    ], render_kw={
        'class': 'form-control',
        'placeholder': '0555 12 34 56',
        'dir': 'ltr'
    })
    
    new_state = SelectField('الولاية', validators=[
        Optional()
    ], render_kw={
        'class': 'form-select'
    })
    
    new_city = StringField('المدينة', validators=[
        Optional(),
        Length(min=2, max=100)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'المدينة'
    })
    
    new_street_address = StringField('العنوان', validators=[
        Optional(),
        Length(min=10, max=255)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'العنوان بالتفصيل'
    })
    
    new_latitude = HiddenField('latitude')
    new_longitude = HiddenField('longitude')
    
    save_address = BooleanField('حفظ العنوان للطلبات القادمة', render_kw={
        'class': 'form-check-input'
    })
    
    # طريقة الشحن
    shipping_method = RadioField('طريقة التوصيل', choices=[
        ('standard', 'توصيل عادي (2-5 أيام)'),
        ('express', 'توصيل سريع (1-2 يوم)')
    ], default='standard', render_kw={
        'class': 'form-check-input'
    })
    
    # طريقة الدفع
    payment_method = RadioField('طريقة الدفع', choices=[
        ('chargily', '💳 الدفع الإلكتروني (CIB / البطاقة الذهبية)'),
        ('cod', '💵 الدفع عند الاستلام')
    ], default='chargily', render_kw={
        'class': 'form-check-input'
    })
    
    # ملاحظات
    customer_notes = TextAreaField('ملاحظات الطلب', validators=[
        Optional(),
        Length(max=500)
    ], render_kw={
        'class': 'form-control',
        'rows': 3,
        'placeholder': 'ملاحظات إضافية للتوصيل... (اختياري)'
    })
    
    # الموافقة
    terms = BooleanField('أوافق على', validators=[
        DataRequired(message='يجب الموافقة على الشروط والأحكام')
    ], render_kw={
        'class': 'form-check-input'
    })
    
    submit = SubmitField('إتمام الطلب', render_kw={
        'class': 'btn btn-dark btn-lg w-100'
    })
    
    def validate(self, **kwargs):
        """تحقق مخصص"""
        if not super().validate(**kwargs):
            return False
        
        # التحقق من وجود عنوان
        if self.use_new_address.data:
            # التحقق من حقول العنوان الجديد
            required_fields = [
                (self.new_full_name, 'الاسم مطلوب'),
                (self.new_phone, 'رقم الهاتف مطلوب'),
                (self.new_state, 'الولاية مطلوبة'),
                (self.new_city, 'المدينة مطلوبة'),
                (self.new_street_address, 'العنوان مطلوب')
            ]
            for field, message in required_fields:
                if not field.data:
                    field.errors.append(message)
                    return False
        else:
            if not self.address_id.data:
                self.address_id.errors.append('يرجى اختيار عنوان')
                return False
        
        return True


class CouponForm(FlaskForm):
    """نموذج كوبون الخصم"""
    
    code = StringField('رمز الكوبون', validators=[
        DataRequired(message='أدخل رمز الكوبون'),
        Length(min=3, max=50)
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'SAVE20',
        'style': 'text-transform: uppercase;'
    })
    
    submit = SubmitField('تطبيق', render_kw={
        'class': 'btn btn-outline-dark'
    })