"""
======================================
🎫 Support Forms
======================================
نماذج الدعم الفني
"""

from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed, MultipleFileField
from wtforms import (
    StringField, TextAreaField, SelectField, 
    SubmitField, HiddenField
)
from wtforms.validators import DataRequired, Length, Optional


class TicketForm(FlaskForm):
    """نموذج إنشاء تذكرة دعم"""
    
    category = SelectField('نوع المشكلة', validators=[
        DataRequired(message='اختر نوع المشكلة')
    ], choices=[
        ('', 'اختر نوع المشكلة...'),
        ('order', '📦 مشكلة في الطلب'),
        ('product', '🏷️ استفسار عن منتج'),
        ('payment', '💳 مشكلة في الدفع'),
        ('shipping', '🚚 مشكلة في التوصيل'),
        ('account', '👤 مشكلة في الحساب'),
        ('other', '❓ أخرى')
    ], render_kw={
        'class': 'form-select'
    })
    
    order_id = SelectField('الطلب المتعلق', validators=[
        Optional()
    ], coerce=int, render_kw={
        'class': 'form-select'
    })
    
    subject = StringField('عنوان التذكرة', validators=[
        DataRequired(message='العنوان مطلوب'),
        Length(min=5, max=200, message='العنوان يجب أن يكون بين 5 و 200 حرف')
    ], render_kw={
        'class': 'form-control',
        'placeholder': 'عنوان مختصر للمشكلة'
    })
    
    description = TextAreaField('تفاصيل المشكلة', validators=[
        DataRequired(message='الوصف مطلوب'),
        Length(min=20, max=5000, message='الوصف يجب أن يكون بين 20 و 5000 حرف')
    ], render_kw={
        'class': 'form-control',
        'rows': 6,
        'placeholder': 'اشرح مشكلتك بالتفصيل...'
    })
    
    priority = SelectField('الأولوية', validators=[
        Optional()
    ], choices=[
        ('medium', '🟡 متوسطة'),
        ('low', '🟢 منخفضة'),
        ('high', '🟠 عالية'),
        ('urgent', '🔴 عاجلة')
    ], default='medium', render_kw={
        'class': 'form-select'
    })
    
    attachments = MultipleFileField('المرفقات', validators=[
        Optional(),
        FileAllowed(['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx'], 
                   'صور ومستندات فقط!')
    ], render_kw={
        'class': 'form-control',
        'accept': 'image/*,.pdf,.doc,.docx',
        'multiple': True
    })
    
    submit = SubmitField('إرسال التذكرة', render_kw={
        'class': 'btn btn-dark btn-lg'
    })


class TicketReplyForm(FlaskForm):
    """نموذج الرد على التذكرة"""
    
    content = TextAreaField('الرسالة', validators=[
        DataRequired(message='الرسالة مطلوبة'),
        Length(min=5, max=5000)
    ], render_kw={
        'class': 'form-control',
        'rows': 4,
        'placeholder': 'اكتب ردك هنا...'
    })
    
    attachments = MultipleFileField('المرفقات', validators=[
        Optional(),
        FileAllowed(['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx'])
    ], render_kw={
        'class': 'form-control',
        'accept': 'image/*,.pdf,.doc,.docx',
        'multiple': True
    })
    
    submit = SubmitField('إرسال', render_kw={
        'class': 'btn btn-dark'
    })


class TicketFeedbackForm(FlaskForm):
    """نموذج تقييم الدعم"""
    
    rating = HiddenField('التقييم', validators=[
        DataRequired(message='التقييم مطلوب')
    ])
    
    feedback = TextAreaField('ملاحظاتك', validators=[
        Optional(),
        Length(max=1000)
    ], render_kw={
        'class': 'form-control',
        'rows': 3,
        'placeholder': 'شاركنا رأيك في خدمة الدعم... (اختياري)'
    })
    
    submit = SubmitField('إرسال التقييم', render_kw={
        'class': 'btn btn-dark'
    })