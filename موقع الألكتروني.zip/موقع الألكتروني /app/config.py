"""
======================================
⚙️ Application Configuration
======================================
إعدادات التطبيق لجميع البيئات
"""

import os
from datetime import timedelta
from dotenv import load_dotenv

# تحميل المتغيرات البيئية
load_dotenv()


class Config:
    """الإعدادات الأساسية المشتركة"""
    
    # ==========================================
    # 🔐 Security Settings
    # ==========================================
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = 3600  # 1 hour
    
    # ==========================================
    # 🗄️ Database Settings
    # ==========================================
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///ecommerce.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = False  # SQL queries logging
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
        'pool_size': 10,
        'max_overflow': 20
    }
    
    # ==========================================
    # 📧 Email Settings (Gmail SMTP)
    # ==========================================
    MAIL_SERVER = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
    MAIL_PORT = int(os.environ.get('MAIL_PORT', 587))
    MAIL_USE_TLS = os.environ.get('MAIL_USE_TLS', 'True').lower() == 'true'
    MAIL_USE_SSL = False
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD')
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_DEFAULT_SENDER')
    MAIL_MAX_EMAILS = 50
    MAIL_ASCII_ATTACHMENTS = False
    
    # ==========================================
    # ☁️ Cloudflare R2 Settings
    # ==========================================
    R2_ACCOUNT_ID = os.environ.get('R2_ACCOUNT_ID')
    R2_ACCESS_KEY_ID = os.environ.get('R2_ACCESS_KEY_ID')
    R2_SECRET_ACCESS_KEY = os.environ.get('R2_SECRET_ACCESS_KEY')
    R2_BUCKET_NAME = os.environ.get('R2_BUCKET_NAME', 'ecommerce-images')
    R2_PUBLIC_URL = os.environ.get('R2_PUBLIC_URL')
    R2_ENDPOINT_URL = f"https://{R2_ACCOUNT_ID}.r2.cloudflarestorage.com" if R2_ACCOUNT_ID else None
    
    # الملفات المسموح بها
    ALLOWED_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
    MAX_IMAGE_SIZE = 5 * 1024 * 1024  # 5MB
    IMAGE_QUALITY = 85
    
    # ==========================================
    # 💳 Chargily Pay Settings
    # ==========================================
    CHARGILY_API_KEY = os.environ.get('CHARGILY_API_KEY')
    CHARGILY_SECRET_KEY = os.environ.get('CHARGILY_SECRET_KEY')
    CHARGILY_MODE = os.environ.get('CHARGILY_MODE', 'test')
    CHARGILY_API_URL = 'https://pay.chargily.net/api/v2'
    
    # ==========================================
    # 🔒 Admin Settings
    # ==========================================
    ADMIN_EMAIL = os.environ.get('ADMIN_EMAIL', 'om011013om@Gmail.com')
    ADMIN_DEFAULT_PASSWORD = os.environ.get('ADMIN_DEFAULT_PASSWORD', 'admin123456')
    
    # ==========================================
    # 🚀 Session & Cache Settings
    # ==========================================
    SESSION_TYPE = 'redis'
    SESSION_PERMANENT = True
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    SESSION_USE_SIGNER = True
    SESSION_KEY_PREFIX = 'ecommerce_session:'
    
    # Redis
    REDIS_URL = os.environ.get('REDIS_URL', 'redis://localhost:6379/0')
    
    # Cache
    CACHE_TYPE = 'redis'
    CACHE_DEFAULT_TIMEOUT = 300
    CACHE_KEY_PREFIX = 'ecommerce_cache:'
    
    # ==========================================
    # 🛡️ Rate Limiting
    # ==========================================
    RATELIMIT_ENABLED = True
    RATELIMIT_STORAGE_URL = os.environ.get('REDIS_URL', 'memory://')
    RATELIMIT_DEFAULT = "200 per day, 50 per hour"
    RATELIMIT_HEADERS_ENABLED = True
    
    # ==========================================
    # 🌍 Localization Settings
    # ==========================================
    BABEL_DEFAULT_LOCALE = 'ar'
    BABEL_DEFAULT_TIMEZONE = 'Africa/Algiers'
    LANGUAGES = ['ar', 'fr', 'en']
    
    # ==========================================
    # 🏪 Store Settings
    # ==========================================
    STORE_NAME = os.environ.get('APP_NAME', 'متجرنا الإلكتروني')
    STORE_CURRENCY = 'DZD'
    STORE_CURRENCY_SYMBOL = 'د.ج'
    STORE_COUNTRY = 'DZ'
    STORE_TAX_RATE = 19  # 19% TVA in Algeria
    
    # Pagination
    PRODUCTS_PER_PAGE = 12
    ORDERS_PER_PAGE = 10
    ADMIN_ITEMS_PER_PAGE = 20
    
    # ==========================================
    # 📱 SMS Settings (Optional)
    # ==========================================
    SMS_ENABLED = False
    SMS_API_KEY = os.environ.get('SMS_API_KEY')
    SMS_SENDER_ID = os.environ.get('SMS_SENDER_ID', 'STORE')
    
    # ==========================================
    # 🔧 Miscellaneous
    # ==========================================
    JSON_AS_ASCII = False  # Support Arabic in JSON
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max upload
    SEND_FILE_MAX_AGE_DEFAULT = 31536000  # 1 year cache for static files


class DevelopmentConfig(Config):
    """إعدادات بيئة التطوير"""
    DEBUG = True
    SQLALCHEMY_ECHO = True
    TEMPLATES_AUTO_RELOAD = True
    
    # Use SQLite for development
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///dev_ecommerce.db'
    
    # Disable some security features for development
    WTF_CSRF_ENABLED = True
    SESSION_TYPE = 'filesystem'


class TestingConfig(Config):
    """إعدادات بيئة الاختبار"""
    TESTING = True
    DEBUG = True
    
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    WTF_CSRF_ENABLED = False
    
    # Disable rate limiting in tests
    RATELIMIT_ENABLED = False
    
    # Use simple session
    SESSION_TYPE = 'filesystem'


class ProductionConfig(Config):
    """إعدادات بيئة الإنتاج"""
    DEBUG = False
    TESTING = False
    
    # Security headers
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # SSL
    PREFERRED_URL_SCHEME = 'https'
    
    # Stricter rate limiting
    RATELIMIT_DEFAULT = "100 per day, 30 per hour"
    
    # PostgreSQL for production
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL')
    
    @classmethod
    def init_app(cls, app):
        """تهيئة إضافية للإنتاج"""
        # Log to stderr
        import logging
        from logging import StreamHandler
        
        stream_handler = StreamHandler()
        stream_handler.setLevel(logging.INFO)
        app.logger.addHandler(stream_handler)


# قاموس الإعدادات
config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}


def get_config():
    """الحصول على الإعدادات بناءً على البيئة"""
    env = os.environ.get('FLASK_ENV', 'development')
    return config.get(env, config['default'])