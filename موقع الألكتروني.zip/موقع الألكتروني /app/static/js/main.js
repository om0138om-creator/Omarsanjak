/* ==========================================
   🚀 LUXE STORE - Main JavaScript
   ========================================== */

document.addEventListener('DOMContentLoaded', function() {
    
    // 1. إخفاء رسائل التنبيه (Flash Messages) تلقائياً بعد 5 ثوانٍ
    setTimeout(function() {
        let alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            let bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // 2. زر العودة للأعلى (Back to Top)
    const backToTopBtn = document.getElementById('backToTop');
    if (backToTopBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTopBtn.style.display = 'flex';
            } else {
                backToTopBtn.style.display = 'none';
            }
        });
        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // 3. السلة المصغرة (Mini Cart)
    const miniCartSidebar = document.getElementById('miniCartSidebar');
    const miniCartOverlay = document.getElementById('miniCartOverlay');
    const closeCartBtn = document.getElementById('miniCartClose');
    const cartToggleBtns = document.querySelectorAll('.cart-toggle'); // أزرار السلة في النافبار

    function openCart() {
        if(miniCartSidebar) miniCartSidebar.classList.add('active');
        if(miniCartOverlay) miniCartOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
        updateMiniCart(); // تحديث البيانات من السيرفر
    }

    function closeCart() {
        if(miniCartSidebar) miniCartSidebar.classList.remove('active');
        if(miniCartOverlay) miniCartOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    if (cartToggleBtns) {
        cartToggleBtns.forEach(btn => btn.addEventListener('click', function(e) {
            e.preventDefault();
            openCart();
        }));
    }
    if (closeCartBtn) closeCartBtn.addEventListener('click', closeCart);
    if (miniCartOverlay) miniCartOverlay.addEventListener('click', closeCart);

});

// 4. دالة إضافة منتج للسلة (AJAX)
function addToCart(productId, quantity = 1, variantId = null) {
    // إظهار تأثير التحميل
    const btn = event.currentTarget;
    const originalContent = btn.innerHTML;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> جاري الإضافة...';
    btn.disabled = true;

    fetch('/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': document.querySelector('meta[name="csrf-token"]')?.content || ''
        },
        body: JSON.stringify({
            product_id: productId,
            quantity: quantity,
            variant_id: variantId
        })
    })
    .then(response => response.json())
    .then(data => {
        btn.innerHTML = originalContent;
        btn.disabled = false;
        
        if (data.success) {
            // تحديث رقم السلة في النافبار
            document.querySelectorAll('.cart-count').forEach(el => el.textContent = data.cart_count);
            // فتح السلة المصغرة
            document.getElementById('miniCartSidebar').classList.add('active');
            document.getElementById('miniCartOverlay').classList.add('active');
            updateMiniCart();
        } else {
            alert(data.message || 'حدث خطأ أثناء الإضافة للسلة');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        btn.innerHTML = originalContent;
        btn.disabled = false;
    });
}

// 5. تحديث محتوى السلة المصغرة
function updateMiniCart() {
    fetch('/cart/mini')
    .then(response => response.text())
    .then(html => {
        const body = document.getElementById('miniCartBody');
        const footer = document.getElementById('miniCartFooter');
        
        // إذا رجع الكود بكلمة empty، نظهر رسالة السلة فارغة
        if(html.includes('mini-cart-empty')) {
            body.innerHTML = html;
            if(footer) footer.style.display = 'none';
        } else {
            body.innerHTML = html;
            if(footer) footer.style.display = 'block';
        }
    });
}
