"""
======================================
🏭 Application Factory
======================================
إنشاء وتهيئة تطبيق Flask
"""

import os
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime

from flask import Flask, request, g, render_template
from flask_wtf.csrf import CSRFError

from app.config import config, get_config
from app.extensions import init_extensions, db, login_manager


def create_app(config_name=None):
    """
    إنشاء وتهيئة التطبيق
    
    Args:
        config_name: اسم بيئة التشغيل (development, testing, production)
    
    Returns:
        Flask app instance
    """
    
    # إنشاء التطبيق
    app = Flask(__name__)
    
    # تحميل الإعدادات
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'development')
    
    app.config.from_object(config[config_name])
    
    # تهيئة الإضافات
    init_extensions(app)
    
    # تسجيل Blueprints
    register_blueprints(app)
    
    # تسجيل معالجات الأخطاء
    register_error_handlers(app)
    
    # تسجيل Context Processors
    register_context_processors(app)
    
    # تسجيل CLI Commands
    register_cli_commands(app)
    
    # تسجيل Before/After Request
    register_request_handlers(app)
    
    # تهيئة Logging
    configure_logging(app)
    
    # إنشاء الجداول
    with app.app_context():
        create_tables(app)
    
    return app


def register_blueprints(app):
    """تسجيل جميع الـ Blueprints"""
    
    from app.routes.main import main_bp
    from app.routes.auth import auth_bp
    from app.routes.products import products_bp
    from app.routes.cart import cart_bp
    from app.routes.orders import orders_bp
    from app.routes.payment import payment_bp
    from app.routes.admin import admin_bp
    from app.routes.support import support_bp
    from app.routes.api import api_bp
    
    # تسجيل مع URL prefix
    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(products_bp, url_prefix='/products')
    app.register_blueprint(cart_bp, url_prefix='/cart')
    app.register_blueprint(orders_bp, url_prefix='/orders')
    app.register_blueprint(payment_bp, url_prefix='/payment')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(support_bp, url_prefix='/support')
    app.register_blueprint(api_bp, url_prefix='/api/v1')


def register_error_handlers(app):
    """تسجيل معالجات الأخطاء"""
    
    @app.errorhandler(400)
    def bad_request(error):
        if request.is_json:
            return {'success': False, 'message': 'طلب غير صالح'}, 400
        return render_template('errors/400.html'), 400
    
    @app.errorhandler(403)
    def forbidden(error):
        if request.is_json:
            return {'success': False, 'message': 'غير مصرح'}, 403
        return render_template('errors/403.html'), 403
    
    @app.errorhandler(404)
    def not_found(error):
        if request.is_json:
            return {'success': False, 'message': 'غير موجود'}, 404
        return render_template('errors/404.html'), 404
    
    @app.errorhandler(429)
    def too_many_requests(error):
        if request.is_json:
            return {'success': False, 'message': 'طلبات كثيرة جداً، حاول لاحقاً'}, 429
        return render_template('errors/429.html'), 429
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        app.logger.error(f'Server Error: {error}')
        if request.is_json:
            return {'success': False, 'message': 'خطأ في الخادم'}, 500
        return render_template('errors/500.html'), 500
    
    @app.errorhandler(CSRFError)
    def csrf_error(error):
        if request.is_json:
            return {'success': False, 'message': 'انتهت صلاحية الجلسة، أعد تحميل الصفحة'}, 400
        return render_template('errors/csrf.html', reason=error.description), 400


def register_context_processors(app):
    """تسجيل Context Processors للقوالب"""
    
    @app.context_processor
    def inject_globals():
        """حقن المتغيرات العامة في جميع القوالب"""
        from app.models.settings import SiteSettings
        from app.models.category import Category
        from flask_login import current_user
        
        # إعدادات الموقع
        settings = SiteSettings.get_settings()
        
        # الفئات للقائمة
        menu_categories = Category.get_menu_categories()
        
        # عدد عناصر السلة
        cart_count = 0
        if current_user.is_authenticated and current_user.cart:
            cart_count = current_user.cart.items_count
        elif 'cart_session_id' in g:
            from app.models.cart import Cart
            cart = Cart.query.filter_by(session_id=g.cart_session_id).first()
            if cart:
                cart_count = cart.items_count
        
        # عدد الإشعارات غير المقروءة
        unread_notifications = 0
        if current_user.is_authenticated:
            unread_notifications = current_user.get_unread_notifications_count()
        
        return {
            'site_settings': settings,
            'menu_categories': menu_categories,
            'cart_count': cart_count,
            'unread_notifications': unread_notifications,
            'current_year': datetime.utcnow().year
        }
    
    @app.context_processor
    def utility_processor():
        """دوال مساعدة للقوالب"""
        
        def format_price(amount, currency='د.ج'):
            """تنسيق السعر"""
            if amount is None:
                return '0 ' + currency
            return f'{amount:,.2f} {currency}'
        
        def format_date(date, format='%Y-%m-%d'):
            """تنسيق التاريخ"""
            if date is None:
                return ''
            return date.strftime(format)
        
        def format_datetime(dt, format='%Y-%m-%d %H:%M'):
            """تنسيق التاريخ والوقت"""
            if dt is None:
                return ''
            return dt.strftime(format)
        
        def time_ago(dt):
            """الوقت المنقضي"""
            if dt is None:
                return ''
            
            now = datetime.utcnow()
            diff = now - dt
            seconds = diff.total_seconds()
            
            if seconds < 60:
                return 'الآن'
            elif seconds < 3600:
                minutes = int(seconds / 60)
                return f'منذ {minutes} دقيقة'
            elif seconds < 86400:
                hours = int(seconds / 3600)
                return f'منذ {hours} ساعة'
            elif seconds < 604800:
                days = int(seconds / 86400)
                return f'منذ {days} يوم'
            else:
                return dt.strftime('%Y-%m-%d')
        
        def truncate(text, length=100, suffix='...'):
            """اختصار النص"""
            if text is None:
                return ''
            if len(text) <= length:
                return text
            return text[:length].rsplit(' ', 1)[0] + suffix
        
        return {
            'format_price': format_price,
            'format_date': format_date,
            'format_datetime': format_datetime,
            'time_ago': time_ago,
            'truncate': truncate
        }


def register_request_handlers(app):
    """تسجيل معالجات الطلبات"""
    
    @app.before_request
    def before_request():
        """قبل كل طلب"""
        # تسجيل وقت بداية الطلب
        g.start_time = datetime.utcnow()
        
        # معرف الجلسة للسلة (للزوار)
        from flask import session
        if 'cart_session_id' not in session:
            import secrets
            session['cart_session_id'] = secrets.token_hex(16)
        g.cart_session_id = session['cart_session_id']
        
        # التحقق من وضع الصيانة
        from app.models.settings import SiteSettings
        from flask_login import current_user
        
        settings = SiteSettings.get_settings()
        if settings.maintenance_mode:
            # السماح للمشرف فقط
            if not current_user.is_authenticated or not current_user.is_admin:
                if not request.endpoint or not request.endpoint.startswith('admin'):
                    return render_template('errors/maintenance.html', 
                                         message=settings.maintenance_message), 503
    
    @app.after_request
    def after_request(response):
        """بعد كل طلب"""
        # إضافة Security Headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        
        # تسجيل وقت الاستجابة
        if hasattr(g, 'start_time'):
            elapsed = datetime.utcnow() - g.start_time
            response.headers['X-Response-Time'] = str(elapsed.total_seconds())
        
        return response


def register_cli_commands(app):
    """تسجيل أوامر CLI"""
    
    @app.cli.command('init-db')
    def init_db():
        """تهيئة قاعدة البيانات"""
        db.create_all()
        print('✅ تم إنشاء قاعدة البيانات')
    
    @app.cli.command('seed-db')
    def seed_db():
        """إضافة بيانات تجريبية"""
        from app.seeds import seed_all
        seed_all()
        print('✅ تم إضافة البيانات التجريبية')
    
    @app.cli.command('create-admin')
    def create_admin():
        """إنشاء حساب المشرف"""
        from app.models.user import User
        
        admin_email = app.config['ADMIN_EMAIL']
        admin = User.query.filter_by(email=admin_email).first()
        
        if admin:
            print(f'⚠️ المشرف موجود مسبقاً: {admin_email}')
            return
        
        admin = User(
            email=admin_email,
            phone='+213000000000',
            first_name='المشرف',
            last_name='الرئيسي',
            is_admin=True,
            email_verified=True,
            email_verified_at=datetime.utcnow()
        )
        admin.set_password(app.config['ADMIN_DEFAULT_PASSWORD'])
        
        db.session.add(admin)
        db.session.commit()
        
        print(f'✅ تم إنشاء حساب المشرف: {admin_email}')
    
    @app.cli.command('seed-wilayas')
    def seed_wilayas():
        """إضافة ولايات الجزائر"""
        from app.models.settings import ShippingZone
        ShippingZone.seed_algeria_wilayas()
        print('✅ تم إضافة الولايات الـ 58')
    
    @app.cli.command('cleanup-carts')
    def cleanup_carts():
        """حذف السلات المنتهية الصلاحية"""
        from app.models.cart import Cart
        expired = Cart.query.filter(
            Cart.expires_at < datetime.utcnow(),
            Cart.user_id.is_(None)
        ).delete()
        db.session.commit()
        print(f'✅ تم حذف {expired} سلة منتهية الصلاحية')


def configure_logging(app):
    """تهيئة نظام التسجيل"""
    
    if not app.debug and not app.testing:
        # إنشاء مجلد السجلات
        if not os.path.exists('logs'):
            os.mkdir('logs')
        
        # ملف السجل
        file_handler = RotatingFileHandler(
            'logs/ecommerce.log',
            maxBytes=10240000,  # 10MB
            backupCount=10
        )
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
        ))
        file_handler.setLevel(logging.INFO)
        app.logger.addHandler(file_handler)
        
        app.logger.setLevel(logging.INFO)
        app.logger.info('E-Commerce startup')


def create_tables(app):
    """إنشاء الجداول إذا لم تكن موجودة"""
    try:
        db.create_all()
        
        # إنشاء حساب المشرف إذا لم يكن موجوداً
        from app.models.user import User
        admin_email = app.config.get('ADMIN_EMAIL', 'om011013om@Gmail.com')
        admin = User.query.filter_by(email=admin_email).first()
        
        if not admin:
            admin = User(
                email=admin_email,
                phone='+213000000000',
                first_name='المشرف',
                last_name='الرئيسي',
                is_admin=True,
                email_verified=True,
                email_verified_at=datetime.utcnow()
            )
            admin.set_password(app.config.get('ADMIN_DEFAULT_PASSWORD', 'admin123456'))
            db.session.add(admin)
            db.session.commit()
            app.logger.info(f'Admin account created: {admin_email}')
        
        # إضافة إعدادات الموقع الافتراضية
        from app.models.settings import SiteSettings
        SiteSettings.get_settings()
        
    except Exception as e:
        app.logger.error(f'Error creating tables: {e}')