"""
======================================
🔐 Authentication Routes
======================================
مسارات المصادقة
"""

from datetime import datetime
from flask import (
    Blueprint, render_template, redirect, url_for, 
    flash, request, session, current_app
)
from flask_login import login_user, logout_user, login_required, current_user
from urllib.parse import urlparse

from app.extensions import db, limiter
from app.models.user import User
from app.models.cart import Cart
from app.models.notification import Notification
from app.forms.auth import (
    LoginForm, RegisterForm, ForgotPasswordForm,
    ResetPasswordForm, ChangePasswordForm, ProfileForm
)
from app.services.email_service import email_service
from app.utils.helpers import format_phone_number, get_client_ip

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/login', methods=['GET', 'POST'])
@limiter.limit("10 per minute")
def login():
    """تسجيل الدخول"""
    
    # إذا كان المستخدم مسجل الدخول بالفعل
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    form = LoginForm()
    
    if form.validate_on_submit():
        email = form.email.data.lower().strip()
        password = form.password.data
        
        user = User.query.filter_by(email=email).first()
        
        # التحقق من وجود المستخدم وكلمة المرور
        if user is None or not user.check_password(password):
            # تسجيل المحاولة الفاشلة
            if user:
                user.record_failed_login()
                db.session.commit()
            
            flash('البريد الإلكتروني أو كلمة المرور غير صحيحة', 'danger')
            return render_template('auth/login.html', form=form)
        
        # التحقق من قفل الحساب
        if user.is_locked():
            flash('تم قفل حسابك مؤقتاً بسبب محاولات دخول متعددة فاشلة. حاول بعد 30 دقيقة.', 'warning')
            return render_template('auth/login.html', form=form)
        
        # التحقق من الحظر
        if user.is_banned:
            flash(f'حسابك محظور. السبب: {user.ban_reason or "غير محدد"}', 'danger')
            return render_template('auth/login.html', form=form)
        
        # التحقق من تفعيل الحساب
        if not user.is_active:
            flash('حسابك غير نشط. تواصل مع الدعم.', 'warning')
            return render_template('auth/login.html', form=form)
        
        # تسجيل الدخول
        login_user(user, remember=form.remember_me.data)
        user.record_login(get_client_ip())
        db.session.commit()
        
        # دمج سلة الزائر مع سلة المستخدم
        merge_guest_cart(user)
        
        flash(f'مرحباً {user.first_name}! 👋', 'success')
        
        # التوجيه للصفحة المطلوبة أو الرئيسية
        next_page = request.args.get('next')
        if next_page and is_safe_url(next_page):
            return redirect(next_page)
        
        # توجيه المشرف للوحة التحكم
        if user.is_admin:
            return redirect(url_for('admin.dashboard'))
        
        return redirect(url_for('main.index'))
    
    return render_template('auth/login.html', form=form)


@auth_bp.route('/register', methods=['GET', 'POST'])
@limiter.limit("5 per minute")
def register():
    """التسجيل"""
    
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    form = RegisterForm()
    
    if form.validate_on_submit():
        # تنسيق رقم الهاتف
        phone = format_phone_number(form.phone.data)
        
        # إنشاء المستخدم
        user = User(
            email=form.email.data.lower().strip(),
            phone=phone,
            first_name=form.first_name.data.strip(),
            last_name=form.last_name.data.strip()
        )
        user.set_password(form.password.data)
        
        db.session.add(user)
        db.session.commit()
        
        # إرسال رابط التأكيد
        email_service.send_verification_email(user)
        
        # تسجيل الدخول تلقائياً
        login_user(user)
        
        flash('تم إنشاء حسابك بنجاح! تحقق من بريدك الإلكتروني لتأكيد الحساب.', 'success')
        return redirect(url_for('auth.unverified'))
    
    return render_template('auth/register.html', form=form)


@auth_bp.route('/logout')
@login_required
def logout():
    """تسجيل الخروج"""
    logout_user()
    flash('تم تسجيل الخروج بنجاح', 'info')
    return redirect(url_for('main.index'))


@auth_bp.route('/verify-email/<token>')
def verify_email(token):
    """تأكيد البريد الإلكتروني"""
    
    user = User.verify_email_token(token)
    
    if user is None:
        flash('رابط التأكيد غير صالح أو منتهي الصلاحية', 'danger')
        return redirect(url_for('auth.login'))
    
    if user.email_verified:
        flash('تم تأكيد بريدك الإلكتروني مسبقاً', 'info')
    else:
        user.verify_email()
        db.session.commit()
        
        # إرسال رسالة ترحيب
        email_service.send_welcome_email(user)
        
        # إضافة نقاط ولاء
        user.loyalty_points += 50
        db.session.commit()
        
        flash('تم تأكيد بريدك الإلكتروني بنجاح! 🎉', 'success')
    
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    return redirect(url_for('auth.login'))


@auth_bp.route('/unverified')
@login_required
def unverified():
    """صفحة البريد غير المؤكد"""
    
    if current_user.email_verified:
        return redirect(url_for('main.index'))
    
    return render_template('auth/unverified.html')


@auth_bp.route('/resend-verification')
@login_required
@limiter.limit("3 per hour")
def resend_verification():
    """إعادة إرسال رابط التأكيد"""
    
    if current_user.email_verified:
        flash('بريدك الإلكتروني مؤكد بالفعل', 'info')
        return redirect(url_for('main.index'))
    
    email_service.send_verification_email(current_user)
    flash('تم إرسال رابط التأكيد إلى بريدك الإلكتروني', 'success')
    
    return redirect(url_for('auth.unverified'))


@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
@limiter.limit("5 per hour")
def forgot_password():
    """نسيت كلمة المرور"""
    
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    form = ForgotPasswordForm()
    
    if form.validate_on_submit():
        email = form.email.data.lower().strip()
        user = User.query.filter_by(email=email).first()
        
        # لا نكشف إذا كان البريد موجوداً أم لا (للأمان)
        if user:
            email_service.send_password_reset_email(user)
            db.session.commit()
        
        flash('إذا كان البريد الإلكتروني مسجلاً، سيصلك رابط إعادة تعيين كلمة المرور', 'info')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/forgot_password.html', form=form)


@auth_bp.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    """إعادة تعيين كلمة المرور"""
    
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    user = User.verify_reset_token(token)
    
    if user is None:
        flash('رابط إعادة التعيين غير صالح أو منتهي الصلاحية', 'danger')
        return redirect(url_for('auth.forgot_password'))
    
    form = ResetPasswordForm()
    
    if form.validate_on_submit():
        user.set_password(form.password.data)
        user.clear_reset_token()
        db.session.commit()
        
        flash('تم تغيير كلمة المرور بنجاح! يمكنك تسجيل الدخول الآن', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/reset_password.html', form=form)


@auth_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """الملف الشخصي"""
    
    form = ProfileForm(obj=current_user)
    
    if form.validate_on_submit():
        # التحقق من تغيير رقم الهاتف
        new_phone = format_phone_number(form.phone.data)
        if new_phone != current_user.phone:
            existing = User.query.filter_by(phone=new_phone).first()
            if existing and existing.id != current_user.id:
                flash('رقم الهاتف مستخدم بالفعل', 'danger')
                return render_template('auth/profile.html', form=form)
            current_user.phone = new_phone
        
        current_user.first_name = form.first_name.data.strip()
        current_user.last_name = form.last_name.data.strip()
        current_user.date_of_birth = form.date_of_birth.data
        current_user.gender = form.gender.data
        
        db.session.commit()
        flash('تم تحديث الملف الشخصي بنجاح', 'success')
        return redirect(url_for('auth.profile'))
    
    return render_template('auth/profile.html', form=form)


@auth_bp.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    """تغيير كلمة المرور"""
    
    form = ChangePasswordForm()
    
    if form.validate_on_submit():
        # التحقق من كلمة المرور الحالية
        if not current_user.check_password(form.current_password.data):
            flash('كلمة المرور الحالية غير صحيحة', 'danger')
            return render_template('auth/change_password.html', form=form)
        
        # التحقق من أن كلمة المرور الجديدة مختلفة
        if form.current_password.data == form.new_password.data:
            flash('كلمة المرور الجديدة يجب أن تكون مختلفة عن الحالية', 'warning')
            return render_template('auth/change_password.html', form=form)
        
        current_user.set_password(form.new_password.data)
        db.session.commit()
        
        flash('تم تغيير كلمة المرور بنجاح', 'success')
        return redirect(url_for('auth.profile'))
    
    return render_template('auth/change_password.html', form=form)


@auth_bp.route('/addresses')
@login_required
def addresses():
    """عناوين المستخدم"""
    addresses = current_user.addresses.filter_by(is_active=True).all()
    return render_template('auth/addresses.html', addresses=addresses)


@auth_bp.route('/addresses/add', methods=['GET', 'POST'])
@login_required
def add_address():
    """إضافة عنوان جديد"""
    from app.forms.checkout import AddressForm
    from app.models.user import UserAddress
    from app.models.settings import ShippingZone
    
    form = AddressForm()
    
    # تحميل الولايات
    zones = ShippingZone.query.filter_by(is_active=True).order_by(ShippingZone.sort_order).all()
    form.state.choices = [(z.name_ar, z.name_ar) for z in zones]
    
    if form.validate_on_submit():
        address = UserAddress(
            user_id=current_user.id,
            label=form.label.data,
            full_name=form.full_name.data,
            phone=format_phone_number(form.phone.data),
            state=form.state.data,
            city=form.city.data,
            street_address=form.street_address.data,
            street_address_2=form.street_address_2.data,
            postal_code=form.postal_code.data,
            latitude=form.latitude.data if form.latitude.data else None,
            longitude=form.longitude.data if form.longitude.data else None
        )
        
        # تعيين كافتراضي إذا طلب أو إذا كان الأول
        if form.is_default.data or current_user.addresses.count() == 0:
            address.set_as_default()
        
        db.session.add(address)
        db.session.commit()
        
        flash('تم إضافة العنوان بنجاح', 'success')
        return redirect(url_for('auth.addresses'))
    
    return render_template('auth/address_form.html', form=form, title='إضافة عنوان جديد')


@auth_bp.route('/addresses/<int:address_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_address(address_id):
    """تعديل عنوان"""
    from app.forms.checkout import AddressForm
    from app.models.user import UserAddress
    from app.models.settings import ShippingZone
    
    address = UserAddress.query.filter_by(
        id=address_id, 
        user_id=current_user.id
    ).first_or_404()
    
    form = AddressForm(obj=address)
    
    # تحميل الولايات
    zones = ShippingZone.query.filter_by(is_active=True).order_by(ShippingZone.sort_order).all()
    form.state.choices = [(z.name_ar, z.name_ar) for z in zones]
    
    if form.validate_on_submit():
        address.label = form.label.data
        address.full_name = form.full_name.data
        address.phone = format_phone_number(form.phone.data)
        address.state = form.state.data
        address.city = form.city.data
        address.street_address = form.street_address.data
        address.street_address_2 = form.street_address_2.data
        address.postal_code = form.postal_code.data
        
        if form.latitude.data:
            address.latitude = float(form.latitude.data)
        if form.longitude.data:
            address.longitude = float(form.longitude.data)
        
        if form.is_default.data:
            address.set_as_default()
        
        db.session.commit()
        flash('تم تحديث العنوان بنجاح', 'success')
        return redirect(url_for('auth.addresses'))
    
    return render_template('auth/address_form.html', form=form, 
                          title='تعديل العنوان', address=address)


@auth_bp.route('/addresses/<int:address_id>/delete', methods=['POST'])
@login_required
def delete_address(address_id):
    """حذف عنوان"""
    from app.models.user import UserAddress
    
    address = UserAddress.query.filter_by(
        id=address_id,
        user_id=current_user.id
    ).first_or_404()
    
    address.is_active = False
    db.session.commit()
    
    flash('تم حذف العنوان', 'success')
    return redirect(url_for('auth.addresses'))


@auth_bp.route('/wishlist')
@login_required
def wishlist():
    """قائمة المفضلة"""
    items = current_user.wishlist.all()
    return render_template('auth/wishlist.html', items=items)


@auth_bp.route('/notifications')
@login_required
def notifications():
    """الإشعارات"""
    page = request.args.get('page', 1, type=int)
    notifications = current_user.notifications.order_by(
        Notification.created_at.desc()
    ).paginate(page=page, per_page=20)
    
    return render_template('auth/notifications.html', notifications=notifications)


@auth_bp.route('/notifications/mark-read', methods=['POST'])
@login_required
def mark_notifications_read():
    """تعيين الإشعارات كمقروءة"""
    current_user.notifications.filter_by(is_read=False).update({'is_read': True})
    db.session.commit()
    return {'success': True}


# ==========================================
# 🔧 Helper Functions
# ==========================================

def is_safe_url(target):
    """التحقق من أن الرابط آمن للتوجيه"""
    ref_url = urlparse(request.host_url)
    test_url = urlparse(target)
    return test_url.scheme in ('http', 'https') and ref_url.netloc == test_url.netloc


def merge_guest_cart(user):
    """دمج سلة الزائر مع سلة المستخدم"""
    guest_session_id = session.get('cart_session_id')
    if not guest_session_id:
        return
    
    guest_cart = Cart.query.filter_by(session_id=guest_session_id).first()
    if not guest_cart or guest_cart.is_empty:
        return
    
    # الحصول على سلة المستخدم أو إنشاء جديدة
    user_cart = Cart.get_or_create(user_id=user.id)
    
    # دمج السلتين
    user_cart.merge_with(guest_cart)
    db.session.commit()