"""
======================================
💳 Payment Routes
======================================
مسارات الدفع - Chargily Pay
"""

import hmac
import hashlib
from flask import (
    Blueprint, render_template, request, jsonify,
    redirect, url_for, flash, current_app, abort
)
from flask_login import login_required, current_user

from app.extensions import db, csrf
from app.models.order import Order
from app.models.notification import Notification
from app.services.payment_service import chargily_payment
from app.services.email_service import email_service
from app.utils.decorators import verified_required

payment_bp = Blueprint('payment', __name__)


@payment_bp.route('/process/<order_number>')
@login_required
@verified_required
def process(order_number):
    """بدء عملية الدفع"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first_or_404()
    
    # التحقق من حالة الطلب
    if order.payment_status == 'paid':
        flash('هذا الطلب مدفوع بالفعل', 'info')
        return redirect(url_for('orders.detail', order_number=order_number))
    
    if order.status == 'cancelled':
        flash('هذا الطلب ملغي', 'warning')
        return redirect(url_for('orders.index'))
    
    # التحقق من طريقة الدفع
    if order.payment_method != 'chargily':
        flash('طريقة الدفع غير صحيحة', 'danger')
        return redirect(url_for('orders.detail', order_number=order_number))
    
    # إنشاء جلسة الدفع
    success, result = chargily_payment.create_checkout(order)
    
    if success:
        db.session.commit()
        # توجيه المستخدم لصفحة الدفع
        return redirect(result['checkout_url'])
    else:
        current_app.logger.error(f'Chargily checkout error: {result}')
        flash('حدث خطأ في بدء عملية الدفع. يرجى المحاولة لاحقاً.', 'danger')
        return redirect(url_for('orders.detail', order_number=order_number))


@payment_bp.route('/success/<order_number>')
@login_required
def success(order_number):
    """صفحة نجاح الدفع"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first_or_404()
    
    # التحقق من حالة الدفع
    if order.chargily_checkout_id:
        success, checkout_data = chargily_payment.get_checkout(order.chargily_checkout_id)
        
        if success and checkout_data.get('status') == 'paid':
            if order.payment_status != 'paid':
                order.mark_as_paid(
                    payment_id=checkout_data.get('invoice_id'),
                    payment_details=checkout_data
                )
                order.deduct_stock()
                
                Notification.create_payment_notification(current_user.id, order, True)
                email_service.send_payment_success(order)
                db.session.commit()
    
    return render_template('payment/success.html', order=order)


@payment_bp.route('/failure/<order_number>')
@login_required
def failure(order_number):
    """صفحة فشل الدفع"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first_or_404()
    
    return render_template('payment/failure.html', order=order)


@payment_bp.route('/retry/<order_number>')
@login_required
def retry(order_number):
    """إعادة محاولة الدفع"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first_or_404()
    
    if order.payment_status == 'paid':
        flash('هذا الطلب مدفوع بالفعل', 'info')
        return redirect(url_for('orders.detail', order_number=order_number))
    
    if order.status == 'cancelled':
        flash('هذا الطلب ملغي', 'warning')
        return redirect(url_for('orders.index'))
    
    return redirect(url_for('payment.process', order_number=order_number))


@payment_bp.route('/webhook', methods=['POST'])
@csrf.exempt  # إعفاء من CSRF لأنه طلب خارجي
def webhook():
    """معالجة Webhook من Chargily"""
    
    # الحصول على التوقيع
    signature = request.headers.get('Signature')
    
    if not signature:
        current_app.logger.warning('Webhook received without signature')
        return jsonify({'error': 'Missing signature'}), 400
    
    # الحصول على البيانات الخام
    payload = request.get_data()
    
    # التحقق من التوقيع
    if not chargily_payment.verify_webhook_signature(payload, signature):
        current_app.logger.warning('Webhook signature verification failed')
        return jsonify({'error': 'Invalid signature'}), 401
    
    # معالجة البيانات
    try:
        data = request.get_json()
        success, message = chargily_payment.process_webhook(data)
        
        if success:
            return jsonify({'status': 'success', 'message': message}), 200
        else:
            return jsonify({'status': 'error', 'message': message}), 400
            
    except Exception as e:
        current_app.logger.error(f'Webhook processing error: {e}')
        return jsonify({'error': str(e)}), 500


@payment_bp.route('/status/<order_number>')
@login_required
def status(order_number):
    """التحقق من حالة الدفع (AJAX)"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first()
    
    if not order:
        return jsonify({'success': False, 'message': 'الطلب غير موجود'}), 404
    
    # التحقق من Chargily
    if order.chargily_checkout_id and order.payment_status != 'paid':
        success, checkout_data = chargily_payment.get_checkout(order.chargily_checkout_id)
        
        if success:
            chargily_status = checkout_data.get('status')
            
            if chargily_status == 'paid' and order.payment_status != 'paid':
                order.mark_as_paid(
                    payment_id=checkout_data.get('invoice_id'),
                    payment_details=checkout_data
                )
                order.deduct_stock()
                db.session.commit()
    
    return jsonify({
        'success': True,
        'payment_status': order.payment_status,
        'payment_status_label': order.payment_status_label,
        'is_paid': order.is_paid,
        'order_status': order.status,
        'order_status_label': order.status_label
    })


# ==========================================
# 💰 Payment Methods Info
# ==========================================

@payment_bp.route('/methods')
def methods():
    """صفحة طرق الدفع"""
    return render_template('payment/methods.html')


@payment_bp.route('/cod-info')
def cod_info():
    """معلومات الدفع عند الاستلام"""
    return render_template('payment/cod_info.html')