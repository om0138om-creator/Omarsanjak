"""
======================================
🔌 API Routes
======================================
نقاط نهاية الـ API
"""

from datetime import datetime
from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user
from functools import wraps

from app.extensions import db, limiter, csrf
from app.models.product import Product, ProductReview
from app.models.category import Category
from app.models.cart import Cart
from app.models.order import Order
from app.models.user import User, UserWishlist
from app.models.settings import ShippingZone, SiteSettings
from app.models.coupon import Coupon
from app.utils.decorators import admin_required

api_bp = Blueprint('api', __name__)


# ==========================================
# 🔐 API Authentication
# ==========================================

def api_login_required(f):
    """التحقق من تسجيل الدخول لـ API"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return jsonify({
                'success': False,
                'error': 'unauthorized',
                'message': 'يرجى تسجيل الدخول'
            }), 401
        return f(*args, **kwargs)
    return decorated_function


def api_admin_required(f):
    """التحقق من صلاحيات المشرف لـ API"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return jsonify({
                'success': False,
                'error': 'unauthorized',
                'message': 'يرجى تسجيل الدخول'
            }), 401
        if not current_user.is_admin:
            return jsonify({
                'success': False,
                'error': 'forbidden',
                'message': 'غير مصرح لك بالوصول'
            }), 403
        return f(*args, **kwargs)
    return decorated_function


# ==========================================
# 📦 Products API
# ==========================================

@api_bp.route('/products')
@limiter.limit("100 per minute")
def products_list():
    """قائمة المنتجات"""
    page = request.args.get('page', 1, type=int)
    per_page = min(request.args.get('per_page', 12, type=int), 100)
    
    # البحث والفلترة
    query = Product.query.filter_by(is_active=True, visibility='visible')
    
    # البحث
    search = request.args.get('q', '').strip()
    if search:
        query = query.filter(
            db.or_(
                Product.name.ilike(f'%{search}%'),
                Product.name_ar.ilike(f'%{search}%'),
                Product.description.ilike(f'%{search}%')
            )
        )
    
    # فلترة بالفئة
    category_id = request.args.get('category', type=int)
    if category_id:
        category = Category.query.get(category_id)
        if category:
            cat_ids = [category.id] + [c.id for c in category.get_all_children()]
            query = query.filter(Product.category_id.in_(cat_ids))
    
    # فلترة بالسعر
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    if min_price is not None:
        query = query.filter(Product.price >= min_price)
    if max_price is not None:
        query = query.filter(Product.price <= max_price)
    
    # فلترة بالتوفر
    if request.args.get('in_stock'):
        query = query.filter(Product.stock_quantity > 0)
    
    # فلترة بالعروض
    if request.args.get('on_sale'):
        now = datetime.utcnow()
        query = query.filter(
            Product.discount_value > 0,
            db.or_(Product.discount_start == None, Product.discount_start <= now),
            db.or_(Product.discount_end == None, Product.discount_end >= now)
        )
    
    # الترتيب
    sort = request.args.get('sort', 'newest')
    if sort == 'price_asc':
        query = query.order_by(Product.price.asc())
    elif sort == 'price_desc':
        query = query.order_by(Product.price.desc())
    elif sort == 'bestselling':
        query = query.order_by(Product.sales_count.desc())
    elif sort == 'rating':
        query = query.order_by(Product.rating_average.desc())
    elif sort == 'name':
        query = query.order_by(Product.name.asc())
    else:
        query = query.order_by(Product.created_at.desc())
    
    # التصفح
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'success': True,
        'data': {
            'products': [p.to_dict() for p in pagination.items],
            'pagination': {
                'page': pagination.page,
                'per_page': pagination.per_page,
                'total': pagination.total,
                'pages': pagination.pages,
                'has_next': pagination.has_next,
                'has_prev': pagination.has_prev
            }
        }
    })


@api_bp.route('/products/<int:product_id>')
@limiter.limit("200 per minute")
def product_detail(product_id):
    """تفاصيل منتج"""
    product = Product.query.get(product_id)
    
    if not product or not product.is_active:
        return jsonify({
            'success': False,
            'error': 'not_found',
            'message': 'المنتج غير موجود'
        }), 404
    
    return jsonify({
        'success': True,
        'data': product.to_dict(include_details=True)
    })


@api_bp.route('/products/<int:product_id>/reviews')
@limiter.limit("100 per minute")
def product_reviews(product_id):
    """تقييمات المنتج"""
    product = Product.query.get_or_404(product_id)
    
    page = request.args.get('page', 1, type=int)
    per_page = min(request.args.get('per_page', 10, type=int), 50)
    
    reviews = product.reviews.filter_by(is_approved=True).order_by(
        ProductReview.created_at.desc()
    ).paginate(page=page, per_page=per_page)
    
    return jsonify({
        'success': True,
        'data': {
            'reviews': [r.to_dict() for r in reviews.items],
            'rating_average': product.rating_average,
            'rating_count': product.rating_count,
            'pagination': {
                'page': reviews.page,
                'total': reviews.total,
                'pages': reviews.pages
            }
        }
    })


@api_bp.route('/products/featured')
@limiter.limit("100 per minute")
def products_featured():
    """المنتجات المميزة"""
    limit = min(request.args.get('limit', 8, type=int), 20)
    products = Product.get_featured(limit=limit)
    
    return jsonify({
        'success': True,
        'data': [p.to_dict() for p in products]
    })


@api_bp.route('/products/new')
@limiter.limit("100 per minute")
def products_new():
    """المنتجات الجديدة"""
    limit = min(request.args.get('limit', 8, type=int), 20)
    products = Product.get_new_arrivals(limit=limit)
    
    return jsonify({
        'success': True,
        'data': [p.to_dict() for p in products]
    })


@api_bp.route('/products/bestsellers')
@limiter.limit("100 per minute")
def products_bestsellers():
    """الأكثر مبيعاً"""
    limit = min(request.args.get('limit', 8, type=int), 20)
    products = Product.get_bestsellers(limit=limit)
    
    return jsonify({
        'success': True,
        'data': [p.to_dict() for p in products]
    })


@api_bp.route('/products/on-sale')
@limiter.limit("100 per minute")
def products_on_sale():
    """المنتجات المخفضة"""
    limit = min(request.args.get('limit', 8, type=int), 20)
    products = Product.get_on_sale(limit=limit)
    
    return jsonify({
        'success': True,
        'data': [p.to_dict() for p in products]
    })


# ==========================================
# 📁 Categories API
# ==========================================

@api_bp.route('/categories')
@limiter.limit("100 per minute")
def categories_list():
    """قائمة الفئات"""
    include_children = request.args.get('include_children', 'false').lower() == 'true'
    
    categories = Category.query.filter_by(
        parent_id=None,
        is_active=True
    ).order_by(Category.sort_order).all()
    
    return jsonify({
        'success': True,
        'data': [c.to_dict(include_children=include_children) for c in categories]
    })


@api_bp.route('/categories/<int:category_id>')
@limiter.limit("100 per minute")
def category_detail(category_id):
    """تفاصيل فئة"""
    category = Category.query.get(category_id)
    
    if not category or not category.is_active:
        return jsonify({
            'success': False,
            'error': 'not_found',
            'message': 'الفئة غير موجودة'
        }), 404
    
    return jsonify({
        'success': True,
        'data': category.to_dict(include_children=True)
    })


@api_bp.route('/categories/<int:category_id>/products')
@limiter.limit("100 per minute")
def category_products(category_id):
    """منتجات فئة"""
    category = Category.query.get_or_404(category_id)
    
    page = request.args.get('page', 1, type=int)
    per_page = min(request.args.get('per_page', 12, type=int), 100)
    
    # جمع الفئات الفرعية
    cat_ids = [category.id] + [c.id for c in category.get_all_children()]
    
    products = Product.query.filter(
        Product.category_id.in_(cat_ids),
        Product.is_active == True
    ).order_by(Product.created_at.desc()).paginate(page=page, per_page=per_page)
    
    return jsonify({
        'success': True,
        'data': {
            'category': category.to_dict(),
            'products': [p.to_dict() for p in products.items],
            'pagination': {
                'page': products.page,
                'total': products.total,
                'pages': products.pages
            }
        }
    })


# ==========================================
# 🛒 Cart API
# ==========================================

@api_bp.route('/cart')
def cart_get():
    """الحصول على السلة"""
    from flask import session, g
    
    if current_user.is_authenticated:
        cart = Cart.get_or_create(user_id=current_user.id)
    else:
        session_id = session.get('cart_session_id')
        if not session_id:
            return jsonify({
                'success': True,
                'data': {'items': [], 'total': 0, 'items_count': 0}
            })
        cart = Cart.get_or_create(session_id=session_id)
    
    if not cart:
        return jsonify({
            'success': True,
            'data': {'items': [], 'total': 0, 'items_count': 0}
        })
    
    return jsonify({
        'success': True,
        'data': cart.to_dict()
    })


@api_bp.route('/cart/add', methods=['POST'])
@csrf.exempt
@limiter.limit("30 per minute")
def cart_add():
    """إضافة للسلة"""
    from flask import session
    
    data = request.get_json()
    product_id = data.get('product_id')
    quantity = data.get('quantity', 1)
    variant_id = data.get('variant_id')
    
    if not product_id:
        return jsonify({
            'success': False,
            'message': 'المنتج مطلوب'
        }), 400
    
    product = Product.query.get(product_id)
    if not product or not product.is_active:
        return jsonify({
            'success': False,
            'message': 'المنتج غير متاح'
        }), 404
    
    # الحصول على السلة
    if current_user.is_authenticated:
        cart = Cart.get_or_create(user_id=current_user.id)
    else:
        session_id = session.get('cart_session_id')
        if not session_id:
            import secrets
            session_id = secrets.token_hex(16)
            session['cart_session_id'] = session_id
        cart = Cart.get_or_create(session_id=session_id)
    
    success, error = cart.add_item(product, quantity, variant_id)
    
    if not success:
        return jsonify({
            'success': False,
            'message': error
        }), 400
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'تمت الإضافة للسلة',
        'data': {
            'cart_count': cart.items_count,
            'cart_total': cart.total
        }
    })


@api_bp.route('/cart/update', methods=['POST'])
@csrf.exempt
@limiter.limit("30 per minute")
def cart_update():
    """تحديث السلة"""
    from flask import session
    
    data = request.get_json()
    item_id = data.get('item_id')
    quantity = data.get('quantity')
    
    if not item_id or quantity is None:
        return jsonify({
            'success': False,
            'message': 'بيانات غير مكتملة'
        }), 400
    
    # الحصول على السلة
    if current_user.is_authenticated:
        cart = Cart.query.filter_by(user_id=current_user.id).first()
    else:
        session_id = session.get('cart_session_id')
        cart = Cart.query.filter_by(session_id=session_id).first() if session_id else None
    
    if not cart:
        return jsonify({
            'success': False,
            'message': 'السلة فارغة'
        }), 400
    
    success, error = cart.update_item_quantity(item_id, quantity)
    
    if not success:
        return jsonify({
            'success': False,
            'message': error
        }), 400
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'تم التحديث',
        'data': cart.to_dict()
    })


@api_bp.route('/cart/remove', methods=['POST'])
@csrf.exempt
@limiter.limit("30 per minute")
def cart_remove():
    """إزالة من السلة"""
    from flask import session
    
    data = request.get_json()
    item_id = data.get('item_id')
    
    if not item_id:
        return jsonify({
            'success': False,
            'message': 'العنصر مطلوب'
        }), 400
    
    # الحصول على السلة
    if current_user.is_authenticated:
        cart = Cart.query.filter_by(user_id=current_user.id).first()
    else:
        session_id = session.get('cart_session_id')
        cart = Cart.query.filter_by(session_id=session_id).first() if session_id else None
    
    if not cart:
        return jsonify({
            'success': False,
            'message': 'السلة فارغة'
        }), 400
    
    success, error = cart.remove_item(item_id)
    db.session.commit()
    
    return jsonify({
        'success': success,
        'message': 'تمت الإزالة' if success else error,
        'data': cart.to_dict()
    })


# ==========================================
# 🏷️ Coupons API
# ==========================================

@api_bp.route('/coupons/validate', methods=['POST'])
@csrf.exempt
@limiter.limit("10 per minute")
def coupon_validate():
    """التحقق من كوبون"""
    data = request.get_json()
    code = data.get('code', '').strip().upper()
    
    if not code:
        return jsonify({
            'success': False,
            'message': 'أدخل رمز الكوبون'
        }), 400
    
    coupon = Coupon.query.filter_by(code=code).first()
    
    if not coupon:
        return jsonify({
            'success': False,
            'message': 'الكوبون غير موجود'
        }), 404
    
    if not coupon.is_valid():
        return jsonify({
            'success': False,
            'message': 'الكوبون غير صالح أو منتهي'
        }), 400
    
    return jsonify({
        'success': True,
        'data': coupon.to_dict()
    })


# ==========================================
# 🚚 Shipping API
# ==========================================

@api_bp.route('/shipping/zones')
@limiter.limit("100 per minute")
def shipping_zones_list():
    """قائمة مناطق الشحن"""
    zones = ShippingZone.query.filter_by(is_active=True).order_by(
        ShippingZone.sort_order
    ).all()
    
    return jsonify({
        'success': True,
        'data': [z.to_dict() for z in zones]
    })


@api_bp.route('/shipping/calculate', methods=['POST'])
@csrf.exempt
@limiter.limit("30 per minute")
def shipping_calculate():
    """حساب تكلفة الشحن"""
    data = request.get_json()
    zone_id = data.get('zone_id')
    subtotal = data.get('subtotal', 0)
    is_express = data.get('express', False)
    
    if not zone_id:
        return jsonify({
            'success': False,
            'message': 'المنطقة مطلوبة'
        }), 400
    
    zone = ShippingZone.query.get(zone_id)
    if not zone or not zone.is_active:
        return jsonify({
            'success': False,
            'message': 'المنطقة غير متاحة'
        }), 404
    
    shipping_cost = zone.get_shipping_cost(subtotal, is_express)
    
    return jsonify({
        'success': True,
        'data': {
            'zone': zone.to_dict(),
            'shipping_cost': shipping_cost,
            'is_free': shipping_cost == 0,
            'delivery_estimate': zone.delivery_estimate if not is_express else f'{zone.express_days} يوم'
        }
    })


# ==========================================
# 👤 User API
# ==========================================

@api_bp.route('/user/profile')
@api_login_required
def user_profile():
    """الملف الشخصي"""
    return jsonify({
        'success': True,
        'data': current_user.to_dict(include_sensitive=True)
    })


@api_bp.route('/user/orders')
@api_login_required
def user_orders():
    """طلبات المستخدم"""
    page = request.args.get('page', 1, type=int)
    per_page = min(request.args.get('per_page', 10, type=int), 50)
    
    orders = current_user.orders.order_by(
        Order.created_at.desc()
    ).paginate(page=page, per_page=per_page)
    
    return jsonify({
        'success': True,
        'data': {
            'orders': [o.to_dict() for o in orders.items],
            'pagination': {
                'page': orders.page,
                'total': orders.total,
                'pages': orders.pages
            }
        }
    })


@api_bp.route('/user/wishlist')
@api_login_required
def user_wishlist():
    """قائمة المفضلة"""
    items = current_user.wishlist.all()
    
    return jsonify({
        'success': True,
        'data': [{
            'id': item.id,
            'product': item.product.to_dict() if item.product else None,
            'added_at': item.created_at.isoformat()
        } for item in items]
    })


@api_bp.route('/user/wishlist/toggle', methods=['POST'])
@api_login_required
@csrf.exempt
def user_wishlist_toggle():
    """إضافة/إزالة من المفضلة"""
    data = request.get_json()
    product_id = data.get('product_id')
    
    if not product_id:
        return jsonify({
            'success': False,
            'message': 'المنتج مطلوب'
        }), 400
    
    existing = UserWishlist.query.filter_by(
        user_id=current_user.id,
        product_id=product_id
    ).first()
    
    if existing:
        db.session.delete(existing)
        action = 'removed'
    else:
        item = UserWishlist(user_id=current_user.id, product_id=product_id)
        db.session.add(item)
        action = 'added'
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'action': action,
        'message': 'تمت الإضافة للمفضلة' if action == 'added' else 'تمت الإزالة من المفضلة'
    })


# ==========================================
# 🔍 Search API
# ==========================================

@api_bp.route('/search')
@limiter.limit("60 per minute")
def search():
    """البحث"""
    query = request.args.get('q', '').strip()
    
    if len(query) < 2:
        return jsonify({
            'success': True,
            'data': {'products': [], 'categories': []}
        })
    
    # البحث في المنتجات
    products = Product.query.filter(
        Product.is_active == True,
        db.or_(
            Product.name.ilike(f'%{query}%'),
            Product.name_ar.ilike(f'%{query}%'),
            Product.sku.ilike(f'%{query}%')
        )
    ).limit(10).all()
    
    # البحث في الفئات
    categories = Category.query.filter(
        Category.is_active == True,
        db.or_(
            Category.name.ilike(f'%{query}%'),
            Category.name_ar.ilike(f'%{query}%')
        )
    ).limit(5).all()
    
    return jsonify({
        'success': True,
        'data': {
            'products': [p.to_dict() for p in products],
            'categories': [c.to_dict() for c in categories]
        }
    })


# ==========================================
# ⚙️ Settings API
# ==========================================

@api_bp.route('/settings')
@limiter.limit("100 per minute")
def settings():
    """إعدادات الموقع"""
    site_settings = SiteSettings.get_settings()
    
    return jsonify({
        'success': True,
        'data': site_settings.to_dict()
    })


# ==========================================
# 📊 Admin API
# ==========================================

@api_bp.route('/admin/stats')
@api_admin_required
def admin_stats():
    """إحصائيات المشرف"""
    from app.services.analytics_service import AnalyticsService
    
    stats = AnalyticsService.get_dashboard_stats()
    
    return jsonify({
        'success': True,
        'data': stats
    })


@api_bp.route('/admin/orders/recent')
@api_admin_required
def admin_recent_orders():
    """أحدث الطلبات"""
    limit = min(request.args.get('limit', 10, type=int), 50)
    
    orders = Order.query.order_by(
        Order.created_at.desc()
    ).limit(limit).all()
    
    return jsonify({
        'success': True,
        'data': [o.to_dict() for o in orders]
    })


@api_bp.route('/admin/products/low-stock')
@api_admin_required
def admin_low_stock():
    """المنتجات منخفضة المخزون"""
    products = Product.query.filter(
        Product.is_active == True,
        Product.track_inventory == True,
        Product.stock_quantity <= Product.low_stock_threshold
    ).order_by(Product.stock_quantity.asc()).limit(20).all()
    
    return jsonify({
        'success': True,
        'data': [p.to_dict() for p in products]
    })


# ==========================================
# 🔔 Health Check
# ==========================================

@api_bp.route('/health')
def health_check():
    """فحص صحة الـ API"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0'
    })