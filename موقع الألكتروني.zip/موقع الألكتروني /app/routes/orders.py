"""
======================================
📋 Orders Routes
======================================
مسارات الطلبات
"""

from datetime import datetime
from flask import (
    Blueprint, render_template, request, jsonify,
    redirect, url_for, flash, current_app, abort
)
from flask_login import login_required, current_user

from app.extensions import db
from app.models.order import Order, OrderItem, OrderStatusHistory
from app.models.cart import Cart
from app.models.user import UserAddress
from app.models.settings import ShippingZone, SiteSettings
from app.models.coupon import Coupon
from app.models.notification import Notification
from app.forms.checkout import CheckoutForm, AddressForm
from app.services.email_service import email_service
from app.utils.decorators import verified_required
from app.utils.helpers import format_phone_number, get_client_ip

orders_bp = Blueprint('orders', __name__)


@orders_bp.route('/')
@login_required
def index():
    """قائمة طلبات المستخدم"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '')
    
    query = current_user.orders
    
    if status:
        query = query.filter_by(status=status)
    
    orders = query.order_by(Order.created_at.desc()).paginate(
        page=page,
        per_page=current_app.config.get('ORDERS_PER_PAGE', 10)
    )
    
    return render_template('orders/index.html', orders=orders, current_status=status)


@orders_bp.route('/<order_number>')
@login_required
def detail(order_number):
    """تفاصيل الطلب"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first_or_404()
    
    return render_template('orders/detail.html', order=order)


@orders_bp.route('/<order_number>/track')
@login_required
def track(order_number):
    """تتبع الطلب"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first_or_404()
    
    # سجل الحالات
    history = order.status_history.order_by(OrderStatusHistory.created_at.asc()).all()
    
    return render_template('orders/track.html', order=order, history=history)


@orders_bp.route('/<order_number>/cancel', methods=['POST'])
@login_required
def cancel(order_number):
    """إلغاء الطلب"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first_or_404()
    
    if not order.can_cancel:
        if request.is_json:
            return jsonify({'success': False, 'message': 'لا يمكن إلغاء هذا الطلب'}), 400
        flash('لا يمكن إلغاء هذا الطلب', 'danger')
        return redirect(url_for('orders.detail', order_number=order_number))
    
    reason = request.form.get('reason', request.json.get('reason', '') if request.is_json else '')
    
    success, message = order.update_status(
        'cancelled',
        user_id=current_user.id,
        notes=reason
    )
    
    if success:
        db.session.commit()
        
        # إرسال إشعار وبريد
        Notification.create_order_notification(current_user.id, order, 'cancelled')
        email_service.send_order_cancelled(order)
        db.session.commit()
    
    if request.is_json:
        return jsonify({'success': success, 'message': message})
    
    if success:
        flash('تم إلغاء الطلب بنجاح', 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('orders.detail', order_number=order_number))


@orders_bp.route('/<order_number>/reorder', methods=['POST'])
@login_required
def reorder(order_number):
    """إعادة الطلب"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first_or_404()
    
    # الحصول على سلة المستخدم
    cart = Cart.get_or_create(user_id=current_user.id)
    
    # إضافة منتجات الطلب للسلة
    added_count = 0
    errors = []
    
    for item in order.items:
        if item.product and item.product.is_active:
            success, error = cart.add_item(item.product, item.quantity, item.variant_id)
            if success:
                added_count += 1
            else:
                errors.append(f'{item.product_name}: {error}')
    
    db.session.commit()
    
    if request.is_json:
        return jsonify({
            'success': added_count > 0,
            'message': f'تمت إضافة {added_count} منتج للسلة',
            'errors': errors
        })
    
    if added_count > 0:
        flash(f'تمت إضافة {added_count} منتج للسلة', 'success')
    if errors:
        for error in errors:
            flash(error, 'warning')
    
    return redirect(url_for('cart.index'))


@orders_bp.route('/<order_number>/invoice')
@login_required
def invoice(order_number):
    """فاتورة الطلب"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first_or_404()
    
    settings = SiteSettings.get_settings()
    
    return render_template('orders/invoice.html', order=order, settings=settings)


# ==========================================
# 🛒 Checkout Process
# ==========================================

@orders_bp.route('/checkout', methods=['GET', 'POST'])
@login_required
@verified_required
def checkout():
    """صفحة إتمام الطلب"""
    
    # الحصول على السلة
    cart = Cart.get_or_create(user_id=current_user.id)
    
    if not cart or cart.is_empty:
        flash('السلة فارغة', 'warning')
        return redirect(url_for('cart.index'))
    
    # التحقق من صلاحية المنتجات
    issues = cart.validate_items()
    if issues:
        flash('بعض المنتجات في سلتك غير متوفرة حالياً', 'warning')
        return redirect(url_for('cart.index'))
    
    # تحديث الأسعار
    cart.refresh_prices()
    
    # الحصول على العناوين
    addresses = current_user.addresses.filter_by(is_active=True).all()
    
    # مناطق الشحن
    shipping_zones = ShippingZone.query.filter_by(
        is_active=True
    ).order_by(ShippingZone.sort_order).all()
    
    # إعداد النموذج
    form = CheckoutForm()
    
    # خيارات العنوان
    form.address_id.choices = [(a.id, a.full_address) for a in addresses]
    form.new_state.choices = [('', 'اختر الولاية...')] + [
        (z.name_ar, z.name_ar) for z in shipping_zones
    ]
    
    if form.validate_on_submit():
        return process_checkout(form, cart, shipping_zones)
    
    # تحديد العنوان الافتراضي
    default_address = current_user.get_default_address()
    if default_address:
        form.address_id.data = default_address.id
    
    # الإعدادات
    settings = SiteSettings.get_settings()
    
    return render_template('orders/checkout.html',
        form=form,
        cart=cart,
        addresses=addresses,
        shipping_zones=shipping_zones,
        settings=settings
    )


def process_checkout(form, cart, shipping_zones):
    """معالجة الطلب"""
    
    # تحديد العنوان
    if form.use_new_address.data:
        # عنوان جديد
        shipping_name = form.new_full_name.data
        shipping_phone = format_phone_number(form.new_phone.data)
        shipping_state = form.new_state.data
        shipping_city = form.new_city.data
        shipping_street = form.new_street_address.data
        shipping_lat = form.new_latitude.data
        shipping_lng = form.new_longitude.data
        
        # حفظ العنوان إذا طلب
        if form.save_address.data:
            new_address = UserAddress(
                user_id=current_user.id,
                full_name=shipping_name,
                phone=shipping_phone,
                state=shipping_state,
                city=shipping_city,
                street_address=shipping_street,
                latitude=shipping_lat if shipping_lat else None,
                longitude=shipping_lng if shipping_lng else None
            )
            db.session.add(new_address)
    else:
        # عنوان موجود
        address = UserAddress.query.filter_by(
            id=form.address_id.data,
            user_id=current_user.id
        ).first()
        
        if not address:
            flash('العنوان غير موجود', 'danger')
            return redirect(url_for('orders.checkout'))
        
        shipping_name = address.full_name
        shipping_phone = address.phone
        shipping_state = address.state
        shipping_city = address.city
        shipping_street = address.street_address
        shipping_lat = address.latitude
        shipping_lng = address.longitude
    
    # الحصول على منطقة الشحن
    shipping_zone = ShippingZone.query.filter_by(name_ar=shipping_state).first()
    if not shipping_zone:
        shipping_zone = shipping_zones[0] if shipping_zones else None
    
    # حساب تكلفة الشحن
    is_express = form.shipping_method.data == 'express'
    shipping_cost = 0
    if shipping_zone:
        shipping_cost = shipping_zone.get_shipping_cost(cart.subtotal, is_express)
    
    # حساب الضرائب
    settings = SiteSettings.get_settings()
    tax_amount = 0
    if settings.tax_enabled and not settings.tax_included_in_price:
        tax_amount = cart.subtotal * (float(settings.tax_rate) / 100)
    
    # المجموع النهائي
    total_amount = cart.subtotal - float(cart.coupon_discount or 0) + shipping_cost + tax_amount
    
    # إنشاء الطلب
    order = Order(
        user_id=current_user.id,
        
        # التسعير
        subtotal=cart.subtotal,
        discount_amount=cart.coupon_discount or 0,
        shipping_amount=shipping_cost,
        tax_amount=tax_amount,
        total_amount=total_amount,
        
        # الكوبون
        coupon_id=cart.coupon_id,
        coupon_code=cart.coupon_code,
        
        # العنوان
        shipping_name=shipping_name,
        shipping_phone=shipping_phone,
        shipping_state=shipping_state,
        shipping_city=shipping_city,
        shipping_street=shipping_street,
        shipping_latitude=shipping_lat,
        shipping_longitude=shipping_lng,
        
        # الشحن
        shipping_method=form.shipping_method.data,
        shipping_zone_id=shipping_zone.id if shipping_zone else None,
        
        # الدفع
        payment_method=form.payment_method.data,
        
        # ملاحظات
        customer_notes=form.customer_notes.data,
        
        # معلومات إضافية
        ip_address=get_client_ip(),
        user_agent=request.user_agent.string[:500] if request.user_agent.string else None
    )
    
    db.session.add(order)
    db.session.flush()  # للحصول على ID
    
    # إضافة عناصر الطلب
    for cart_item in cart.items:
        order_item = OrderItem(
            order_id=order.id,
            product_id=cart_item.product_id,
            variant_id=cart_item.variant_id,
            quantity=cart_item.quantity,
            unit_price=cart_item.unit_price,
            original_price=cart_item.original_price,
            discount_amount=cart_item.discount_amount,
            total_price=cart_item.total_price
        )
        db.session.add(order_item)
    
    # تسجيل استخدام الكوبون
    if cart.coupon_id:
        coupon = Coupon.query.get(cart.coupon_id)
        if coupon:
            coupon.record_usage(current_user.id, order.id, cart.coupon_discount)
    
    # إضافة سجل الحالة
    history = OrderStatusHistory(
        order_id=order.id,
        new_status='pending',
        notes='تم إنشاء الطلب'
    )
    db.session.add(history)
    
    # تفريغ السلة
    cart.clear()
    
    db.session.commit()
    
    # إرسال الإشعارات
    Notification.create_order_notification(current_user.id, order, 'new')
    email_service.send_order_confirmation(order)
    email_service.send_admin_new_order(order)
    db.session.commit()
    
    # التوجيه حسب طريقة الدفع
    if order.payment_method == 'chargily':
        return redirect(url_for('payment.process', order_number=order.order_number))
    else:
        # الدفع عند الاستلام
        flash('تم استلام طلبك بنجاح! سنتواصل معك قريباً.', 'success')
        return redirect(url_for('orders.confirmation', order_number=order.order_number))


@orders_bp.route('/<order_number>/confirmation')
@login_required
def confirmation(order_number):
    """صفحة تأكيد الطلب"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first_or_404()
    
    return render_template('orders/confirmation.html', order=order)


# ==========================================
# 📊 API Endpoints
# ==========================================

@orders_bp.route('/api/<order_number>')
@login_required
def api_detail(order_number):
    """API تفاصيل الطلب"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first()
    
    if not order:
        return jsonify({'success': False, 'message': 'الطلب غير موجود'}), 404
    
    return jsonify({
        'success': True,
        'order': order.to_dict(include_items=True, include_history=True)
    })


@orders_bp.route('/api/<order_number>/status')
@login_required
def api_status(order_number):
    """API حالة الطلب"""
    order = Order.query.filter_by(
        order_number=order_number,
        user_id=current_user.id
    ).first()
    
    if not order:
        return jsonify({'success': False, 'message': 'الطلب غير موجود'}), 404
    
    return jsonify({
        'success': True,
        'status': order.status,
        'status_label': order.status_label,
        'status_color': order.status_color,
        'payment_status': order.payment_status,
        'payment_status_label': order.payment_status_label,
        'tracking_number': order.tracking_number,
        'estimated_delivery': order.estimated_delivery.isoformat() if order.estimated_delivery else None
    })