"""
======================================
🎫 Support Routes
======================================
مسارات الدعم الفني
"""

from datetime import datetime
from flask import (
    Blueprint, render_template, request, jsonify,
    redirect, url_for, flash, current_app
)
from flask_login import login_required, current_user

from app.extensions import db
from app.models.ticket import Ticket, TicketMessage
from app.models.order import Order
from app.models.notification import Notification
from app.forms.support import TicketForm, TicketReplyForm, TicketFeedbackForm
from app.services.email_service import email_service
from app.services.storage_service import storage_service

support_bp = Blueprint('support', __name__)


@support_bp.route('/')
@login_required
def index():
    """قائمة تذاكر الدعم"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '')
    
    query = current_user.tickets
    
    if status == 'open':
        query = query.filter(Ticket.status.in_(['open', 'in_progress', 'waiting_customer']))
    elif status == 'closed':
        query = query.filter(Ticket.status.in_(['resolved', 'closed']))
    
    tickets = query.order_by(Ticket.updated_at.desc()).paginate(
        page=page,
        per_page=10
    )
    
    return render_template('support/index.html', tickets=tickets, current_status=status)


@support_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    """إنشاء تذكرة جديدة"""
    form = TicketForm()
    
    # تحميل طلبات المستخدم
    orders = current_user.orders.order_by(Order.created_at.desc()).limit(10).all()
    form.order_id.choices = [('', 'اختر طلب... (اختياري)')] + [
        (o.id, f'#{o.order_number} - {o.created_at.strftime("%Y-%m-%d")}')
        for o in orders
    ]
    
    if form.validate_on_submit():
        # إنشاء التذكرة
        ticket = Ticket(
            user_id=current_user.id,
            category=form.category.data,
            subject=form.subject.data,
            description=form.description.data,
            priority=form.priority.data,
            order_id=form.order_id.data if form.order_id.data else None
        )
        
        db.session.add(ticket)
        db.session.flush()
        
        # رفع المرفقات
        attachments = []
        if form.attachments.data:
            for file in form.attachments.data:
                if file and file.filename:
                    result = storage_service.upload_image(
                        file,
                        folder=f'tickets/{ticket.id}',
                        create_thumbnail=False
                    )
                    if result['success']:
                        attachments.append(result['url'])
        
        # إضافة الرسالة الأولى
        message = TicketMessage(
            ticket_id=ticket.id,
            user_id=current_user.id,
            content=form.description.data,
            attachments=attachments if attachments else None
        )
        db.session.add(message)
        
        db.session.commit()
        
        # إشعار المشرف
        email_service.send_admin_new_ticket(ticket)
        
        flash('تم إرسال تذكرتك بنجاح. سنرد عليك قريباً.', 'success')
        return redirect(url_for('support.detail', ticket_number=ticket.ticket_number))
    
    return render_template('support/create.html', form=form)


@support_bp.route('/<ticket_number>')
@login_required
def detail(ticket_number):
    """تفاصيل التذكرة"""
    ticket = Ticket.query.filter_by(
        ticket_number=ticket_number,
        user_id=current_user.id
    ).first_or_404()
    
    # تعيين الرسائل كمقروءة
    ticket.messages.filter_by(
        is_admin_reply=True,
        is_read=False
    ).update({'is_read': True, 'read_at': datetime.utcnow()})
    db.session.commit()
    
    # نموذج الرد
    reply_form = TicketReplyForm()
    
    # نموذج التقييم
    feedback_form = None
    if ticket.status in ['resolved', 'closed'] and not ticket.satisfaction_rating:
        feedback_form = TicketFeedbackForm()
    
    return render_template('support/detail.html',
        ticket=ticket,
        reply_form=reply_form,
        feedback_form=feedback_form
    )


@support_bp.route('/<ticket_number>/reply', methods=['POST'])
@login_required
def reply(ticket_number):
    """الرد على التذكرة"""
    ticket = Ticket.query.filter_by(
        ticket_number=ticket_number,
        user_id=current_user.id
    ).first_or_404()
    
    # التحقق من أن التذكرة مفتوحة
    if not ticket.is_open:
        flash('لا يمكن الرد على تذكرة مغلقة', 'warning')
        return redirect(url_for('support.detail', ticket_number=ticket_number))
    
    form = TicketReplyForm()
    
    if form.validate_on_submit():
        # رفع المرفقات
        attachments = []
        if form.attachments.data:
            for file in form.attachments.data:
                if file and file.filename:
                    result = storage_service.upload_image(
                        file,
                        folder=f'tickets/{ticket.id}',
                        create_thumbnail=False
                    )
                    if result['success']:
                        attachments.append(result['url'])
        
        # إضافة الرسالة
        ticket.add_message(
            user_id=current_user.id,
            content=form.content.data,
            is_admin=False,
            attachments=attachments if attachments else None
        )
        
        db.session.commit()
        
        flash('تم إرسال ردك بنجاح', 'success')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(error, 'danger')
    
    return redirect(url_for('support.detail', ticket_number=ticket_number))


@support_bp.route('/<ticket_number>/close', methods=['POST'])
@login_required
def close(ticket_number):
    """إغلاق التذكرة"""
    ticket = Ticket.query.filter_by(
        ticket_number=ticket_number,
        user_id=current_user.id
    ).first_or_404()
    
    if not ticket.is_open:
        flash('التذكرة مغلقة بالفعل', 'info')
        return redirect(url_for('support.detail', ticket_number=ticket_number))
    
    ticket.update_status('closed', current_user.id)
    db.session.commit()
    
    flash('تم إغلاق التذكرة', 'success')
    return redirect(url_for('support.detail', ticket_number=ticket_number))


@support_bp.route('/<ticket_number>/reopen', methods=['POST'])
@login_required
def reopen(ticket_number):
    """إعادة فتح التذكرة"""
    ticket = Ticket.query.filter_by(
        ticket_number=ticket_number,
        user_id=current_user.id
    ).first_or_404()
    
    if ticket.status not in ['resolved', 'closed']:
        flash('التذكرة مفتوحة بالفعل', 'info')
        return redirect(url_for('support.detail', ticket_number=ticket_number))
    
    ticket.update_status('open', current_user.id)
    ticket.resolved_at = None
    ticket.closed_at = None
    db.session.commit()
    
    flash('تم إعادة فتح التذكرة', 'success')
    return redirect(url_for('support.detail', ticket_number=ticket_number))


@support_bp.route('/<ticket_number>/feedback', methods=['POST'])
@login_required
def feedback(ticket_number):
    """تقييم خدمة الدعم"""
    ticket = Ticket.query.filter_by(
        ticket_number=ticket_number,
        user_id=current_user.id
    ).first_or_404()
    
    if ticket.satisfaction_rating:
        flash('لقد قمت بتقييم هذه التذكرة مسبقاً', 'info')
        return redirect(url_for('support.detail', ticket_number=ticket_number))
    
    form = TicketFeedbackForm()
    
    if form.validate_on_submit():
        ticket.satisfaction_rating = int(form.rating.data)
        ticket.feedback = form.feedback.data
        db.session.commit()
        
        flash('شكراً لتقييمك!', 'success')
    else:
        flash('حدث خطأ في إرسال التقييم', 'danger')
    
    return redirect(url_for('support.detail', ticket_number=ticket_number))


# ==========================================
# 📖 Help Center
# ==========================================

@support_bp.route('/help')
def help_center():
    """مركز المساعدة"""
    return render_template('support/help_center.html')


@support_bp.route('/help/<slug>')
def help_article(slug):
    """مقالة مساعدة"""
    # يمكن إضافة نموذج للمقالات لاحقاً
    articles = {
        'how-to-order': {
            'title': 'كيفية الطلب',
            'content': 'محتوى المقالة...'
        },
        'payment-methods': {
            'title': 'طرق الدفع',
            'content': 'محتوى المقالة...'
        },
        'shipping-info': {
            'title': 'معلومات الشحن',
            'content': 'محتوى المقالة...'
        },
        'returns': {
            'title': 'سياسة الاسترجاع',
            'content': 'محتوى المقالة...'
        }
    }
    
    article = articles.get(slug)
    if not article:
        abort(404)
    
    return render_template('support/help_article.html', article=article, slug=slug)


# ==========================================
# 📱 Live Chat (Optional)
# ==========================================

@support_bp.route('/chat')
@login_required
def chat():
    """الدردشة المباشرة"""
    # يمكن دمج خدمة دردشة مثل Tawk.to أو Crisp
    return render_template('support/chat.html')


# ==========================================
# 📊 API Endpoints
# ==========================================

@support_bp.route('/api/tickets')
@login_required
def api_tickets():
    """API قائمة التذاكر"""
    tickets = current_user.tickets.order_by(Ticket.updated_at.desc()).limit(10).all()
    
    return jsonify({
        'success': True,
        'tickets': [t.to_dict() for t in tickets]
    })


@support_bp.route('/api/tickets/<ticket_number>')
@login_required
def api_ticket_detail(ticket_number):
    """API تفاصيل التذكرة"""
    ticket = Ticket.query.filter_by(
        ticket_number=ticket_number,
        user_id=current_user.id
    ).first()
    
    if not ticket:
        return jsonify({'success': False, 'message': 'التذكرة غير موجودة'}), 404
    
    return jsonify({
        'success': True,
        'ticket': ticket.to_dict(include_messages=True)
    })


@support_bp.route('/api/tickets/<ticket_number>/messages')
@login_required
def api_ticket_messages(ticket_number):
    """API رسائل التذكرة"""
    ticket = Ticket.query.filter_by(
        ticket_number=ticket_number,
        user_id=current_user.id
    ).first()
    
    if not ticket:
        return jsonify({'success': False, 'message': 'التذكرة غير موجودة'}), 404
    
    messages = ticket.messages.filter_by(is_internal_note=False).all()
    
    return jsonify({
        'success': True,
        'messages': [m.to_dict() for m in messages]
    })


@support_bp.route('/api/unread-count')
@login_required
def api_unread_count():
    """عدد الرسائل غير المقروءة"""
    count = TicketMessage.query.join(Ticket).filter(
        Ticket.user_id == current_user.id,
        TicketMessage.is_admin_reply == True,
        TicketMessage.is_read == False
    ).count()
    
    return jsonify({
        'count': count
    })