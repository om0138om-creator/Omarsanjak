"""
======================================
🏠 Main Routes
======================================
المسارات الرئيسية
"""

from flask import Blueprint, render_template, request, jsonify, current_app
from flask_login import current_user

from app.extensions import cache
from app.models.product import Product
from app.models.category import Category
from app.models.settings import SiteSettings

main_bp = Blueprint('main', __name__)


@main_bp.route('/')
@cache.cached(timeout=60, unless=lambda: current_user.is_authenticated)
def index():
    """الصفحة الرئيسية"""
    
    # المنتجات المميزة
    featured_products = Product.get_featured(limit=8)
    
    # المنتجات الجديدة
    new_arrivals = Product.get_new_arrivals(limit=8)
    
    # الأكثر مبيعاً
    bestsellers = Product.get_bestsellers(limit=8)
    
    # العروض والخصومات
    on_sale = Product.get_on_sale(limit=8)
    
    # الفئات المميزة
    featured_categories = Category.get_featured_categories()
    
    return render_template('main/index.html',
        featured_products=featured_products,
        new_arrivals=new_arrivals,
        bestsellers=bestsellers,
        on_sale=on_sale,
        featured_categories=featured_categories
    )


@main_bp.route('/about')
@cache.cached(timeout=3600)
def about():
    """صفحة من نحن"""
    return render_template('main/about.html')


@main_bp.route('/contact', methods=['GET', 'POST'])
def contact():
    """صفحة اتصل بنا"""
    from app.forms.support import TicketForm
    
    if request.method == 'POST':
        # معالجة نموذج الاتصال
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')
        
        # يمكن إرسال بريد إلكتروني هنا
        # أو إنشاء تذكرة دعم
        
        return jsonify({
            'success': True,
            'message': 'تم استلام رسالتك وسنرد عليك قريباً'
        })
    
    settings = SiteSettings.get_settings()
    return render_template('main/contact.html', settings=settings)


@main_bp.route('/terms')
@cache.cached(timeout=3600)
def terms():
    """الشروط والأحكام"""
    settings = SiteSettings.get_settings()
    return render_template('main/terms.html', 
        content=settings.terms_of_service)


@main_bp.route('/privacy')
@cache.cached(timeout=3600)
def privacy():
    """سياسة الخصوصية"""
    settings = SiteSettings.get_settings()
    return render_template('main/privacy.html',
        content=settings.privacy_policy)


@main_bp.route('/shipping-policy')
@cache.cached(timeout=3600)
def shipping_policy():
    """سياسة الشحن"""
    settings = SiteSettings.get_settings()
    return render_template('main/shipping_policy.html',
        content=settings.shipping_policy)


@main_bp.route('/return-policy')
@cache.cached(timeout=3600)
def return_policy():
    """سياسة الاسترجاع"""
    settings = SiteSettings.get_settings()
    return render_template('main/return_policy.html',
        content=settings.return_policy)


@main_bp.route('/faq')
@cache.cached(timeout=3600)
def faq():
    """الأسئلة الشائعة"""
    return render_template('main/faq.html')


@main_bp.route('/search')
def search():
    """صفحة البحث"""
    from app.forms.products import ProductSearchForm
    
    form = ProductSearchForm(request.args)
    
    # تحميل الفئات
    categories = Category.get_root_categories()
    form.category.choices = [('', 'جميع الفئات')] + [
        (c.id, c.display_name) for c in categories
    ]
    
    # إجراء البحث
    query = request.args.get('q', '').strip()
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('PRODUCTS_PER_PAGE', 12)
    
    products = Product.search(
        query=query,
        category_id=request.args.get('category', type=int),
        min_price=request.args.get('min_price', type=float),
        max_price=request.args.get('max_price', type=float),
        in_stock_only=request.args.get('in_stock') == 'on',
        sort_by=request.args.get('sort', 'relevance')
    ).paginate(page=page, per_page=per_page)
    
    return render_template('main/search.html',
        form=form,
        products=products,
        query=query
    )


@main_bp.route('/quick-search')
def quick_search():
    """البحث السريع (AJAX)"""
    query = request.args.get('q', '').strip()
    
    if len(query) < 2:
        return jsonify({'results': []})
    
    products = Product.search(query=query).limit(5).all()
    categories = Category.query.filter(
        Category.name.ilike(f'%{query}%') |
        Category.name_ar.ilike(f'%{query}%')
    ).filter_by(is_active=True).limit(3).all()
    
    results = {
        'products': [{
            'id': p.id,
            'name': p.display_name,
            'slug': p.slug,
            'price': p.current_price,
            'image': p.get_main_image(),
            'url': f'/products/{p.slug}'
        } for p in products],
        'categories': [{
            'id': c.id,
            'name': c.display_name,
            'slug': c.slug,
            'url': f'/products/category/{c.slug}'
        } for c in categories]
    }
    
    return jsonify(results)


@main_bp.route('/newsletter/subscribe', methods=['POST'])
def newsletter_subscribe():
    """الاشتراك في النشرة البريدية"""
    email = request.form.get('email', '').strip().lower()
    
    if not email or '@' not in email:
        return jsonify({
            'success': False,
            'message': 'البريد الإلكتروني غير صالح'
        })
    
    # يمكن حفظ الإيميل في قاعدة البيانات
    # أو إضافته لخدمة مثل Mailchimp
    
    return jsonify({
        'success': True,
        'message': 'شكراً لاشتراكك في نشرتنا البريدية!'
    })


@main_bp.route('/sitemap.xml')
@cache.cached(timeout=86400)
def sitemap():
    """خريطة الموقع"""
    from flask import make_response
    from datetime import datetime
    
    pages = []
    
    # الصفحات الثابتة
    static_pages = [
        ('main.index', 'daily', 1.0),
        ('main.about', 'monthly', 0.5),
        ('main.contact', 'monthly', 0.5),
        ('main.terms', 'monthly', 0.3),
        ('main.privacy', 'monthly', 0.3),
        ('main.faq', 'weekly', 0.5),
    ]
    
    for endpoint, changefreq, priority in static_pages:
        from flask import url_for
        pages.append({
            'loc': url_for(endpoint, _external=True),
            'changefreq': changefreq,
            'priority': priority
        })
    
    # الفئات
    categories = Category.query.filter_by(is_active=True).all()
    for cat in categories:
        pages.append({
            'loc': url_for('products.category', slug=cat.slug, _external=True),
            'changefreq': 'weekly',
            'priority': 0.7
        })
    
    # المنتجات
    products = Product.query.filter_by(is_active=True).all()
    for product in products:
        pages.append({
            'loc': url_for('products.detail', slug=product.slug, _external=True),
            'lastmod': product.updated_at.strftime('%Y-%m-%d'),
            'changefreq': 'weekly',
            'priority': 0.8
        })
    
    # إنشاء XML
    xml = '<?xml version="1.0" encoding="UTF-8"?>\n'
    xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    
    for page in pages:
        xml += '  <url>\n'
        xml += f'    <loc>{page["loc"]}</loc>\n'
        if 'lastmod' in page:
            xml += f'    <lastmod>{page["lastmod"]}</lastmod>\n'
        xml += f'    <changefreq>{page["changefreq"]}</changefreq>\n'
        xml += f'    <priority>{page["priority"]}</priority>\n'
        xml += '  </url>\n'
    
    xml += '</urlset>'
    
    response = make_response(xml)
    response.headers['Content-Type'] = 'application/xml'
    return response


@main_bp.route('/robots.txt')
@cache.cached(timeout=86400)
def robots():
    """ملف robots.txt"""
    from flask import make_response, url_for
    
    content = f"""User-agent: *
Allow: /

Sitemap: {url_for('main.sitemap', _external=True)}
"""
    
    response = make_response(content)
    response.headers['Content-Type'] = 'text/plain'
    return response


# ==========================================
# 🔧 Error Handlers for this Blueprint
# ==========================================

@main_bp.app_errorhandler(404)
def page_not_found(e):
    return render_template('errors/404.html'), 404


@main_bp.app_errorhandler(500)
def internal_server_error(e):
    return render_template('errors/500.html'), 500