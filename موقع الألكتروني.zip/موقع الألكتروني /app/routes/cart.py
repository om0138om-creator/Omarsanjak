"""
======================================
🛒 Cart Routes
======================================
مسارات سلة التسوق
"""

from flask import (
    Blueprint, render_template, request, jsonify,
    redirect, url_for, flash, session, g
)
from flask_login import login_required, current_user

from app.extensions import db
from app.models.cart import Cart, CartItem
from app.models.product import Product, ProductVariant
from app.models.coupon import Coupon
from app.models.settings import ShippingZone

cart_bp = Blueprint('cart', __name__)


def get_cart():
    """الحصول على سلة التسوق الحالية"""
    if current_user.is_authenticated:
        return Cart.get_or_create(user_id=current_user.id)
    else:
        session_id = session.get('cart_session_id')
        if session_id:
            return Cart.get_or_create(session_id=session_id)
    return None


@cart_bp.route('/')
def index():
    """عرض سلة التسوق"""
    cart = get_cart()
    
    if not cart or cart.is_empty:
        return render_template('cart/empty.html')
    
    # تحديث الأسعار
    cart.refresh_prices()
    db.session.commit()
    
    # التحقق من المشاكل
    issues = cart.validate_items()
    
    # مناطق الشحن للحساب التقديري
    shipping_zones = ShippingZone.query.filter_by(
        is_active=True
    ).order_by(ShippingZone.sort_order).all()
    
    return render_template('cart/index.html',
        cart=cart,
        issues=issues,
        shipping_zones=shipping_zones
    )


@cart_bp.route('/add', methods=['POST'])
def add():
    """إضافة منتج للسلة"""
    data = request.get_json() if request.is_json else request.form
    
    product_id = data.get('product_id', type=int) if hasattr(data, 'get') else int(data.get('product_id', 0))
    quantity = int(data.get('quantity', 1))
    variant_id = data.get('variant_id')
    if variant_id:
        variant_id = int(variant_id)
    
    # التحقق من المنتج
    product = Product.query.get(product_id)
    if not product or not product.is_active:
        if request.is_json:
            return jsonify({'success': False, 'message': 'المنتج غير متاح'}), 404
        flash('المنتج غير متاح', 'danger')
        return redirect(request.referrer or url_for('products.index'))
    
    # التحقق من المتغير إذا محدد
    variant = None
    if variant_id:
        variant = ProductVariant.query.get(variant_id)
        if not variant or variant.product_id != product.id:
            if request.is_json:
                return jsonify({'success': False, 'message': 'الخيار غير متاح'}), 404
            flash('الخيار المحدد غير متاح', 'danger')
            return redirect(request.referrer or url_for('products.detail', slug=product.slug))
    
    # الحصول على السلة
    cart = get_cart()
    if not cart:
        if request.is_json:
            return jsonify({'success': False, 'message': 'خطأ في السلة'}), 500
        flash('حدث خطأ', 'danger')
        return redirect(request.referrer or url_for('products.index'))
    
    # إضافة للسلة
    success, error = cart.add_item(product, quantity, variant_id)
    
    if not success:
        if request.is_json:
            return jsonify({'success': False, 'message': error}), 400
        flash(error, 'danger')
        return redirect(request.referrer or url_for('products.detail', slug=product.slug))
    
    db.session.commit()
    
    if request.is_json:
        return jsonify({
            'success': True,
            'message': 'تمت الإضافة للسلة',
            'cart_count': cart.items_count,
            'cart_total': cart.total
        })
    
    flash('تمت إضافة المنتج للسلة', 'success')
    return redirect(request.referrer or url_for('cart.index'))


@cart_bp.route('/update', methods=['POST'])
def update():
    """تحديث كمية منتج"""
    data = request.get_json() if request.is_json else request.form
    
    item_id = int(data.get('item_id', 0))
    quantity = int(data.get('quantity', 1))
    
    cart = get_cart()
    if not cart:
        if request.is_json:
            return jsonify({'success': False, 'message': 'السلة فارغة'}), 400
        flash('السلة فارغة', 'warning')
        return redirect(url_for('cart.index'))
    
    success, error = cart.update_item_quantity(item_id, quantity)
    
    if not success:
        if request.is_json:
            return jsonify({'success': False, 'message': error}), 400
        flash(error, 'danger')
        return redirect(url_for('cart.index'))
    
    db.session.commit()
    
    if request.is_json:
        # الحصول على العنصر المحدث
        item = CartItem.query.get(item_id)
        return jsonify({
            'success': True,
            'message': 'تم التحديث',
            'item': item.to_dict() if item else None,
            'cart_count': cart.items_count,
            'subtotal': cart.subtotal,
            'discount_total': cart.discount_total,
            'total': cart.total
        })
    
    flash('تم تحديث الكمية', 'success')
    return redirect(url_for('cart.index'))


@cart_bp.route('/remove', methods=['POST'])
def remove():
    """إزالة منتج من السلة"""
    data = request.get_json() if request.is_json else request.form
    item_id = int(data.get('item_id', 0))
    
    cart = get_cart()
    if not cart:
        if request.is_json:
            return jsonify({'success': False, 'message': 'السلة فارغة'}), 400
        flash('السلة فارغة', 'warning')
        return redirect(url_for('cart.index'))
    
    success, error = cart.remove_item(item_id)
    db.session.commit()
    
    if request.is_json:
        return jsonify({
            'success': success,
            'message': 'تمت الإزالة' if success else error,
            'cart_count': cart.items_count,
            'subtotal': cart.subtotal,
            'total': cart.total,
            'is_empty': cart.is_empty
        })
    
    if success:
        flash('تمت إزالة المنتج', 'success')
    else:
        flash(error, 'danger')
    
    return redirect(url_for('cart.index'))


@cart_bp.route('/clear', methods=['POST'])
def clear():
    """تفريغ السلة"""
    cart = get_cart()
    
    if cart:
        cart.clear()
        db.session.commit()
    
    if request.is_json:
        return jsonify({
            'success': True,
            'message': 'تم تفريغ السلة'
        })
    
    flash('تم تفريغ السلة', 'info')
    return redirect(url_for('cart.index'))


@cart_bp.route('/apply-coupon', methods=['POST'])
def apply_coupon():
    """تطبيق كوبون خصم"""
    data = request.get_json() if request.is_json else request.form
    code = data.get('code', '').strip().upper()
    
    if not code:
        if request.is_json:
            return jsonify({'success': False, 'message': 'أدخل رمز الكوبون'}), 400
        flash('أدخل رمز الكوبون', 'warning')
        return redirect(url_for('cart.index'))
    
    cart = get_cart()
    if not cart or cart.is_empty:
        if request.is_json:
            return jsonify({'success': False, 'message': 'السلة فارغة'}), 400
        flash('السلة فارغة', 'warning')
        return redirect(url_for('cart.index'))
    
    # البحث عن الكوبون
    coupon = Coupon.query.filter_by(code=code).first()
    
    if not coupon:
        if request.is_json:
            return jsonify({'success': False, 'message': 'الكوبون غير موجود'}), 404
        flash('الكوبون غير موجود', 'danger')
        return redirect(url_for('cart.index'))
    
    # التحقق للمستخدم
    if current_user.is_authenticated:
        is_valid, error = coupon.is_valid_for_user(current_user.id)
        if not is_valid:
            if request.is_json:
                return jsonify({'success': False, 'message': error}), 400
            flash(error, 'danger')
            return redirect(url_for('cart.index'))
    
    # تطبيق الكوبون
    success, message = cart.apply_coupon(coupon)
    db.session.commit()
    
    if request.is_json:
        return jsonify({
            'success': success,
            'message': message,
            'coupon_discount': float(cart.coupon_discount) if success else 0,
            'total': cart.total
        })
    
    if success:
        flash(message, 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('cart.index'))


@cart_bp.route('/remove-coupon', methods=['POST'])
def remove_coupon():
    """إزالة الكوبون"""
    cart = get_cart()
    
    if cart:
        cart.remove_coupon()
        db.session.commit()
    
    if request.is_json:
        return jsonify({
            'success': True,
            'message': 'تمت إزالة الكوبون',
            'total': cart.total if cart else 0
        })
    
    flash('تمت إزالة الكوبون', 'info')
    return redirect(url_for('cart.index'))


@cart_bp.route('/shipping-estimate', methods=['POST'])
def shipping_estimate():
    """حساب تكلفة الشحن التقديرية"""
    data = request.get_json()
    zone_id = data.get('zone_id')
    shipping_method = data.get('method', 'standard')
    
    cart = get_cart()
    if not cart or cart.is_empty:
        return jsonify({'success': False, 'message': 'السلة فارغة'}), 400
    
    zone = ShippingZone.query.get(zone_id)
    if not zone:
        return jsonify({'success': False, 'message': 'المنطقة غير موجودة'}), 404
    
    is_express = shipping_method == 'express'
    shipping_cost = zone.get_shipping_cost(cart.subtotal, is_express)
    
    return jsonify({
        'success': True,
        'shipping_cost': shipping_cost,
        'delivery_estimate': zone.delivery_estimate if not is_express else f'{zone.express_days} يوم',
        'free_shipping': shipping_cost == 0,
        'total': cart.total + shipping_cost
    })


@cart_bp.route('/count')
def count():
    """عدد عناصر السلة (AJAX)"""
    cart = get_cart()
    count = cart.items_count if cart else 0
    
    return jsonify({
        'count': count
    })


@cart_bp.route('/mini')
def mini():
    """السلة المصغرة (AJAX)"""
    cart = get_cart()
    
    if not cart or cart.is_empty:
        return render_template('cart/_mini_empty.html')
    
    return render_template('cart/_mini.html', cart=cart)


@cart_bp.route('/summary')
def summary():
    """ملخص السلة (AJAX)"""
    cart = get_cart()
    
    if not cart:
        return jsonify({'success': False, 'message': 'السلة فارغة'}), 400
    
    return jsonify({
        'success': True,
        'cart': cart.to_dict()
    })