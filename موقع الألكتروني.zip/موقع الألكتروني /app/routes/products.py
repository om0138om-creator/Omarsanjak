"""
======================================
📦 Products Routes
======================================
مسارات المنتجات
"""

from flask import (
    Blueprint, render_template, request, jsonify, 
    abort, flash, redirect, url_for, current_app
)
from flask_login import login_required, current_user

from app.extensions import db, cache
from app.models.product import Product, ProductReview
from app.models.category import Category
from app.models.user import UserWishlist
from app.forms.products import ProductSearchForm, ReviewForm
from app.utils.decorators import verified_required

products_bp = Blueprint('products', __name__)


@products_bp.route('/')
def index():
    """عرض جميع المنتجات"""
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('PRODUCTS_PER_PAGE', 12)
    
    # فلترة
    sort = request.args.get('sort', 'newest')
    
    query = Product.query.filter_by(is_active=True, visibility='visible')
    
    # الترتيب
    if sort == 'price_asc':
        query = query.order_by(Product.price.asc())
    elif sort == 'price_desc':
        query = query.order_by(Product.price.desc())
    elif sort == 'bestselling':
        query = query.order_by(Product.sales_count.desc())
    elif sort == 'rating':
        query = query.order_by(Product.rating_average.desc())
    else:  # newest
        query = query.order_by(Product.created_at.desc())
    
    products = query.paginate(page=page, per_page=per_page)
    
    # الفئات للفلترة
    categories = Category.get_root_categories()
    
    return render_template('products/index.html',
        products=products,
        categories=categories,
        current_sort=sort
    )


@products_bp.route('/category/<slug>')
def category(slug):
    """عرض منتجات فئة معينة"""
    cat = Category.query.filter_by(slug=slug, is_active=True).first_or_404()
    
    # زيادة المشاهدات
    cat.increment_views()
    db.session.commit()
    
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('PRODUCTS_PER_PAGE', 12)
    sort = request.args.get('sort', 'newest')
    
    # جمع المنتجات من الفئة والفئات الفرعية
    category_ids = [cat.id] + [c.id for c in cat.get_all_children()]
    
    query = Product.query.filter(
        Product.category_id.in_(category_ids),
        Product.is_active == True,
        Product.visibility == 'visible'
    )
    
    # الترتيب
    if sort == 'price_asc':
        query = query.order_by(Product.price.asc())
    elif sort == 'price_desc':
        query = query.order_by(Product.price.desc())
    elif sort == 'bestselling':
        query = query.order_by(Product.sales_count.desc())
    elif sort == 'rating':
        query = query.order_by(Product.rating_average.desc())
    else:
        query = query.order_by(Product.created_at.desc())
    
    products = query.paginate(page=page, per_page=per_page)
    
    # الفئات الفرعية
    subcategories = cat.children.filter_by(is_active=True).all()
    
    # مسار التنقل
    breadcrumb = cat.get_breadcrumb()
    
    return render_template('products/category.html',
        category=cat,
        products=products,
        subcategories=subcategories,
        breadcrumb=breadcrumb,
        current_sort=sort
    )


@products_bp.route('/<slug>')
def detail(slug):
    """تفاصيل المنتج"""
    product = Product.query.filter_by(
        slug=slug, 
        is_active=True
    ).first_or_404()
    
    # زيادة المشاهدات
    product.increment_views()
    db.session.commit()
    
    # التحقق من المفضلة
    is_wishlisted = False
    if current_user.is_authenticated:
        is_wishlisted = UserWishlist.query.filter_by(
            user_id=current_user.id,
            product_id=product.id
        ).first() is not None
    
    # التقييمات
    reviews = product.reviews.filter_by(is_approved=True).order_by(
        ProductReview.created_at.desc()
    ).limit(10).all()
    
    # نموذج التقييم
    review_form = ReviewForm()
    
    # التحقق من إمكانية التقييم
    can_review = False
    user_review = None
    if current_user.is_authenticated:
        # التحقق من شراء المنتج
        from app.models.order import Order, OrderItem
        purchased = db.session.query(OrderItem).join(Order).filter(
            Order.user_id == current_user.id,
            Order.status == 'delivered',
            OrderItem.product_id == product.id
        ).first() is not None
        
        # التحقق من عدم وجود تقييم سابق
        user_review = ProductReview.query.filter_by(
            user_id=current_user.id,
            product_id=product.id
        ).first()
        
        can_review = purchased and user_review is None
    
    # منتجات مشابهة
    related_products = Product.query.filter(
        Product.category_id == product.category_id,
        Product.id != product.id,
        Product.is_active == True
    ).order_by(Product.sales_count.desc()).limit(4).all()
    
    # مسار التنقل
    breadcrumb = []
    if product.category:
        breadcrumb = product.category.get_breadcrumb()
    
    return render_template('products/detail.html',
        product=product,
        is_wishlisted=is_wishlisted,
        reviews=reviews,
        review_form=review_form,
        can_review=can_review,
        user_review=user_review,
        related_products=related_products,
        breadcrumb=breadcrumb
    )


@products_bp.route('/<slug>/reviews', methods=['POST'])
@login_required
@verified_required
def add_review(slug):
    """إضافة تقييم"""
    product = Product.query.filter_by(slug=slug, is_active=True).first_or_404()
    
    # التحقق من شراء المنتج
    from app.models.order import Order, OrderItem
    purchase = db.session.query(Order).join(OrderItem).filter(
        Order.user_id == current_user.id,
        Order.status == 'delivered',
        OrderItem.product_id == product.id
    ).first()
    
    if not purchase:
        flash('يجب شراء المنتج أولاً قبل تقييمه', 'warning')
        return redirect(url_for('products.detail', slug=slug))
    
    # التحقق من عدم وجود تقييم سابق
    existing = ProductReview.query.filter_by(
        user_id=current_user.id,
        product_id=product.id
    ).first()
    
    if existing:
        flash('لقد قمت بتقييم هذا المنتج مسبقاً', 'info')
        return redirect(url_for('products.detail', slug=slug))
    
    form = ReviewForm()
    
    if form.validate_on_submit():
        review = ProductReview(
            product_id=product.id,
            user_id=current_user.id,
            order_id=purchase.id,
            rating=int(form.rating.data),
            title=form.title.data,
            comment=form.comment.data,
            pros=form.pros.data,
            cons=form.cons.data,
            is_verified_purchase=True
        )
        
        db.session.add(review)
        db.session.commit()
        
        flash('شكراً لك! سيتم مراجعة تقييمك ونشره قريباً', 'success')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(error, 'danger')
    
    return redirect(url_for('products.detail', slug=slug))


@products_bp.route('/reviews/<int:review_id>/helpful', methods=['POST'])
@login_required
def mark_review_helpful(review_id):
    """تصويت على مفيدية التقييم"""
    review = ProductReview.query.get_or_404(review_id)
    
    helpful = request.json.get('helpful', True)
    
    if helpful:
        review.mark_helpful()
    else:
        review.mark_not_helpful()
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'helpful_count': review.helpful_count,
        'not_helpful_count': review.not_helpful_count
    })


@products_bp.route('/wishlist/toggle', methods=['POST'])
@login_required
def toggle_wishlist():
    """إضافة/إزالة من المفضلة"""
    product_id = request.json.get('product_id')
    
    if not product_id:
        return jsonify({'success': False, 'message': 'المنتج غير محدد'}), 400
    
    product = Product.query.get(product_id)
    if not product:
        return jsonify({'success': False, 'message': 'المنتج غير موجود'}), 404
    
    # البحث عن العنصر في المفضلة
    wishlist_item = UserWishlist.query.filter_by(
        user_id=current_user.id,
        product_id=product_id
    ).first()
    
    if wishlist_item:
        # إزالة من المفضلة
        db.session.delete(wishlist_item)
        product.wishlist_count = max(0, product.wishlist_count - 1)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'action': 'removed',
            'message': 'تمت الإزالة من المفضلة'
        })
    else:
        # إضافة للمفضلة
        wishlist_item = UserWishlist(
            user_id=current_user.id,
            product_id=product_id
        )
        db.session.add(wishlist_item)
        product.wishlist_count += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'action': 'added',
            'message': 'تمت الإضافة للمفضلة'
        })


@products_bp.route('/quick-view/<int:product_id>')
def quick_view(product_id):
    """العرض السريع (AJAX)"""
    product = Product.query.get_or_404(product_id)
    
    if not product.is_active:
        abort(404)
    
    return render_template('products/_quick_view.html', product=product)


@products_bp.route('/compare')
def compare():
    """مقارنة المنتجات"""
    product_ids = request.args.getlist('products', type=int)
    
    if len(product_ids) < 2:
        flash('اختر منتجين على الأقل للمقارنة', 'warning')
        return redirect(url_for('products.index'))
    
    if len(product_ids) > 4:
        product_ids = product_ids[:4]
    
    products = Product.query.filter(
        Product.id.in_(product_ids),
        Product.is_active == True
    ).all()
    
    return render_template('products/compare.html', products=products)


@products_bp.route('/new')
def new_arrivals():
    """المنتجات الجديدة"""
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('PRODUCTS_PER_PAGE', 12)
    
    products = Product.query.filter_by(
        is_active=True,
        is_new=True
    ).order_by(Product.created_at.desc()).paginate(page=page, per_page=per_page)
    
    return render_template('products/new_arrivals.html', products=products)


@products_bp.route('/sale')
def on_sale():
    """المنتجات المخفضة"""
    from datetime import datetime
    
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('PRODUCTS_PER_PAGE', 12)
    now = datetime.utcnow()
    
    products = Product.query.filter(
        Product.is_active == True,
        Product.discount_value > 0,
        db.or_(Product.discount_start == None, Product.discount_start <= now),
        db.or_(Product.discount_end == None, Product.discount_end >= now)
    ).order_by(Product.discount_value.desc()).paginate(page=page, per_page=per_page)
    
    return render_template('products/on_sale.html', products=products)


@products_bp.route('/bestsellers')
def bestsellers():
    """الأكثر مبيعاً"""
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('PRODUCTS_PER_PAGE', 12)
    
    products = Product.query.filter_by(
        is_active=True,
        is_bestseller=True
    ).order_by(Product.sales_count.desc()).paginate(page=page, per_page=per_page)
    
    return render_template('products/bestsellers.html', products=products)


@products_bp.route('/featured')
def featured():
    """المنتجات المميزة"""
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('PRODUCTS_PER_PAGE', 12)
    
    products = Product.query.filter_by(
        is_active=True,
        is_featured=True
    ).order_by(Product.created_at.desc()).paginate(page=page, per_page=per_page)
    
    return render_template('products/featured.html', products=products)


# ==========================================
# 🔧 API Endpoints for Products
# ==========================================

@products_bp.route('/api/filter')
def api_filter():
    """API فلترة المنتجات"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 12, type=int)
    
    query = Product.query.filter_by(is_active=True, visibility='visible')
    
    # فلترة بالفئة
    category_id = request.args.get('category', type=int)
    if category_id:
        cat = Category.query.get(category_id)
        if cat:
            category_ids = [cat.id] + [c.id for c in cat.get_all_children()]
            query = query.filter(Product.category_id.in_(category_ids))
    
    # فلترة بالسعر
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    if min_price:
        query = query.filter(Product.price >= min_price)
    if max_price:
        query = query.filter(Product.price <= max_price)
    
    # فلترة بالتوفر
    if request.args.get('in_stock'):
        query = query.filter(Product.stock_quantity > 0)
    
    # فلترة بالعروض
    if request.args.get('on_sale'):
        from datetime import datetime
        now = datetime.utcnow()
        query = query.filter(
            Product.discount_value > 0,
            db.or_(Product.discount_start == None, Product.discount_start <= now),
            db.or_(Product.discount_end == None, Product.discount_end >= now)
        )
    
    # البحث
    search = request.args.get('q', '').strip()
    if search:
        query = query.filter(
            db.or_(
                Product.name.ilike(f'%{search}%'),
                Product.name_ar.ilike(f'%{search}%'),
                Product.description.ilike(f'%{search}%'),
                Product.sku.ilike(f'%{search}%')
            )
        )
    
    # الترتيب
    sort = request.args.get('sort', 'newest')
    if sort == 'price_asc':
        query = query.order_by(Product.price.asc())
    elif sort == 'price_desc':
        query = query.order_by(Product.price.desc())
    elif sort == 'bestselling':
        query = query.order_by(Product.sales_count.desc())
    elif sort == 'rating':
        query = query.order_by(Product.rating_average.desc())
    else:
        query = query.order_by(Product.created_at.desc())
    
    # التصفح
    pagination = query.paginate(page=page, per_page=per_page)
    
    return jsonify({
        'success': True,
        'products': [p.to_dict() for p in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': pagination.page,
        'has_next': pagination.has_next,
        'has_prev': pagination.has_prev
    })


@products_bp.route('/api/<int:product_id>')
def api_product_detail(product_id):
    """API تفاصيل المنتج"""
    product = Product.query.get_or_404(product_id)
    
    if not product.is_active:
        return jsonify({'success': False, 'message': 'المنتج غير متاح'}), 404
    
    return jsonify({
        'success': True,
        'product': product.to_dict(include_details=True)
    })