"""
======================================
🎛️ Admin Dashboard Routes
======================================
مسارات لوحة التحكم
"""

from datetime import datetime, timedelta
from flask import (
    Blueprint, render_template, request, jsonify,
    redirect, url_for, flash, current_app, abort
)
from flask_login import login_required, current_user
from sqlalchemy import func, desc

from app.extensions import db
from app.models.user import User
from app.models.product import Product, ProductImage, ProductReview
from app.models.category import Category
from app.models.order import Order, OrderItem, OrderStatusHistory
from app.models.cart import Cart
from app.models.ticket import Ticket, TicketMessage
from app.models.coupon import Coupon
from app.models.settings import SiteSettings, ShippingZone
from app.models.notification import Notification
from app.forms.products import ProductForm
from app.forms.admin import (
    CategoryForm, ShippingZoneForm, CouponAdminForm,
    SiteSettingsForm, OrderStatusForm, AdminTicketReplyForm
)
from app.services.storage_service import storage_service
from app.services.email_service import email_service
from app.services.analytics_service import AnalyticsService
from app.utils.decorators import admin_required

admin_bp = Blueprint('admin', __name__)


# ==========================================
# 🎯 Middleware - التحقق من صلاحيات المشرف
# ==========================================

@admin_bp.before_request
@login_required
def check_admin():
    """التحقق من صلاحيات المشرف قبل كل طلب"""
    if not current_user.is_admin:
        abort(403)


# ==========================================
# 📊 Dashboard - لوحة التحكم الرئيسية
# ==========================================

@admin_bp.route('/')
@admin_bp.route('/dashboard')
def dashboard():
    """لوحة التحكم الرئيسية"""
    
    # الإحصائيات
    stats = AnalyticsService.get_dashboard_stats()
    
    # مخطط الإيرادات
    revenue_chart = AnalyticsService.get_revenue_chart(days=30)
    
    # أحدث الطلبات
    recent_orders = Order.query.order_by(
        Order.created_at.desc()
    ).limit(10).all()
    
    # الطلبات قيد المراجعة
    pending_orders = Order.query.filter_by(
        status='pending'
    ).order_by(Order.created_at.desc()).limit(5).all()
    
    # أفضل المنتجات
    top_products = AnalyticsService.get_top_products(limit=5)
    
    # التذاكر المفتوحة
    open_tickets = Ticket.query.filter(
        Ticket.status.in_(['open', 'in_progress'])
    ).order_by(Ticket.created_at.desc()).limit(5).all()
    
    # منتجات منخفضة المخزون
    low_stock_products = Product.query.filter(
        Product.is_active == True,
        Product.track_inventory == True,
        Product.stock_quantity <= Product.low_stock_threshold,
        Product.stock_quantity > 0
    ).limit(5).all()
    
    # منتجات نفدت
    out_of_stock = Product.query.filter(
        Product.is_active == True,
        Product.track_inventory == True,
        Product.stock_quantity <= 0
    ).limit(5).all()
    
    return render_template('admin/dashboard.html',
        stats=stats,
        revenue_chart=revenue_chart,
        recent_orders=recent_orders,
        pending_orders=pending_orders,
        top_products=top_products,
        open_tickets=open_tickets,
        low_stock_products=low_stock_products,
        out_of_stock=out_of_stock
    )


# ==========================================
# 📦 Products - إدارة المنتجات
# ==========================================

@admin_bp.route('/products')
def products():
    """قائمة المنتجات"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('q', '').strip()
    category_id = request.args.get('category', type=int)
    status = request.args.get('status', '')
    
    query = Product.query
    
    # البحث
    if search:
        query = query.filter(
            db.or_(
                Product.name.ilike(f'%{search}%'),
                Product.name_ar.ilike(f'%{search}%'),
                Product.sku.ilike(f'%{search}%')
            )
        )
    
    # فلترة بالفئة
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    # فلترة بالحالة
    if status == 'active':
        query = query.filter_by(is_active=True)
    elif status == 'inactive':
        query = query.filter_by(is_active=False)
    elif status == 'low_stock':
        query = query.filter(
            Product.stock_quantity <= Product.low_stock_threshold,
            Product.stock_quantity > 0
        )
    elif status == 'out_of_stock':
        query = query.filter(Product.stock_quantity <= 0)
    
    products = query.order_by(Product.created_at.desc()).paginate(
        page=page,
        per_page=current_app.config.get('ADMIN_ITEMS_PER_PAGE', 20)
    )
    
    # الفئات للفلترة
    categories = Category.query.filter_by(is_active=True).all()
    
    return render_template('admin/products/index.html',
        products=products,
        categories=categories,
        search=search,
        current_category=category_id,
        current_status=status
    )


@admin_bp.route('/products/create', methods=['GET', 'POST'])
def product_create():
    """إضافة منتج جديد"""
    form = ProductForm()
    
    # تحميل الفئات
    categories = Category.query.filter_by(is_active=True).all()
    form.category_id.choices = [(0, 'اختر التصنيف...')] + [
        (c.id, c.display_name) for c in categories
    ]
    
    if form.validate_on_submit():
        product = Product(
            name=form.name.data,
            name_ar=form.name_ar.data,
            sku=form.sku.data,
            short_description=form.short_description.data,
            description=form.description.data,
            category_id=form.category_id.data if form.category_id.data else None,
            brand=form.brand.data,
            tags=form.tags.data,
            price=form.price.data,
            compare_at_price=form.compare_at_price.data,
            cost_price=form.cost_price.data,
            discount_type=form.discount_type.data if form.discount_type.data else None,
            discount_value=form.discount_value.data,
            discount_start=form.discount_start.data,
            discount_end=form.discount_end.data,
            stock_quantity=form.stock_quantity.data,
            low_stock_threshold=form.low_stock_threshold.data or 5,
            track_inventory=form.track_inventory.data,
            allow_backorder=form.allow_backorder.data,
            min_purchase_qty=form.min_purchase_qty.data or 1,
            max_purchase_qty=form.max_purchase_qty.data,
            weight=form.weight.data,
            length=form.length.data,
            width=form.width.data,
            height=form.height.data,
            is_active=form.is_active.data,
            is_featured=form.is_featured.data,
            is_new=form.is_new.data,
            meta_title=form.meta_title.data,
            meta_description=form.meta_description.data
        )
        
        db.session.add(product)
        db.session.flush()
        
        # رفع الصورة الرئيسية
        if form.main_image.data:
            result = storage_service.upload_image(
                form.main_image.data,
                folder=f'products/{product.id}'
            )
            if result['success']:
                product.main_image_url = result['url']
                product.thumbnail_url = result['thumbnail_url']
                
                # إضافة للصور
                image = ProductImage(
                    product_id=product.id,
                    url=result['url'],
                    thumbnail_url=result['thumbnail_url'],
                    r2_key=result['key'],
                    r2_thumbnail_key=result.get('thumbnail_key'),
                    is_primary=True,
                    width=result.get('width'),
                    height=result.get('height'),
                    file_size=result.get('file_size')
                )
                db.session.add(image)
        
        # رفع الصور الإضافية
        if form.additional_images.data:
            for idx, file in enumerate(form.additional_images.data):
                if file and file.filename:
                    result = storage_service.upload_image(
                        file,
                        folder=f'products/{product.id}'
                    )
                    if result['success']:
                        image = ProductImage(
                            product_id=product.id,
                            url=result['url'],
                            thumbnail_url=result['thumbnail_url'],
                            r2_key=result['key'],
                            r2_thumbnail_key=result.get('thumbnail_key'),
                            is_primary=False,
                            sort_order=idx + 1,
                            width=result.get('width'),
                            height=result.get('height'),
                            file_size=result.get('file_size')
                        )
                        db.session.add(image)
        
        # تحديث عدد منتجات الفئة
        if product.category:
            product.category.update_products_count()
        
        db.session.commit()
        
        flash('تم إضافة المنتج بنجاح', 'success')
        return redirect(url_for('admin.products'))
    
    return render_template('admin/products/form.html',
        form=form,
        title='إضافة منتج جديد',
        is_edit=False
    )


@admin_bp.route('/products/<int:product_id>/edit', methods=['GET', 'POST'])
def product_edit(product_id):
    """تعديل منتج"""
    product = Product.query.get_or_404(product_id)
    form = ProductForm(obj=product)
    
    # تحميل الفئات
    categories = Category.query.filter_by(is_active=True).all()
    form.category_id.choices = [(0, 'اختر التصنيف...')] + [
        (c.id, c.display_name) for c in categories
    ]
    
    if form.validate_on_submit():
        # حفظ الفئة القديمة لتحديث العدد
        old_category = product.category
        
        form.populate_obj(product)
        product.updated_at = datetime.utcnow()
        
        # رفع الصورة الرئيسية الجديدة
        if form.main_image.data:
            result = storage_service.upload_image(
                form.main_image.data,
                folder=f'products/{product.id}'
            )
            if result['success']:
                product.main_image_url = result['url']
                product.thumbnail_url = result['thumbnail_url']
                
                # تحديث الصورة الرئيسية
                primary_image = product.images.filter_by(is_primary=True).first()
                if primary_image:
                    primary_image.url = result['url']
                    primary_image.thumbnail_url = result['thumbnail_url']
                else:
                    image = ProductImage(
                        product_id=product.id,
                        url=result['url'],
                        thumbnail_url=result['thumbnail_url'],
                        r2_key=result['key'],
                        is_primary=True
                    )
                    db.session.add(image)
        
        # رفع صور إضافية
        if form.additional_images.data:
            last_order = product.images.count()
            for idx, file in enumerate(form.additional_images.data):
                if file and file.filename:
                    result = storage_service.upload_image(
                        file,
                        folder=f'products/{product.id}'
                    )
                    if result['success']:
                        image = ProductImage(
                            product_id=product.id,
                            url=result['url'],
                            thumbnail_url=result['thumbnail_url'],
                            r2_key=result['key'],
                            is_primary=False,
                            sort_order=last_order + idx + 1
                        )
                        db.session.add(image)
        
        # تحديث عدد منتجات الفئات
        if old_category:
            old_category.update_products_count()
        if product.category:
            product.category.update_products_count()
        
        db.session.commit()
        
        flash('تم تحديث المنتج بنجاح', 'success')
        return redirect(url_for('admin.products'))
    
    return render_template('admin/products/form.html',
        form=form,
        product=product,
        title='تعديل المنتج',
        is_edit=True
    )


@admin_bp.route('/products/<int:product_id>/delete', methods=['POST'])
def product_delete(product_id):
    """حذف منتج"""
    product = Product.query.get_or_404(product_id)
    
    # حذف الصور من R2
    for image in product.images:
        if image.r2_key:
            storage_service.delete_file(image.r2_key)
        if image.r2_thumbnail_key:
            storage_service.delete_file(image.r2_thumbnail_key)
    
    # حفظ الفئة لتحديث العدد
    category = product.category
    
    db.session.delete(product)
    
    if category:
        category.update_products_count()
    
    db.session.commit()
    
    flash('تم حذف المنتج', 'success')
    return redirect(url_for('admin.products'))


@admin_bp.route('/products/<int:product_id>/toggle-status', methods=['POST'])
def product_toggle_status(product_id):
    """تبديل حالة المنتج"""
    product = Product.query.get_or_404(product_id)
    product.is_active = not product.is_active
    db.session.commit()
    
    status = 'نشط' if product.is_active else 'غير نشط'
    
    if request.is_json:
        return jsonify({
            'success': True,
            'is_active': product.is_active,
            'message': f'تم تغيير حالة المنتج إلى {status}'
        })
    
    flash(f'تم تغيير حالة المنتج إلى {status}', 'success')
    return redirect(url_for('admin.products'))


@admin_bp.route('/products/<int:product_id>/images')
def product_images(product_id):
    """إدارة صور المنتج"""
    product = Product.query.get_or_404(product_id)
    return render_template('admin/products/images.html', product=product)


@admin_bp.route('/products/<int:product_id>/images/upload', methods=['POST'])
def product_image_upload(product_id):
    """رفع صورة للمنتج"""
    product = Product.query.get_or_404(product_id)
    
    if 'image' not in request.files:
        return jsonify({'success': False, 'message': 'لم يتم اختيار صورة'}), 400
    
    file = request.files['image']
    result = storage_service.upload_image(file, folder=f'products/{product.id}')
    
    if not result['success']:
        return jsonify({'success': False, 'message': result['error']}), 400
    
    image = ProductImage(
        product_id=product.id,
        url=result['url'],
        thumbnail_url=result['thumbnail_url'],
        r2_key=result['key'],
        r2_thumbnail_key=result.get('thumbnail_key'),
        width=result.get('width'),
        height=result.get('height'),
        file_size=result.get('file_size'),
        sort_order=product.images.count()
    )
    db.session.add(image)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'image': image.to_dict(),
        'message': 'تم رفع الصورة بنجاح'
    })


@admin_bp.route('/products/images/<int:image_id>/delete', methods=['POST'])
def product_image_delete(image_id):
    """حذف صورة"""
    image = ProductImage.query.get_or_404(image_id)
    
    # حذف من R2
    if image.r2_key:
        storage_service.delete_file(image.r2_key)
    if image.r2_thumbnail_key:
        storage_service.delete_file(image.r2_thumbnail_key)
    
    db.session.delete(image)
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'تم حذف الصورة'})


@admin_bp.route('/products/images/<int:image_id>/set-primary', methods=['POST'])
def product_image_set_primary(image_id):
    """تعيين صورة كرئيسية"""
    image = ProductImage.query.get_or_404(image_id)
    image.set_as_primary()
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'تم تعيين الصورة كرئيسية'})


# ==========================================
# 📁 Categories - إدارة الفئات
# ==========================================

@admin_bp.route('/categories')
def categories():
    """قائمة الفئات"""
    categories = Category.query.filter_by(parent_id=None).order_by(
        Category.sort_order
    ).all()
    
    return render_template('admin/categories/index.html', categories=categories)


@admin_bp.route('/categories/create', methods=['GET', 'POST'])
def category_create():
    """إضافة فئة"""
    form = CategoryForm()
    
    # الفئات الأصلية
    parent_categories = Category.query.filter_by(parent_id=None).all()
    form.parent_id.choices = [(0, 'فئة رئيسية')] + [
        (c.id, c.display_name) for c in parent_categories
    ]
    
    if form.validate_on_submit():
        category = Category(
            name=form.name.data,
            name_ar=form.name_ar.data,
            description=form.description.data,
            parent_id=form.parent_id.data if form.parent_id.data else None,
            icon=form.icon.data,
            is_active=form.is_active.data,
            is_featured=form.is_featured.data,
            show_in_menu=form.show_in_menu.data,
            sort_order=form.sort_order.data or 0,
            meta_title=form.meta_title.data,
            meta_description=form.meta_description.data
        )
        
        # رفع الصورة
        if form.image.data:
            result = storage_service.upload_image(
                form.image.data,
                folder='categories'
            )
            if result['success']:
                category.image_url = result['url']
        
        db.session.add(category)
        db.session.commit()
        
        flash('تم إضافة الفئة بنجاح', 'success')
        return redirect(url_for('admin.categories'))
    
    return render_template('admin/categories/form.html',
        form=form,
        title='إضافة فئة جديدة',
        is_edit=False
    )


@admin_bp.route('/categories/<int:category_id>/edit', methods=['GET', 'POST'])
def category_edit(category_id):
    """تعديل فئة"""
    category = Category.query.get_or_404(category_id)
    form = CategoryForm(obj=category)
    
    # الفئات الأصلية (باستثناء هذه الفئة وفروعها)
    excluded_ids = [category.id] + [c.id for c in category.get_all_children()]
    parent_categories = Category.query.filter(
        Category.parent_id == None,
        ~Category.id.in_(excluded_ids)
    ).all()
    form.parent_id.choices = [(0, 'فئة رئيسية')] + [
        (c.id, c.display_name) for c in parent_categories
    ]
    
    if form.validate_on_submit():
        form.populate_obj(category)
        category.parent_id = form.parent_id.data if form.parent_id.data else None
        
        # رفع صورة جديدة
        if form.image.data:
            result = storage_service.upload_image(
                form.image.data,
                folder='categories'
            )
            if result['success']:
                category.image_url = result['url']
        
        db.session.commit()
        
        flash('تم تحديث الفئة بنجاح', 'success')
        return redirect(url_for('admin.categories'))
    
    return render_template('admin/categories/form.html',
        form=form,
        category=category,
        title='تعديل الفئة',
        is_edit=True
    )


@admin_bp.route('/categories/<int:category_id>/delete', methods=['POST'])
def category_delete(category_id):
    """حذف فئة"""
    category = Category.query.get_or_404(category_id)
    
    # التحقق من عدم وجود منتجات
    if category.products.count() > 0:
        flash('لا يمكن حذف فئة تحتوي على منتجات', 'danger')
        return redirect(url_for('admin.categories'))
    
    # التحقق من عدم وجود فئات فرعية
    if category.children.count() > 0:
        flash('لا يمكن حذف فئة تحتوي على فئات فرعية', 'danger')
        return redirect(url_for('admin.categories'))
    
    db.session.delete(category)
    db.session.commit()
    
    flash('تم حذف الفئة', 'success')
    return redirect(url_for('admin.categories'))


# ==========================================
# 📋 Orders - إدارة الطلبات
# ==========================================

@admin_bp.route('/orders')
def orders():
    """قائمة الطلبات"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '')
    payment_status = request.args.get('payment', '')
    search = request.args.get('q', '').strip()
    date_from = request.args.get('from', '')
    date_to = request.args.get('to', '')
    
    query = Order.query
    
    # البحث
    if search:
        query = query.filter(
            db.or_(
                Order.order_number.ilike(f'%{search}%'),
                Order.shipping_name.ilike(f'%{search}%'),
                Order.shipping_phone.ilike(f'%{search}%')
            )
        )
    
    # فلترة بالحالة
    if status:
        query = query.filter_by(status=status)
    
    # فلترة بحالة الدفع
    if payment_status:
        query = query.filter_by(payment_status=payment_status)
    
    # فلترة بالتاريخ
    if date_from:
        query = query.filter(Order.created_at >= datetime.strptime(date_from, '%Y-%m-%d'))
    if date_to:
        query = query.filter(Order.created_at <= datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1))
    
    orders = query.order_by(Order.created_at.desc()).paginate(
        page=page,
        per_page=current_app.config.get('ADMIN_ITEMS_PER_PAGE', 20)
    )
    
    # إحصائيات سريعة
    stats = {
        'pending': Order.query.filter_by(status='pending').count(),
        'processing': Order.query.filter_by(status='processing').count(),
        'shipped': Order.query.filter_by(status='shipped').count(),
        'payment_pending': Order.query.filter_by(payment_status='payment_pending').count()
    }
    
    return render_template('admin/orders/index.html',
        orders=orders,
        stats=stats,
        current_status=status,
        current_payment=payment_status,
        search=search
    )


@admin_bp.route('/orders/<int:order_id>')
def order_detail(order_id):
    """تفاصيل الطلب"""
    order = Order.query.get_or_404(order_id)
    
    # نموذج تغيير الحالة
    status_form = OrderStatusForm()
    
    # الحالات المتاحة للانتقال
    available_statuses = Order.STATUS_FLOW.get(order.status, [])
    status_form.status.choices = [
        (s, Order.STATUS_LABELS.get(s, s)) for s in available_statuses
    ]
    
    return render_template('admin/orders/detail.html',
        order=order,
        status_form=status_form
    )


@admin_bp.route('/orders/<int:order_id>/update-status', methods=['POST'])
def order_update_status(order_id):
    """تحديث حالة الطلب"""
    order = Order.query.get_or_404(order_id)
    form = OrderStatusForm()
    
    # تحديث الحالات المتاحة
    available_statuses = Order.STATUS_FLOW.get(order.status, [])
    form.status.choices = [(s, Order.STATUS_LABELS.get(s, s)) for s in available_statuses]
    
    if form.validate_on_submit():
        new_status = form.status.data
        
        # تحديث معلومات الشحن
        if new_status == 'shipped':
            if form.tracking_number.data:
                order.tracking_number = form.tracking_number.data
            if form.carrier.data:
                order.carrier = form.carrier.data
        
        success, message = order.update_status(
            new_status,
            user_id=current_user.id,
            notes=form.notes.data
        )
        
        if success:
            db.session.commit()
            
            # إشعار العميل
            if form.notify_customer.data:
                Notification.create_order_notification(
                    order.user_id, order, new_status
                )
                
                # إرسال بريد إلكتروني
                if new_status == 'shipped':
                    email_service.send_order_shipped(order)
                elif new_status == 'delivered':
                    email_service.send_order_delivered(order)
                elif new_status == 'cancelled':
                    email_service.send_order_cancelled(order)
                
                db.session.commit()
            
            flash(f'تم تحديث حالة الطلب إلى {Order.STATUS_LABELS.get(new_status)}', 'success')
        else:
            flash(message, 'danger')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(error, 'danger')
    
    return redirect(url_for('admin.order_detail', order_id=order_id))


@admin_bp.route('/orders/<int:order_id>/add-note', methods=['POST'])
def order_add_note(order_id):
    """إضافة ملاحظة للطلب"""
    order = Order.query.get_or_404(order_id)
    note = request.form.get('note', '').strip()
    
    if note:
        order.admin_notes = (order.admin_notes or '') + f'\n[{datetime.now().strftime("%Y-%m-%d %H:%M")}] {note}'
        db.session.commit()
        flash('تم إضافة الملاحظة', 'success')
    
    return redirect(url_for('admin.order_detail', order_id=order_id))


@admin_bp.route('/orders/export')
def orders_export():
    """تصدير الطلبات"""
    import csv
    from io import StringIO
    from flask import make_response
    
    status = request.args.get('status', '')
    date_from = request.args.get('from', '')
    date_to = request.args.get('to', '')
    
    query = Order.query
    
    if status:
        query = query.filter_by(status=status)
    if date_from:
        query = query.filter(Order.created_at >= datetime.strptime(date_from, '%Y-%m-%d'))
    if date_to:
        query = query.filter(Order.created_at <= datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1))
    
    orders = query.order_by(Order.created_at.desc()).all()
    
    # إنشاء CSV
    output = StringIO()
    writer = csv.writer(output)
    
    # العناوين
    writer.writerow([
        'رقم الطلب', 'التاريخ', 'العميل', 'الهاتف', 'الولاية', 'المدينة',
        'الحالة', 'حالة الدفع', 'المجموع', 'طريقة الدفع'
    ])
    
    # البيانات
    for order in orders:
        writer.writerow([
            order.order_number,
            order.created_at.strftime('%Y-%m-%d %H:%M'),
            order.shipping_name,
            order.shipping_phone,
            order.shipping_state,
            order.shipping_city,
            order.status_label,
            order.payment_status_label,
            float(order.total_amount),
            order.payment_method
        ])
    
    response = make_response(output.getvalue())
    response.headers['Content-Type'] = 'text/csv; charset=utf-8'
    response.headers['Content-Disposition'] = f'attachment; filename=orders_{datetime.now().strftime("%Y%m%d")}.csv'
    
    return response


# ==========================================
# 👥 Users - إدارة المستخدمين
# ==========================================

@admin_bp.route('/users')
def users():
    """قائمة المستخدمين"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('q', '').strip()
    status = request.args.get('status', '')
    
    query = User.query.filter_by(is_admin=False)
    
    # البحث
    if search:
        query = query.filter(
            db.or_(
                User.email.ilike(f'%{search}%'),
                User.phone.ilike(f'%{search}%'),
                User.first_name.ilike(f'%{search}%'),
                User.last_name.ilike(f'%{search}%')
            )
        )
    
    # فلترة بالحالة
    if status == 'verified':
        query = query.filter_by(email_verified=True)
    elif status == 'unverified':
        query = query.filter_by(email_verified=False)
    elif status == 'banned':
        query = query.filter_by(is_banned=True)
    
    users = query.order_by(User.created_at.desc()).paginate(
        page=page,
        per_page=current_app.config.get('ADMIN_ITEMS_PER_PAGE', 20)
    )
    
    return render_template('admin/users/index.html',
        users=users,
        search=search,
        current_status=status
    )


@admin_bp.route('/users/<int:user_id>')
def user_detail(user_id):
    """تفاصيل المستخدم"""
    user = User.query.get_or_404(user_id)
    
    # إحصائيات المستخدم
    stats = {
        'total_orders': user.total_orders,
        'total_spent': user.total_spent,
        'loyalty_points': user.loyalty_points,
        'tickets_count': user.tickets.count()
    }
    
    # أحدث الطلبات
    recent_orders = user.orders.order_by(Order.created_at.desc()).limit(5).all()
    
    return render_template('admin/users/detail.html',
        user=user,
        stats=stats,
        recent_orders=recent_orders
    )


@admin_bp.route('/users/<int:user_id>/ban', methods=['POST'])
def user_ban(user_id):
    """حظر مستخدم"""
    user = User.query.get_or_404(user_id)
    
    if user.is_admin:
        flash('لا يمكن حظر المشرفين', 'danger')
        return redirect(url_for('admin.user_detail', user_id=user_id))
    
    reason = request.form.get('reason', '')
    user.ban(reason)
    db.session.commit()
    
    flash('تم حظر المستخدم', 'success')
    return redirect(url_for('admin.user_detail', user_id=user_id))


@admin_bp.route('/users/<int:user_id>/unban', methods=['POST'])
def user_unban(user_id):
    """إلغاء حظر مستخدم"""
    user = User.query.get_or_404(user_id)
    user.unban()
    db.session.commit()
    
    flash('تم إلغاء حظر المستخدم', 'success')
    return redirect(url_for('admin.user_detail', user_id=user_id))


# ==========================================
# 🎫 Support Tickets - تذاكر الدعم
# ==========================================

@admin_bp.route('/tickets')
def tickets():
    """قائمة التذاكر"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '')
    priority = request.args.get('priority', '')
    category = request.args.get('category', '')
    
    query = Ticket.query
    
    if status:
        if status == 'open':
            query = query.filter(Ticket.status.in_(['open', 'in_progress', 'waiting_customer']))
        else:
            query = query.filter_by(status=status)
    
    if priority:
        query = query.filter_by(priority=priority)
    
    if category:
        query = query.filter_by(category=category)
    
    tickets = query.order_by(Ticket.updated_at.desc()).paginate(
        page=page,
        per_page=current_app.config.get('ADMIN_ITEMS_PER_PAGE', 20)
    )
    
    # إحصائيات
    stats = {
        'open': Ticket.query.filter_by(status='open').count(),
        'in_progress': Ticket.query.filter_by(status='in_progress').count(),
        'waiting': Ticket.query.filter_by(status='waiting_customer').count(),
        'urgent': Ticket.query.filter_by(priority='urgent', status='open').count()
    }
    
    return render_template('admin/tickets/index.html',
        tickets=tickets,
        stats=stats,
        current_status=status,
        current_priority=priority,
        current_category=category
    )


@admin_bp.route('/tickets/<int:ticket_id>')
def ticket_detail(ticket_id):
    """تفاصيل التذكرة"""
    ticket = Ticket.query.get_or_404(ticket_id)
    
    # تعيين الرسائل كمقروءة
    ticket.messages.filter_by(is_admin_reply=False, is_read=False).update({
        'is_read': True,
        'read_at': datetime.utcnow()
    })
    db.session.commit()
    
    # نموذج الرد
    reply_form = AdminTicketReplyForm()
    
    return render_template('admin/tickets/detail.html',
        ticket=ticket,
        reply_form=reply_form
    )


@admin_bp.route('/tickets/<int:ticket_id>/reply', methods=['POST'])
def ticket_reply(ticket_id):
    """الرد على التذكرة"""
    ticket = Ticket.query.get_or_404(ticket_id)
    form = AdminTicketReplyForm()
    
    if form.validate_on_submit():
        # إضافة الرسالة
        ticket.add_message(
            user_id=current_user.id,
            content=form.content.data,
            is_admin=True
        )
        
        # تحديث الحالة
        if form.status.data:
            ticket.update_status(form.status.data, current_user.id)
        
        # تعيين المشرف
        if not ticket.assigned_to:
            ticket.assign_to(current_user.id)
        
        db.session.commit()
        
        # إشعار العميل
        if not form.is_internal_note.data:
            email_service.send_ticket_reply(ticket, form.content.data)
        
        flash('تم إرسال الرد', 'success')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(error, 'danger')
    
    return redirect(url_for('admin.ticket_detail', ticket_id=ticket_id))


@admin_bp.route('/tickets/<int:ticket_id>/assign', methods=['POST'])
def ticket_assign(ticket_id):
    """تعيين التذكرة لمشرف"""
    ticket = Ticket.query.get_or_404(ticket_id)
    ticket.assign_to(current_user.id)
    db.session.commit()
    
    flash('تم تعيين التذكرة لك', 'success')
    return redirect(url_for('admin.ticket_detail', ticket_id=ticket_id))


# ==========================================
# 🏷️ Coupons - إدارة الكوبونات
# ==========================================

@admin_bp.route('/coupons')
def coupons():
    """قائمة الكوبونات"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '')
    
    query = Coupon.query
    
    if status == 'active':
        query = query.filter_by(is_active=True)
    elif status == 'inactive':
        query = query.filter_by(is_active=False)
    elif status == 'expired':
        query = query.filter(Coupon.expires_at < datetime.utcnow())
    
    coupons = query.order_by(Coupon.created_at.desc()).paginate(
        page=page,
        per_page=current_app.config.get('ADMIN_ITEMS_PER_PAGE', 20)
    )
    
    return render_template('admin/coupons/index.html',
        coupons=coupons,
        current_status=status
    )


@admin_bp.route('/coupons/create', methods=['GET', 'POST'])
def coupon_create():
    """إنشاء كوبون"""
    form = CouponAdminForm()
    
    if form.validate_on_submit():
        # التحقق من عدم تكرار الرمز
        existing = Coupon.query.filter_by(code=form.code.data.upper()).first()
        if existing:
            flash('رمز الكوبون مستخدم بالفعل', 'danger')
            return render_template('admin/coupons/form.html', form=form, title='إنشاء كوبون', is_edit=False)
        
        coupon = Coupon(
            code=form.code.data.upper(),
            description=form.description.data,
            discount_type=form.discount_type.data,
            discount_value=form.discount_value.data,
            maximum_discount=form.maximum_discount.data,
            minimum_amount=form.minimum_amount.data,
            usage_limit=form.usage_limit.data,
            usage_limit_per_user=form.usage_limit_per_user.data or 1,
            starts_at=form.starts_at.data,
            expires_at=form.expires_at.data,
            is_active=form.is_active.data,
            is_public=form.is_public.data,
            first_order_only=form.first_order_only.data,
            created_by=current_user.id
        )
        
        db.session.add(coupon)
        db.session.commit()
        
        flash('تم إنشاء الكوبون بنجاح', 'success')
        return redirect(url_for('admin.coupons'))
    
    return render_template('admin/coupons/form.html',
        form=form,
        title='إنشاء كوبون جديد',
        is_edit=False
    )


@admin_bp.route('/coupons/<int:coupon_id>/edit', methods=['GET', 'POST'])
def coupon_edit(coupon_id):
    """تعديل كوبون"""
    coupon = Coupon.query.get_or_404(coupon_id)
    form = CouponAdminForm(obj=coupon)
    
    if form.validate_on_submit():
        # التحقق من تكرار الرمز
        existing = Coupon.query.filter_by(code=form.code.data.upper()).first()
        if existing and existing.id != coupon.id:
            flash('رمز الكوبون مستخدم بالفعل', 'danger')
            return render_template('admin/coupons/form.html', form=form, coupon=coupon, title='تعديل الكوبون', is_edit=True)
        
        form.populate_obj(coupon)
        coupon.code = form.code.data.upper()
        db.session.commit()
        
        flash('تم تحديث الكوبون', 'success')
        return redirect(url_for('admin.coupons'))
    
    return render_template('admin/coupons/form.html',
        form=form,
        coupon=coupon,
        title='تعديل الكوبون',
        is_edit=True
    )


@admin_bp.route('/coupons/<int:coupon_id>/delete', methods=['POST'])
def coupon_delete(coupon_id):
    """حذف كوبون"""
    coupon = Coupon.query.get_or_404(coupon_id)
    db.session.delete(coupon)
    db.session.commit()
    
    flash('تم حذف الكوبون', 'success')
    return redirect(url_for('admin.coupons'))


# ==========================================
# 🚚 Shipping Zones - مناطق الشحن
# ==========================================

@admin_bp.route('/shipping-zones')
def shipping_zones():
    """قائمة مناطق الشحن"""
    zones = ShippingZone.query.order_by(ShippingZone.sort_order).all()
    return render_template('admin/shipping/index.html', zones=zones)


@admin_bp.route('/shipping-zones/create', methods=['GET', 'POST'])
def shipping_zone_create():
    """إضافة منطقة شحن"""
    form = ShippingZoneForm()
    
    if form.validate_on_submit():
        zone = ShippingZone(
            name=form.name.data,
            name_ar=form.name_ar.data,
            code=form.code.data,
            shipping_cost=form.shipping_cost.data,
            express_shipping_cost=form.express_shipping_cost.data,
            free_shipping_threshold=form.free_shipping_threshold.data,
            estimated_days_min=form.estimated_days_min.data,
            estimated_days_max=form.estimated_days_max.data,
            express_days=form.express_days.data,
            is_active=form.is_active.data,
            is_express_available=form.is_express_available.data,
            sort_order=form.sort_order.data or 0
        )
        
        db.session.add(zone)
        db.session.commit()
        
        flash('تم إضافة المنطقة', 'success')
        return redirect(url_for('admin.shipping_zones'))
    
    return render_template('admin/shipping/form.html',
        form=form,
        title='إضافة منطقة شحن'
    )


@admin_bp.route('/shipping-zones/<int:zone_id>/edit', methods=['GET', 'POST'])
def shipping_zone_edit(zone_id):
    """تعديل منطقة شحن"""
    zone = ShippingZone.query.get_or_404(zone_id)
    form = ShippingZoneForm(obj=zone)
    
    if form.validate_on_submit():
        form.populate_obj(zone)
        db.session.commit()
        
        flash('تم تحديث المنطقة', 'success')
        return redirect(url_for('admin.shipping_zones'))
    
    return render_template('admin/shipping/form.html',
        form=form,
        zone=zone,
        title='تعديل منطقة الشحن'
    )


@admin_bp.route('/shipping-zones/seed', methods=['POST'])
def shipping_zones_seed():
    """إضافة ولايات الجزائر"""
    ShippingZone.seed_algeria_wilayas()
    flash('تم إضافة الولايات الـ 58', 'success')
    return redirect(url_for('admin.shipping_zones'))


# ==========================================
# ⚙️ Settings - الإعدادات
# ==========================================

@admin_bp.route('/settings', methods=['GET', 'POST'])
def settings():
    """إعدادات الموقع"""
    site_settings = SiteSettings.get_settings()
    form = SiteSettingsForm(obj=site_settings)
    
    if form.validate_on_submit():
        # رفع الشعار
        if form.logo.data:
            result = storage_service.upload_image(
                form.logo.data,
                folder='settings',
                create_thumbnail=False
            )
            if result['success']:
                site_settings.logo_url = result['url']
        
        # رفع الأيقونة
        if form.favicon.data:
            result = storage_service.upload_image(
                form.favicon.data,
                folder='settings',
                create_thumbnail=False
            )
            if result['success']:
                site_settings.favicon_url = result['url']
        
        # تحديث باقي الحقول
        form.populate_obj(site_settings)
        db.session.commit()
        
        flash('تم حفظ الإعدادات', 'success')
        return redirect(url_for('admin.settings'))
    
    return render_template('admin/settings/index.html',
        form=form,
        settings=site_settings
    )


@admin_bp.route('/settings/legal', methods=['GET', 'POST'])
def settings_legal():
    """الصفحات القانونية"""
    site_settings = SiteSettings.get_settings()
    
    if request.method == 'POST':
        site_settings.terms_of_service = request.form.get('terms_of_service', '')
        site_settings.privacy_policy = request.form.get('privacy_policy', '')
        site_settings.return_policy = request.form.get('return_policy', '')
        site_settings.shipping_policy = request.form.get('shipping_policy', '')
        
        db.session.commit()
        flash('تم حفظ الصفحات القانونية', 'success')
        return redirect(url_for('admin.settings_legal'))
    
    return render_template('admin/settings/legal.html', settings=site_settings)


# ==========================================
# 📊 Reports - التقارير
# ==========================================

@admin_bp.route('/reports')
def reports():
    """صفحة التقارير"""
    return render_template('admin/reports/index.html')


@admin_bp.route('/reports/sales')
def reports_sales():
    """تقرير المبيعات"""
    period = request.args.get('period', '30')
    days = int(period)
    
    chart_data = AnalyticsService.get_revenue_chart(days=days)
    top_products = AnalyticsService.get_top_products(limit=10, days=days)
    category_sales = AnalyticsService.get_category_sales(days=days)
    
    # إجماليات
    start_date = datetime.utcnow() - timedelta(days=days)
    
    totals = db.session.query(
        func.count(Order.id).label('orders_count'),
        func.sum(Order.total_amount).label('total_revenue'),
        func.avg(Order.total_amount).label('avg_order_value')
    ).filter(
        Order.created_at >= start_date,
        Order.payment_status == 'paid'
    ).first()
    
    return render_template('admin/reports/sales.html',
        chart_data=chart_data,
        top_products=top_products,
        category_sales=category_sales,
        totals=totals,
        period=period
    )


@admin_bp.route('/reports/customers')
def reports_customers():
    """تقرير العملاء"""
    top_customers = AnalyticsService.get_top_customers(limit=20)
    
    # إحصائيات العملاء
    stats = {
        'total': User.query.filter_by(is_admin=False).count(),
        'verified': User.query.filter_by(is_admin=False, email_verified=True).count(),
        'with_orders': db.session.query(func.count(func.distinct(Order.user_id))).scalar(),
        'new_this_month': User.query.filter(
            User.created_at >= datetime.utcnow() - timedelta(days=30)
        ).count()
    }
    
    return render_template('admin/reports/customers.html',
        top_customers=top_customers,
        stats=stats
    )


# ==========================================
# 🔔 Notifications
# ==========================================

@admin_bp.route('/notifications')
def notifications():
    """إشعارات المشرف"""
    # الطلبات الجديدة
    new_orders = Order.query.filter_by(status='pending').count()
    
    # التذاكر الجديدة
    new_tickets = Ticket.query.filter_by(status='open').count()
    
    # منتجات نفدت
    out_of_stock = Product.query.filter(
        Product.is_active == True,
        Product.stock_quantity <= 0
    ).count()
    
    # تقييمات تنتظر الموافقة
    pending_reviews = ProductReview.query.filter_by(is_approved=False).count()
    
    return render_template('admin/notifications.html',
        new_orders=new_orders,
        new_tickets=new_tickets,
        out_of_stock=out_of_stock,
        pending_reviews=pending_reviews
    )


# ==========================================
# ⭐ Reviews Management
# ==========================================

@admin_bp.route('/reviews')
def reviews():
    """إدارة التقييمات"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '')
    
    query = ProductReview.query
    
    if status == 'pending':
        query = query.filter_by(is_approved=False)
    elif status == 'approved':
        query = query.filter_by(is_approved=True)
    
    reviews = query.order_by(ProductReview.created_at.desc()).paginate(
        page=page,
        per_page=20
    )
    
    return render_template('admin/reviews/index.html',
        reviews=reviews,
        current_status=status
    )


@admin_bp.route('/reviews/<int:review_id>/approve', methods=['POST'])
def review_approve(review_id):
    """الموافقة على تقييم"""
    review = ProductReview.query.get_or_404(review_id)
    review.approve(current_user.id)
    db.session.commit()
    
    flash('تم الموافقة على التقييم', 'success')
    return redirect(url_for('admin.reviews'))


@admin_bp.route('/reviews/<int:review_id>/reject', methods=['POST'])
def review_reject(review_id):
    """رفض تقييم"""
    review = ProductReview.query.get_or_404(review_id)
    reason = request.form.get('reason', '')
    review.reject(current_user.id, reason)
    db.session.commit()
    
    flash('تم رفض التقييم', 'success')
    return redirect(url_for('admin.reviews'))


@admin_bp.route('/reviews/<int:review_id>/delete', methods=['POST'])
def review_delete(review_id):
    """حذف تقييم"""
    review = ProductReview.query.get_or_404(review_id)
    product = review.product
    
    db.session.delete(review)
    product.update_rating()
    db.session.commit()
    
    flash('تم حذف التقييم', 'success')
    return redirect(url_for('admin.reviews'))