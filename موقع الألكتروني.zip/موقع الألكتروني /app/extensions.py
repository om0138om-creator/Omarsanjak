"""
======================================
🔌 Flask Extensions
======================================
تهيئة جميع الإضافات
"""

from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from flask_mail import Mail
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_caching import Cache

# ==========================================
# 🗄️ Database
# ==========================================
db = SQLAlchemy()
migrate = Migrate()

# ==========================================
# 🔐 Authentication
# ==========================================
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = 'يرجى تسجيل الدخول للوصول إلى هذه الصفحة.'
login_manager.login_message_category = 'warning'
login_manager.session_protection = 'strong'

# ==========================================
# 🛡️ Security
# ==========================================
csrf = CSRFProtect()

# ==========================================
# 📧 Email
# ==========================================
mail = Mail()

# ==========================================
# 🌐 CORS
# ==========================================
cors = CORS()

# ==========================================
# ⚡ Rate Limiting
# ==========================================
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"],
    storage_uri="memory://"
)

# ==========================================
# 💾 Caching
# ==========================================
cache = Cache()


def init_extensions(app):
    """تهيئة جميع الإضافات مع التطبيق"""
    
    # Database
    db.init_app(app)
    migrate.init_app(app, db)
    
    # Authentication
    login_manager.init_app(app)
    
    # Security
    csrf.init_app(app)
    
    # Email
    mail.init_app(app)
    
    # CORS - allow specific origins
    cors.init_app(app, resources={
        r"/api/*": {
            "origins": app.config.get('ALLOWED_HOSTS', ['localhost']),
            "methods": ["GET", "POST", "PUT", "DELETE"],
            "allow_headers": ["Content-Type", "Authorization"]
        }
    })
    
    # Rate Limiting
    limiter.init_app(app)
    
    # Caching
    cache_config = {
        'CACHE_TYPE': app.config.get('CACHE_TYPE', 'simple'),
        'CACHE_DEFAULT_TIMEOUT': app.config.get('CACHE_DEFAULT_TIMEOUT', 300)
    }
    if app.config.get('REDIS_URL'):
        cache_config['CACHE_REDIS_URL'] = app.config['REDIS_URL']
    cache.init_app(app, config=cache_config)
    
    # User loader for Flask-Login
    from app.models.user import User
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    @login_manager.unauthorized_handler
    def unauthorized():
        from flask import request, redirect, url_for, flash, jsonify
        
        if request.is_json or request.path.startswith('/api/'):
            return jsonify({
                'success': False,
                'message': 'يرجى تسجيل الدخول'
            }), 401
        
        flash('يرجى تسجيل الدخول للوصول إلى هذه الصفحة.', 'warning')
        return redirect(url_for('auth.login', next=request.url))