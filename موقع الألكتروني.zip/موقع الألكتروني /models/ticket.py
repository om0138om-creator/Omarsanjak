"""
======================================
🎫 Ticket Model
======================================
نموذج تذاكر الدعم الفني
"""

from datetime import datetime
import secrets

from app.extensions import db


class Ticket(db.Model):
    """نموذج تذكرة الدعم"""
    
    __tablename__ = 'tickets'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # ==========================================
    # 🔑 Ticket Identification
    # ==========================================
    ticket_number = db.Column(db.String(20), unique=True, nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # ==========================================
    # 📝 Ticket Details
    # ==========================================
    subject = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    
    # ==========================================
    # 🏷️ Categorization
    # ==========================================
    # order, product, payment, shipping, account, other
    category = db.Column(db.String(50), default='other', nullable=False)
    
    # low, medium, high, urgent
    priority = db.Column(db.String(20), default='medium', nullable=False)
    
    # ==========================================
    # 📊 Status
    # ==========================================
    # open, in_progress, waiting_customer, resolved, closed
    status = db.Column(db.String(20), default='open', nullable=False, index=True)
    
    # ==========================================
    # 🔗 Related Order
    # ==========================================
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=True)
    
    # ==========================================
    # 👤 Assignment
    # ==========================================
    assigned_to = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    assigned_at = db.Column(db.DateTime, nullable=True)
    
    # ==========================================
    # ⏰ Timestamps
    # ==========================================
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    first_response_at = db.Column(db.DateTime, nullable=True)
    resolved_at = db.Column(db.DateTime, nullable=True)
    closed_at = db.Column(db.DateTime, nullable=True)
    
    # ==========================================
    # ⭐ Feedback
    # ==========================================
    satisfaction_rating = db.Column(db.Integer, nullable=True)  # 1-5
    feedback = db.Column(db.Text, nullable=True)
    
    # ==========================================
    # 🔗 Relationships
    # ==========================================
    messages = db.relationship('TicketMessage', backref='ticket', lazy='dynamic',
                              cascade='all, delete-orphan',
                              order_by='TicketMessage.created_at')
    order = db.relationship('Order', backref='tickets')
    assignee = db.relationship('User', foreign_keys=[assigned_to], backref='assigned_tickets')
    
    # ==========================================
    # Labels
    # ==========================================
    CATEGORY_LABELS = {
        'order': 'الطلبات',
        'product': 'المنتجات',
        'payment': 'الدفع',
        'shipping': 'الشحن والتوصيل',
        'account': 'الحساب',
        'other': 'أخرى'
    }
    
    PRIORITY_LABELS = {
        'low': 'منخفضة',
        'medium': 'متوسطة',
        'high': 'عالية',
        'urgent': 'عاجلة'
    }
    
    STATUS_LABELS = {
        'open': 'مفتوحة',
        'in_progress': 'قيد المعالجة',
        'waiting_customer': 'بانتظار الرد',
        'resolved': 'تم الحل',
        'closed': 'مغلقة'
    }
    
    def __init__(self, **kwargs):
        super(Ticket, self).__init__(**kwargs)
        if not self.ticket_number:
            self.ticket_number = self.generate_ticket_number()
    
    @staticmethod
    def generate_ticket_number():
        """توليد رقم تذكرة فريد"""
        timestamp = datetime.utcnow().strftime('%y%m%d')
        random_part = secrets.token_hex(3).upper()
        return f"TKT-{timestamp}-{random_part}"
    
    # ==========================================
    # 📊 Status Methods
    # ==========================================
    def update_status(self, new_status, user_id=None):
        """تحديث حالة التذكرة"""
        old_status = self.status
        self.status = new_status
        
        now = datetime.utcnow()
        if new_status == 'resolved':
            self.resolved_at = now
        elif new_status == 'closed':
            self.closed_at = now
        
        self.updated_at = now
        return old_status
    
    def assign_to(self, admin_id):
        """تعيين التذكرة لمشرف"""
        self.assigned_to = admin_id
        self.assigned_at = datetime.utcnow()
        if self.status == 'open':
            self.status = 'in_progress'
    
    # ==========================================
    # 💬 Message Methods
    # ==========================================
    def add_message(self, user_id, content, is_admin=False, attachments=None):
        """إضافة رسالة"""
        message = TicketMessage(
            ticket_id=self.id,
            user_id=user_id,
            content=content,
            is_admin_reply=is_admin,
            attachments=attachments
        )
        db.session.add(message)
        
        # تحديث وقت أول رد
        if is_admin and not self.first_response_at:
            self.first_response_at = datetime.utcnow()
        
        # تحديث الحالة
        if is_admin:
            self.status = 'waiting_customer'
        else:
            if self.status == 'waiting_customer':
                self.status = 'in_progress'
        
        self.updated_at = datetime.utcnow()
        return message
    
    @property
    def messages_count(self):
        """عدد الرسائل"""
        return self.messages.count()
    
    @property
    def last_message(self):
        """آخر رسالة"""
        return self.messages.order_by(TicketMessage.created_at.desc()).first()
    
    @property
    def unread_count(self):
        """عدد الرسائل غير المقروءة"""
        return self.messages.filter_by(is_read=False).count()
    
    # ==========================================
    # 📊 Properties
    # ==========================================
    @property
    def category_label(self):
        return self.CATEGORY_LABELS.get(self.category, self.category)
    
    @property
    def priority_label(self):
        return self.PRIORITY_LABELS.get(self.priority, self.priority)
    
    @property
    def status_label(self):
        return self.STATUS_LABELS.get(self.status, self.status)
    
    @property
    def priority_color(self):
        colors = {
            'low': 'success',
            'medium': 'info',
            'high': 'warning',
            'urgent': 'danger'
        }
        return colors.get(self.priority, 'secondary')
    
    @property
    def status_color(self):
        colors = {
            'open': 'info',
            'in_progress': 'primary',
            'waiting_customer': 'warning',
            'resolved': 'success',
            'closed': 'secondary'
        }
        return colors.get(self.status, 'secondary')
    
    @property
    def is_open(self):
        return self.status not in ['resolved', 'closed']
    
    @property
    def response_time(self):
        """وقت الرد (بالدقائق)"""
        if not self.first_response_at:
            return None
        delta = self.first_response_at - self.created_at
        return int(delta.total_seconds() / 60)
    
    @property
    def resolution_time(self):
        """وقت الحل (بالساعات)"""
        if not self.resolved_at:
            return None
        delta = self.resolved_at - self.created_at
        return round(delta.total_seconds() / 3600, 1)
    
    # ==========================================
    # 📤 Serialization
    # ==========================================
    def to_dict(self, include_messages=False):
        data = {
            'id': self.id,
            'ticket_number': self.ticket_number,
            'subject': self.subject,
            'description': self.description,
            'category': self.category,
            'category_label': self.category_label,
            'priority': self.priority,
            'priority_label': self.priority_label,
            'priority_color': self.priority_color,
            'status': self.status,
            'status_label': self.status_label,
            'status_color': self.status_color,
            'is_open': self.is_open,
            'order_id': self.order_id,
            'order_number': self.order.order_number if self.order else None,
            'user': {
                'id': self.user.id,
                'name': self.user.full_name,
                'email': self.user.email
            } if self.user else None,
            'assigned_to': self.assignee.full_name if self.assignee else None,
            'messages_count': self.messages_count,
            'response_time': self.response_time,
            'resolution_time': self.resolution_time,
            'satisfaction_rating': self.satisfaction_rating,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None
        }
        
        if include_messages:
            data['messages'] = [m.to_dict() for m in self.messages]
        
        return data
    
    def __repr__(self):
        return f'<Ticket {self.ticket_number}>'


class TicketMessage(db.Model):
    """نموذج رسالة في التذكرة"""
    
    __tablename__ = 'ticket_messages'
    
    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, db.ForeignKey('tickets.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    content = db.Column(db.Text, nullable=False)
    
    is_admin_reply = db.Column(db.Boolean, default=False)
    is_internal_note = db.Column(db.Boolean, default=False)  # ملاحظة داخلية (لا تظهر للعميل)
    is_read = db.Column(db.Boolean, default=False)
    
    # المرفقات
    attachments = db.Column(db.JSON, nullable=True)  # قائمة روابط الملفات
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    read_at = db.Column(db.DateTime, nullable=True)
    
    # Relationship
    sender = db.relationship('User', backref='ticket_messages')
    
    def mark_as_read(self):
        """تعيين كمقروءة"""
        if not self.is_read:
            self.is_read = True
            self.read_at = datetime.utcnow()
    
    def to_dict(self):
        return {
            'id': self.id,
            'content': self.content,
            'is_admin_reply': self.is_admin_reply,
            'is_internal_note': self.is_internal_note,
            'is_read': self.is_read,
            'attachments': self.attachments,
            'sender': {
                'id': self.sender.id,
                'name': self.sender.full_name,
                'avatar': self.sender.avatar_url,
                'is_admin': self.sender.is_admin
            } if self.sender else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f'<TicketMessage {self.id}>'