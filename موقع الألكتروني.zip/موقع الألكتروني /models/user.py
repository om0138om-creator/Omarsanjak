"""
======================================
👤 User Model
======================================
نموذج المستخدم والعناوين والمفضلة
"""

from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadSignature
from flask import current_app
import secrets

from app.extensions import db


class User(UserMixin, db.Model):
    """نموذج المستخدم الرئيسي"""
    
    __tablename__ = 'users'
    
    # ==========================================
    # 🔑 Primary Fields
    # ==========================================
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(36), unique=True, nullable=False, 
                     default=lambda: secrets.token_hex(16))
    
    # ==========================================
    # 👤 Personal Information
    # ==========================================
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    phone = db.Column(db.String(20), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    
    avatar_url = db.Column(db.String(500), nullable=True)
    date_of_birth = db.Column(db.Date, nullable=True)
    gender = db.Column(db.String(10), nullable=True)  # male, female, other
    
    # ==========================================
    # ✅ Verification Status
    # ==========================================
    email_verified = db.Column(db.Boolean, default=False, nullable=False)
    email_verified_at = db.Column(db.DateTime, nullable=True)
    phone_verified = db.Column(db.Boolean, default=False, nullable=False)
    phone_verified_at = db.Column(db.DateTime, nullable=True)
    
    # ==========================================
    # 🔐 Account Status
    # ==========================================
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    is_banned = db.Column(db.Boolean, default=False, nullable=False)
    ban_reason = db.Column(db.String(500), nullable=True)
    banned_at = db.Column(db.DateTime, nullable=True)
    
    # ==========================================
    # 🔄 Authentication Tracking
    # ==========================================
    last_login_at = db.Column(db.DateTime, nullable=True)
    last_login_ip = db.Column(db.String(45), nullable=True)
    login_count = db.Column(db.Integer, default=0)
    failed_login_attempts = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime, nullable=True)
    
    # ==========================================
    # 🔑 Password Reset
    # ==========================================
    password_reset_token = db.Column(db.String(256), nullable=True)
    password_reset_expires = db.Column(db.DateTime, nullable=True)
    password_changed_at = db.Column(db.DateTime, nullable=True)
    
    # ==========================================
    # 📊 Statistics
    # ==========================================
    total_orders = db.Column(db.Integer, default=0)
    total_spent = db.Column(db.Float, default=0.0)
    loyalty_points = db.Column(db.Integer, default=0)
    
    # ==========================================
    # ⏰ Timestamps
    # ==========================================
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, 
                          onupdate=datetime.utcnow, nullable=False)
    
    # ==========================================
    # 🔗 Relationships
    # ==========================================
    addresses = db.relationship('UserAddress', backref='user', lazy='dynamic',
                               cascade='all, delete-orphan')
    wishlist = db.relationship('UserWishlist', backref='user', lazy='dynamic',
                              cascade='all, delete-orphan')
    orders = db.relationship('Order', backref='user', lazy='dynamic')
    reviews = db.relationship('ProductReview', backref='user', lazy='dynamic')
    tickets = db.relationship('Ticket', backref='user', lazy='dynamic')
    notifications = db.relationship('Notification', backref='user', lazy='dynamic',
                                   cascade='all, delete-orphan')
    cart = db.relationship('Cart', backref='user', uselist=False,
                          cascade='all, delete-orphan')
    
    # ==========================================
    # 🔧 Password Methods
    # ==========================================
    def set_password(self, password):
        """تشفير وتعيين كلمة المرور"""
        self.password_hash = generate_password_hash(
            password,
            method='pbkdf2:sha256',
            salt_length=16
        )
        self.password_changed_at = datetime.utcnow()
    
    def check_password(self, password):
        """التحقق من كلمة المرور"""
        return check_password_hash(self.password_hash, password)
    
    def is_password_expired(self, days=90):
        """التحقق من انتهاء صلاحية كلمة المرور"""
        if not self.password_changed_at:
            return False
        return datetime.utcnow() > self.password_changed_at + timedelta(days=days)
    
    # ==========================================
    # 📧 Email Verification Methods
    # ==========================================
    def generate_email_token(self, expiration=86400):
        """توليد رمز تأكيد البريد الإلكتروني (24 ساعة)"""
        serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
        return serializer.dumps(
            {'user_id': self.id, 'email': self.email},
            salt='email-verification-salt'
        )
    
    @staticmethod
    def verify_email_token(token, expiration=86400):
        """التحقق من رمز تأكيد البريد الإلكتروني"""
        serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
        try:
            data = serializer.loads(
                token,
                salt='email-verification-salt',
                max_age=expiration
            )
            return User.query.get(data['user_id'])
        except (SignatureExpired, BadSignature):
            return None
    
    def verify_email(self):
        """تأكيد البريد الإلكتروني"""
        self.email_verified = True
        self.email_verified_at = datetime.utcnow()
    
    # ==========================================
    # 🔑 Password Reset Methods
    # ==========================================
    def generate_reset_token(self, expiration=3600):
        """توليد رمز إعادة تعيين كلمة المرور (1 ساعة)"""
        serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
        token = serializer.dumps(
            {'user_id': self.id},
            salt='password-reset-salt'
        )
        self.password_reset_token = token
        self.password_reset_expires = datetime.utcnow() + timedelta(seconds=expiration)
        return token
    
    @staticmethod
    def verify_reset_token(token, expiration=3600):
        """التحقق من رمز إعادة التعيين"""
        serializer = URLSafeTimedSerializer(current_app.config['SECRET_KEY'])
        try:
            data = serializer.loads(
                token,
                salt='password-reset-salt',
                max_age=expiration
            )
            user = User.query.get(data['user_id'])
            if user and user.password_reset_token == token:
                return user
            return None
        except (SignatureExpired, BadSignature):
            return None
    
    def clear_reset_token(self):
        """مسح رمز إعادة التعيين"""
        self.password_reset_token = None
        self.password_reset_expires = None
    
    # ==========================================
    # 🔒 Account Security Methods
    # ==========================================
    def record_login(self, ip_address):
        """تسجيل عملية الدخول"""
        self.last_login_at = datetime.utcnow()
        self.last_login_ip = ip_address
        self.login_count += 1
        self.failed_login_attempts = 0
        self.locked_until = None
    
    def record_failed_login(self):
        """تسجيل محاولة دخول فاشلة"""
        self.failed_login_attempts += 1
        if self.failed_login_attempts >= 5:
            self.locked_until = datetime.utcnow() + timedelta(minutes=30)
    
    def is_locked(self):
        """التحقق من قفل الحساب"""
        if self.locked_until and datetime.utcnow() < self.locked_until:
            return True
        return False
    
    def ban(self, reason=None):
        """حظر المستخدم"""
        self.is_banned = True
        self.ban_reason = reason
        self.banned_at = datetime.utcnow()
    
    def unban(self):
        """إلغاء حظر المستخدم"""
        self.is_banned = False
        self.ban_reason = None
        self.banned_at = None
    
    # ==========================================
    # 📊 Statistics Methods
    # ==========================================
    def update_statistics(self, order_total):
        """تحديث إحصائيات المستخدم"""
        self.total_orders += 1
        self.total_spent += order_total
        # نقاط الولاء: 1 نقطة لكل 100 دينار
        self.loyalty_points += int(order_total / 100)
    
    def get_loyalty_tier(self):
        """الحصول على مستوى الولاء"""
        if self.loyalty_points >= 10000:
            return 'platinum'
        elif self.loyalty_points >= 5000:
            return 'gold'
        elif self.loyalty_points >= 1000:
            return 'silver'
        return 'bronze'
    
    # ==========================================
    # 🔧 Utility Methods
    # ==========================================
    @property
    def full_name(self):
        """الاسم الكامل"""
        return f"{self.first_name} {self.last_name}"
    
    @property
    def is_verified(self):
        """التحقق من اكتمال التوثيق"""
        return self.email_verified
    
    def can_purchase(self):
        """التحقق من إمكانية الشراء"""
        return (
            self.is_active and 
            not self.is_banned and 
            self.email_verified
        )
    
    def get_default_address(self):
        """الحصول على العنوان الافتراضي"""
        return self.addresses.filter_by(is_default=True).first()
    
    def get_unread_notifications_count(self):
        """عدد الإشعارات غير المقروءة"""
        return self.notifications.filter_by(is_read=False).count()
    
    def to_dict(self, include_sensitive=False):
        """تحويل إلى قاموس"""
        data = {
            'id': self.id,
            'uuid': self.uuid,
            'email': self.email,
            'phone': self.phone,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'full_name': self.full_name,
            'avatar_url': self.avatar_url,
            'email_verified': self.email_verified,
            'is_admin': self.is_admin,
            'loyalty_points': self.loyalty_points,
            'loyalty_tier': self.get_loyalty_tier(),
            'total_orders': self.total_orders,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
        
        if include_sensitive:
            data.update({
                'total_spent': self.total_spent,
                'last_login_at': self.last_login_at.isoformat() if self.last_login_at else None,
                'is_banned': self.is_banned,
                'ban_reason': self.ban_reason
            })
        
        return data
    
    def __repr__(self):
        return f'<User {self.email}>'


class UserAddress(db.Model):
    """نموذج عناوين المستخدم"""
    
    __tablename__ = 'user_addresses'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # ==========================================
    # 📍 Address Details
    # ==========================================
    label = db.Column(db.String(50), nullable=True)  # المنزل، العمل، إلخ
    full_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    
    # العنوان
    street_address = db.Column(db.String(255), nullable=False)
    street_address_2 = db.Column(db.String(255), nullable=True)
    city = db.Column(db.String(100), nullable=False)
    state = db.Column(db.String(100), nullable=False)  # الولاية
    postal_code = db.Column(db.String(20), nullable=True)
    country = db.Column(db.String(2), default='DZ', nullable=False)
    
    # الإحداثيات الجغرافية
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    
    # ==========================================
    # ⚙️ Settings
    # ==========================================
    is_default = db.Column(db.Boolean, default=False, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    
    # ==========================================
    # ⏰ Timestamps
    # ==========================================
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def set_as_default(self):
        """تعيين كعنوان افتراضي"""
        # إلغاء الافتراضي من العناوين الأخرى
        UserAddress.query.filter_by(
            user_id=self.user_id,
            is_default=True
        ).update({'is_default': False})
        self.is_default = True
    
    @property
    def full_address(self):
        """العنوان الكامل"""
        parts = [self.street_address]
        if self.street_address_2:
            parts.append(self.street_address_2)
        parts.extend([self.city, self.state])
        if self.postal_code:
            parts.append(self.postal_code)
        return ', '.join(parts)
    
    def to_dict(self):
        return {
            'id': self.id,
            'label': self.label,
            'full_name': self.full_name,
            'phone': self.phone,
            'street_address': self.street_address,
            'street_address_2': self.street_address_2,
            'city': self.city,
            'state': self.state,
            'postal_code': self.postal_code,
            'country': self.country,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'is_default': self.is_default,
            'full_address': self.full_address
        }
    
    def __repr__(self):
        return f'<UserAddress {self.id} - {self.city}>'


class UserWishlist(db.Model):
    """نموذج قائمة المفضلة"""
    
    __tablename__ = 'user_wishlist'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    
    # Notification preferences
    notify_on_sale = db.Column(db.Boolean, default=True)
    notify_on_restock = db.Column(db.Boolean, default=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    product = db.relationship('Product', backref='wishlisted_by')
    
    # Unique constraint
    __table_args__ = (
        db.UniqueConstraint('user_id', 'product_id', name='unique_wishlist_item'),
    )
    
    def __repr__(self):
        return f'<Wishlist User:{self.user_id} Product:{self.product_id}>'