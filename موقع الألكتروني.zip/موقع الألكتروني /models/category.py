"""
======================================
📁 Category Model
======================================
نموذج التصنيفات (رئيسية وفرعية)
"""

from datetime import datetime
from slugify import slugify
from app.extensions import db


class Category(db.Model):
    """نموذج التصنيفات"""
    
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # ==========================================
    # 📝 Basic Information
    # ==========================================
    name = db.Column(db.String(100), nullable=False)
    name_ar = db.Column(db.String(100), nullable=True)  # الاسم بالعربية
    slug = db.Column(db.String(120), unique=True, nullable=False, index=True)
    description = db.Column(db.Text, nullable=True)
    
    # ==========================================
    # 🖼️ Visual
    # ==========================================
    image_url = db.Column(db.String(500), nullable=True)
    icon = db.Column(db.String(50), nullable=True)  # CSS class for icon
    color = db.Column(db.String(7), nullable=True)  # Hex color
    
    # ==========================================
    # 🔗 Hierarchy (Parent-Child)
    # ==========================================
    parent_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=True)
    level = db.Column(db.Integer, default=0)  # 0 = root, 1 = child, 2 = grandchild
    
    # ==========================================
    # ⚙️ Settings
    # ==========================================
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    is_featured = db.Column(db.Boolean, default=False)  # عرض في الصفحة الرئيسية
    show_in_menu = db.Column(db.Boolean, default=True)  # عرض في القائمة
    sort_order = db.Column(db.Integer, default=0)  # ترتيب العرض
    
    # ==========================================
    # 📊 Statistics
    # ==========================================
    products_count = db.Column(db.Integer, default=0)
    views_count = db.Column(db.Integer, default=0)
    
    # ==========================================
    # 🔍 SEO
    # ==========================================
    meta_title = db.Column(db.String(70), nullable=True)
    meta_description = db.Column(db.String(160), nullable=True)
    meta_keywords = db.Column(db.String(255), nullable=True)
    
    # ==========================================
    # ⏰ Timestamps
    # ==========================================
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # ==========================================
    # 🔗 Relationships
    # ==========================================
    # Self-referential relationship for subcategories
    children = db.relationship(
        'Category',
        backref=db.backref('parent', remote_side=[id]),
        lazy='dynamic',
        cascade='all, delete-orphan'
    )
    
    # Products relationship
    products = db.relationship('Product', backref='category', lazy='dynamic')
    
    # ==========================================
    # 🔧 Methods
    # ==========================================
    def __init__(self, **kwargs):
        super(Category, self).__init__(**kwargs)
        if not self.slug and self.name:
            self.generate_slug()
        if self.parent_id:
            parent = Category.query.get(self.parent_id)
            self.level = parent.level + 1 if parent else 0
    
    def generate_slug(self):
        """توليد slug فريد"""
        base_slug = slugify(self.name, allow_unicode=True)
        slug = base_slug
        counter = 1
        while Category.query.filter_by(slug=slug).first():
            slug = f"{base_slug}-{counter}"
            counter += 1
        self.slug = slug
    
    def update_products_count(self):
        """تحديث عدد المنتجات"""
        self.products_count = self.products.filter_by(is_active=True).count()
        # إضافة منتجات الفئات الفرعية
        for child in self.children:
            self.products_count += child.products.filter_by(is_active=True).count()
    
    def increment_views(self):
        """زيادة عدد المشاهدات"""
        self.views_count += 1
    
    def get_all_children(self):
        """الحصول على جميع الفئات الفرعية (متداخلة)"""
        result = []
        for child in self.children.filter_by(is_active=True):
            result.append(child)
            result.extend(child.get_all_children())
        return result
    
    def get_ancestors(self):
        """الحصول على جميع الفئات الأصلية"""
        ancestors = []
        current = self.parent
        while current:
            ancestors.insert(0, current)
            current = current.parent
        return ancestors
    
    def get_breadcrumb(self):
        """الحصول على مسار التنقل"""
        breadcrumb = self.get_ancestors()
        breadcrumb.append(self)
        return breadcrumb
    
    @property
    def display_name(self):
        """الاسم للعرض (عربي أو إنجليزي)"""
        return self.name_ar or self.name
    
    @property
    def has_children(self):
        """التحقق من وجود فئات فرعية"""
        return self.children.filter_by(is_active=True).count() > 0
    
    @property
    def is_root(self):
        """هل هي فئة رئيسية؟"""
        return self.parent_id is None
    
    @classmethod
    def get_root_categories(cls):
        """الحصول على الفئات الرئيسية"""
        return cls.query.filter_by(
            parent_id=None,
            is_active=True
        ).order_by(cls.sort_order).all()
    
    @classmethod
    def get_menu_categories(cls):
        """الحصول على فئات القائمة"""
        return cls.query.filter_by(
            parent_id=None,
            is_active=True,
            show_in_menu=True
        ).order_by(cls.sort_order).all()
    
    @classmethod
    def get_featured_categories(cls):
        """الحصول على الفئات المميزة"""
        return cls.query.filter_by(
            is_active=True,
            is_featured=True
        ).order_by(cls.sort_order).all()
    
    def to_dict(self, include_children=False):
        """تحويل إلى قاموس"""
        data = {
            'id': self.id,
            'name': self.name,
            'name_ar': self.name_ar,
            'display_name': self.display_name,
            'slug': self.slug,
            'description': self.description,
            'image_url': self.image_url,
            'icon': self.icon,
            'parent_id': self.parent_id,
            'level': self.level,
            'is_active': self.is_active,
            'is_featured': self.is_featured,
            'products_count': self.products_count,
            'has_children': self.has_children
        }
        
        if include_children:
            data['children'] = [
                child.to_dict(include_children=True) 
                for child in self.children.filter_by(is_active=True)
            ]
        
        return data
    
    def __repr__(self):
        return f'<Category {self.name}>'