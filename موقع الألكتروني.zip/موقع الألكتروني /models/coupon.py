"""
======================================
🏷️ Coupon Model
======================================
نموذج كوبونات الخصم
"""

from datetime import datetime
from app.extensions import db


class Coupon(db.Model):
    """نموذج كوبون الخصم"""
    
    __tablename__ = 'coupons'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # ==========================================
    # 🏷️ Coupon Details
    # ==========================================
    code = db.Column(db.String(50), unique=True, nullable=False, index=True)
    description = db.Column(db.String(255), nullable=True)
    
    # ==========================================
    # 💰 Discount Type
    # ==========================================
    # percentage, fixed, free_shipping
    discount_type = db.Column(db.String(20), nullable=False, default='percentage')
    discount_value = db.Column(db.Numeric(12, 2), nullable=False)
    
    # الحد الأقصى للخصم (للنسبة المئوية)
    maximum_discount = db.Column(db.Numeric(12, 2), nullable=True)
    
    # ==========================================
    # 📋 Conditions
    # ==========================================
    minimum_amount = db.Column(db.Numeric(12, 2), nullable=True)  # الحد الأدنى للطلب
    minimum_items = db.Column(db.Integer, nullable=True)  # الحد الأدنى للمنتجات
    
    # ==========================================
    # 🔢 Usage Limits
    # ==========================================
    usage_limit = db.Column(db.Integer, nullable=True)  # الحد الأقصى للاستخدام الكلي
    usage_limit_per_user = db.Column(db.Integer, default=1)  # لكل مستخدم
    usage_count = db.Column(db.Integer, default=0)  # عدد مرات الاستخدام
    
    # ==========================================
    # 📅 Validity Period
    # ==========================================
    starts_at = db.Column(db.DateTime, nullable=True)
    expires_at = db.Column(db.DateTime, nullable=True)
    
    # ==========================================
    # 🎯 Targeting
    # ==========================================
    # تطبيق على منتجات/فئات معينة
    applicable_products = db.Column(db.JSON, nullable=True)  # قائمة IDs
    applicable_categories = db.Column(db.JSON, nullable=True)  # قائمة IDs
    excluded_products = db.Column(db.JSON, nullable=True)
    excluded_categories = db.Column(db.JSON, nullable=True)
    
    # مستخدمين معينين
    allowed_users = db.Column(db.JSON, nullable=True)  # قائمة IDs
    
    # ==========================================
    # ⚙️ Settings
    # ==========================================
    is_active = db.Column(db.Boolean, default=True)
    is_public = db.Column(db.Boolean, default=True)  # ظاهر للجميع
    first_order_only = db.Column(db.Boolean, default=False)  # للطلب الأول فقط
    
    # ==========================================
    # ⏰ Timestamps
    # ==========================================
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    # ==========================================
    # 🔗 Relationships
    # ==========================================
    usages = db.relationship('CouponUsage', backref='coupon', lazy='dynamic',
                            cascade='all, delete-orphan')
    
    # ==========================================
    # 🔧 Validation Methods
    # ==========================================
    def is_valid(self):
        """التحقق من صلاحية الكوبون"""
        if not self.is_active:
            return False
        
        now = datetime.utcnow()
        
        # التحقق من تاريخ البدء
        if self.starts_at and now < self.starts_at:
            return False
        
        # التحقق من تاريخ الانتهاء
        if self.expires_at and now > self.expires_at:
            return False
        
        # التحقق من حد الاستخدام
        if self.usage_limit and self.usage_count >= self.usage_limit:
            return False
        
        return True
    
    def is_valid_for_user(self, user_id):
        """التحقق من صلاحية الكوبون للمستخدم"""
        if not self.is_valid():
            return False, "الكوبون غير صالح أو منتهي"
        
        # التحقق من المستخدمين المسموح لهم
        if self.allowed_users and user_id not in self.allowed_users:
            return False, "هذا الكوبون غير متاح لك"
        
        # التحقق من استخدام المستخدم
        if self.has_user_used(user_id):
            user_usage = self.get_user_usage_count(user_id)
            if user_usage >= self.usage_limit_per_user:
                return False, "لقد وصلت للحد الأقصى من استخدام هذا الكوبون"
        
        # التحقق من الطلب الأول
        if self.first_order_only:
            from app.models.order import Order
            from app.models.user import User
            user = User.query.get(user_id)
            if user and user.total_orders > 0:
                return False, "هذا الكوبون للطلب الأول فقط"
        
        return True, None
    
    def has_user_used(self, user_id):
        """هل استخدم المستخدم هذا الكوبون؟"""
        return self.usages.filter_by(user_id=user_id).count() > 0
    
    def get_user_usage_count(self, user_id):
        """عدد مرات استخدام المستخدم للكوبون"""
        return self.usages.filter_by(user_id=user_id).count()
    
    # ==========================================
    # 💰 Discount Calculation
    # ==========================================
    def calculate_discount(self, subtotal, items=None):
        """حساب قيمة الخصم"""
        if self.discount_type == 'percentage':
            discount = float(subtotal) * (float(self.discount_value) / 100)
            # تطبيق الحد الأقصى
            if self.maximum_discount:
                discount = min(discount, float(self.maximum_discount))
            return round(discount, 2)
        
        elif self.discount_type == 'fixed':
            return min(float(self.discount_value), float(subtotal))
        
        elif self.discount_type == 'free_shipping':
            return 0  # سيتم التعامل معه في حساب الشحن
        
        return 0
    
    def is_applicable_to_product(self, product_id, category_id=None):
        """هل الكوبون قابل للتطبيق على المنتج؟"""
        # التحقق من المنتجات المستثناة
        if self.excluded_products and product_id in self.excluded_products:
            return False
        
        # التحقق من الفئات المستثناة
        if self.excluded_categories and category_id in self.excluded_categories:
            return False
        
        # إذا لم تحدد منتجات/فئات، فالكوبون لكل شيء
        if not self.applicable_products and not self.applicable_categories:
            return True
        
        # التحقق من المنتجات المحددة
        if self.applicable_products and product_id in self.applicable_products:
            return True
        
        # التحقق من الفئات المحددة
        if self.applicable_categories and category_id in self.applicable_categories:
            return True
        
        return False
    
    # ==========================================
    # 📊 Usage Tracking
    # ==========================================
    def record_usage(self, user_id, order_id, discount_amount):
        """تسجيل استخدام الكوبون"""
        usage = CouponUsage(
            coupon_id=self.id,
            user_id=user_id,
            order_id=order_id,
            discount_amount=discount_amount
        )
        db.session.add(usage)
        self.usage_count += 1
        return usage
    
    @property
    def remaining_uses(self):
        """عدد الاستخدامات المتبقية"""
        if not self.usage_limit:
            return None
        return max(0, self.usage_limit - self.usage_count)
    
    @property
    def is_expired(self):
        """هل انتهت صلاحية الكوبون؟"""
        if not self.expires_at:
            return False
        return datetime.utcnow() > self.expires_at
    
    @property
    def days_until_expiry(self):
        """عدد الأيام حتى انتهاء الصلاحية"""
        if not self.expires_at:
            return None
        delta = self.expires_at - datetime.utcnow()
        return max(0, delta.days)
    
    @property
    def discount_display(self):
        """عرض الخصم"""
        if self.discount_type == 'percentage':
            return f"{int(self.discount_value)}%"
        elif self.discount_type == 'fixed':
            return f"{self.discount_value} د.ج"
        elif self.discount_type == 'free_shipping':
            return "شحن مجاني"
        return str(self.discount_value)
    
    # ==========================================
    # 📤 Serialization
    # ==========================================
    def to_dict(self, include_stats=False):
        """تحويل إلى قاموس"""
        data = {
            'id': self.id,
            'code': self.code,
            'description': self.description,
            'discount_type': self.discount_type,
            'discount_value': float(self.discount_value),
            'discount_display': self.discount_display,
            'maximum_discount': float(self.maximum_discount) if self.maximum_discount else None,
            'minimum_amount': float(self.minimum_amount) if self.minimum_amount else None,
            'minimum_items': self.minimum_items,
            'usage_limit': self.usage_limit,
            'usage_limit_per_user': self.usage_limit_per_user,
            'is_active': self.is_active,
            'starts_at': self.starts_at.isoformat() if self.starts_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'is_expired': self.is_expired,
            'days_until_expiry': self.days_until_expiry,
            'is_valid': self.is_valid()
        }
        
        if include_stats:
            data.update({
                'usage_count': self.usage_count,
                'remaining_uses': self.remaining_uses,
                'total_discount_given': sum(u.discount_amount for u in self.usages)
            })
        
        return data
    
    def __repr__(self):
        return f'<Coupon {self.code}>'


class CouponUsage(db.Model):
    """نموذج سجل استخدام الكوبون"""
    
    __tablename__ = 'coupon_usages'
    
    id = db.Column(db.Integer, primary_key=True)
    coupon_id = db.Column(db.Integer, db.ForeignKey('coupons.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    
    discount_amount = db.Column(db.Numeric(12, 2), nullable=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='coupon_usages')
    order = db.relationship('Order', backref='coupon_usage')
    
    def __repr__(self):
        return f'<CouponUsage {self.coupon.code} by User {self.user_id}>'