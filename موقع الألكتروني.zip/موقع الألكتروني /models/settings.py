"""
======================================
⚙️ Settings Models
======================================
نماذج الإعدادات والشحن والضرائب
"""

from datetime import datetime
from app.extensions import db


class SiteSettings(db.Model):
    """نموذج إعدادات الموقع"""
    
    __tablename__ = 'site_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # ==========================================
    # 🏪 Store Information
    # ==========================================
    store_name = db.Column(db.String(100), default='متجرنا الإلكتروني')
    store_name_ar = db.Column(db.String(100), nullable=True)
    tagline = db.Column(db.String(200), nullable=True)
    description = db.Column(db.Text, nullable=True)
    
    # ==========================================
    # 📧 Contact Information
    # ==========================================
    email = db.Column(db.String(120), nullable=True)
    phone = db.Column(db.String(20), nullable=True)
    whatsapp = db.Column(db.String(20), nullable=True)
    address = db.Column(db.Text, nullable=True)
    
    # ==========================================
    # 🌐 Social Media
    # ==========================================
    facebook_url = db.Column(db.String(255), nullable=True)
    instagram_url = db.Column(db.String(255), nullable=True)
    twitter_url = db.Column(db.String(255), nullable=True)
    youtube_url = db.Column(db.String(255), nullable=True)
    tiktok_url = db.Column(db.String(255), nullable=True)
    
    # ==========================================
    # 🖼️ Branding
    # ==========================================
    logo_url = db.Column(db.String(500), nullable=True)
    logo_dark_url = db.Column(db.String(500), nullable=True)
    favicon_url = db.Column(db.String(500), nullable=True)
    
    # ==========================================
    # 💰 Currency & Tax
    # ==========================================
    currency = db.Column(db.String(3), default='DZD')
    currency_symbol = db.Column(db.String(10), default='د.ج')
    currency_position = db.Column(db.String(10), default='after')  # before, after
    
    tax_enabled = db.Column(db.Boolean, default=True)
    tax_rate = db.Column(db.Numeric(5, 2), default=19)  # TVA 19%
    tax_included_in_price = db.Column(db.Boolean, default=True)
    
    # ==========================================
    # 🚚 Shipping
    # ==========================================
    free_shipping_enabled = db.Column(db.Boolean, default=False)
    free_shipping_threshold = db.Column(db.Numeric(12, 2), nullable=True)
    default_shipping_cost = db.Column(db.Numeric(12, 2), default=500)
    
    # ==========================================
    # 📦 Orders
    # ==========================================
    min_order_amount = db.Column(db.Numeric(12, 2), nullable=True)
    max_order_amount = db.Column(db.Numeric(12, 2), nullable=True)
    order_prefix = db.Column(db.String(10), default='ORD')
    
    # ==========================================
    # 🛒 Cart
    # ==========================================
    cart_expiry_days = db.Column(db.Integer, default=7)
    max_cart_items = db.Column(db.Integer, default=50)
    
    # ==========================================
    # 📧 Email Settings
    # ==========================================
    send_order_confirmation = db.Column(db.Boolean, default=True)
    send_shipping_notification = db.Column(db.Boolean, default=True)
    send_delivery_notification = db.Column(db.Boolean, default=True)
    
    # ==========================================
    # 🔧 Maintenance
    # ==========================================
    maintenance_mode = db.Column(db.Boolean, default=False)
    maintenance_message = db.Column(db.Text, nullable=True)
    
    # ==========================================
    # 🔍 SEO
    # ==========================================
    meta_title = db.Column(db.String(70), nullable=True)
    meta_description = db.Column(db.String(160), nullable=True)
    meta_keywords = db.Column(db.String(255), nullable=True)
    google_analytics_id = db.Column(db.String(50), nullable=True)
    facebook_pixel_id = db.Column(db.String(50), nullable=True)
    
    # ==========================================
    # 📜 Legal Pages
    # ==========================================
    terms_of_service = db.Column(db.Text, nullable=True)
    privacy_policy = db.Column(db.Text, nullable=True)
    return_policy = db.Column(db.Text, nullable=True)
    shipping_policy = db.Column(db.Text, nullable=True)
    
    # ==========================================
    # ⏰ Timestamps
    # ==========================================
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @classmethod
    def get_settings(cls):
        """الحصول على الإعدادات (أو إنشاء افتراضية)"""
        settings = cls.query.first()
        if not settings:
            settings = cls()
            db.session.add(settings)
            db.session.commit()
        return settings
    
    def to_dict(self):
        return {
            'store_name': self.store_name,
            'store_name_ar': self.store_name_ar,
            'tagline': self.tagline,
            'description': self.description,
            'email': self.email,
            'phone': self.phone,
            'whatsapp': self.whatsapp,
            'address': self.address,
            'social': {
                'facebook': self.facebook_url,
                'instagram': self.instagram_url,
                'twitter': self.twitter_url,
                'youtube': self.youtube_url,
                'tiktok': self.tiktok_url
            },
            'logo_url': self.logo_url,
            'favicon_url': self.favicon_url,
            'currency': self.currency,
            'currency_symbol': self.currency_symbol,
            'tax_rate': float(self.tax_rate) if self.tax_rate else 0,
            'free_shipping_threshold': float(self.free_shipping_threshold) if self.free_shipping_threshold else None,
            'maintenance_mode': self.maintenance_mode
        }
    
    def __repr__(self):
        return f'<SiteSettings {self.store_name}>'


class ShippingZone(db.Model):
    """نموذج مناطق الشحن (ولايات الجزائر)"""
    
    __tablename__ = 'shipping_zones'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # ==========================================
    # 📍 Zone Information
    # ==========================================
    name = db.Column(db.String(100), nullable=False)  # اسم الولاية
    name_ar = db.Column(db.String(100), nullable=True)
    code = db.Column(db.String(10), nullable=True)  # رمز الولاية (01-58)
    
    # ==========================================
    # 💰 Shipping Costs
    # ==========================================
    shipping_cost = db.Column(db.Numeric(12, 2), nullable=False)
    express_shipping_cost = db.Column(db.Numeric(12, 2), nullable=True)
    
    # الشحن المجاني
    free_shipping_threshold = db.Column(db.Numeric(12, 2), nullable=True)
    
    # ==========================================
    # ⏰ Delivery Time
    # ==========================================
    estimated_days_min = db.Column(db.Integer, default=2)
    estimated_days_max = db.Column(db.Integer, default=5)
    express_days = db.Column(db.Integer, default=1)
    
    # ==========================================
    # ⚙️ Settings
    # ==========================================
    is_active = db.Column(db.Boolean, default=True)
    is_express_available = db.Column(db.Boolean, default=True)
    sort_order = db.Column(db.Integer, default=0)
    
    # ==========================================
    # ⏰ Timestamps
    # ==========================================
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @property
    def display_name(self):
        return self.name_ar or self.name
    
    @property
    def delivery_estimate(self):
        """تقدير التوصيل"""
        if self.estimated_days_min == self.estimated_days_max:
            return f"{self.estimated_days_min} أيام"
        return f"{self.estimated_days_min}-{self.estimated_days_max} أيام"
    
    def get_shipping_cost(self, order_total, is_express=False):
        """حساب تكلفة الشحن"""
        # التحقق من الشحن المجاني
        if self.free_shipping_threshold and order_total >= float(self.free_shipping_threshold):
            return 0
        
        if is_express and self.is_express_available:
            return float(self.express_shipping_cost or self.shipping_cost)
        
        return float(self.shipping_cost)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'name_ar': self.name_ar,
            'display_name': self.display_name,
            'code': self.code,
            'shipping_cost': float(self.shipping_cost),
            'express_shipping_cost': float(self.express_shipping_cost) if self.express_shipping_cost else None,
            'free_shipping_threshold': float(self.free_shipping_threshold) if self.free_shipping_threshold else None,
            'delivery_estimate': self.delivery_estimate,
            'express_days': self.express_days,
            'is_express_available': self.is_express_available
        }
    
    @classmethod
    def seed_algeria_wilayas(cls):
        """إضافة ولايات الجزائر"""
        wilayas = [
            ('01', 'Adrar', 'أدرار'),
            ('02', 'Chlef', 'الشلف'),
            ('03', 'Laghouat', 'الأغواط'),
            ('04', 'Oum El Bouaghi', 'أم البواقي'),
            ('05', 'Batna', 'باتنة'),
            ('06', 'Béjaïa', 'بجاية'),
            ('07', 'Biskra', 'بسكرة'),
            ('08', 'Béchar', 'بشار'),
            ('09', 'Blida', 'البليدة'),
            ('10', 'Bouira', 'البويرة'),
            ('11', 'Tamanrasset', 'تمنراست'),
            ('12', 'Tébessa', 'تبسة'),
            ('13', 'Tlemcen', 'تلمسان'),
            ('14', 'Tiaret', 'تيارت'),
            ('15', 'Tizi Ouzou', 'تيزي وزو'),
            ('16', 'Alger', 'الجزائر'),
            ('17', 'Djelfa', 'الجلفة'),
            ('18', 'Jijel', 'جيجل'),
            ('19', 'Sétif', 'سطيف'),
            ('20', 'Saïda', 'سعيدة'),
            ('21', 'Skikda', 'سكيكدة'),
            ('22', 'Sidi Bel Abbès', 'سيدي بلعباس'),
            ('23', 'Annaba', 'عنابة'),
            ('24', 'Guelma', 'قالمة'),
            ('25', 'Constantine', 'قسنطينة'),
            ('26', 'Médéa', 'المدية'),
            ('27', 'Mostaganem', 'مستغانم'),
            ('28', "M'Sila", 'المسيلة'),
            ('29', 'Mascara', 'معسكر'),
            ('30', 'Ouargla', 'ورقلة'),
            ('31', 'Oran', 'وهران'),
            ('32', 'El Bayadh', 'البيض'),
            ('33', 'Illizi', 'إليزي'),
            ('34', 'Bordj Bou Arréridj', 'برج بوعريريج'),
            ('35', 'Boumerdès', 'بومرداس'),
            ('36', 'El Tarf', 'الطارف'),
            ('37', 'Tindouf', 'تندوف'),
            ('38', 'Tissemsilt', 'تيسمسيلت'),
            ('39', 'El Oued', 'الوادي'),
            ('40', 'Khenchela', 'خنشلة'),
            ('41', 'Souk Ahras', 'سوق أهراس'),
            ('42', 'Tipaza', 'تيبازة'),
            ('43', 'Mila', 'ميلة'),
            ('44', 'Aïn Defla', 'عين الدفلى'),
            ('45', 'Naâma', 'النعامة'),
            ('46', 'Aïn Témouchent', 'عين تموشنت'),
            ('47', 'Ghardaïa', 'غرداية'),
            ('48', 'Relizane', 'غليزان'),
            ('49', 'El M\'Ghair', 'المغير'),
            ('50', 'El Meniaa', 'المنيعة'),
            ('51', 'Ouled Djellal', 'أولاد جلال'),
            ('52', 'Bordj Baji Mokhtar', 'برج باجي مختار'),
            ('53', 'Béni Abbès', 'بني عباس'),
            ('54', 'Timimoun', 'تيميمون'),
            ('55', 'Touggourt', 'تقرت'),
            ('56', 'Djanet', 'جانت'),
            ('57', 'In Salah', 'عين صالح'),
            ('58', 'In Guezzam', 'عين قزام'),
        ]
        
        for code, name, name_ar in wilayas:
            existing = cls.query.filter_by(code=code).first()
            if not existing:
                # تكلفة الشحن بناءً على المسافة من الجزائر العاصمة
                if code in ['16', '09', '35', '42']:  # ولايات قريبة
                    cost = 400
                    express_cost = 700
                elif code in ['06', '15', '19', '25', '31', '23']:  # ولايات متوسطة
                    cost = 600
                    express_cost = 1000
                else:  # ولايات بعيدة
                    cost = 800
                    express_cost = 1400
                
                zone = cls(
                    code=code,
                    name=name,
                    name_ar=name_ar,
                    shipping_cost=cost,
                    express_shipping_cost=express_cost,
                    sort_order=int(code)
                )
                db.session.add(zone)
        
        db.session.commit()
    
    def __repr__(self):
        return f'<ShippingZone {self.name}>'


class TaxRate(db.Model):
    """نموذج معدلات الضرائب"""
    
    __tablename__ = 'tax_rates'
    
    id = db.Column(db.Integer, primary_key=True)
    
    name = db.Column(db.String(100), nullable=False)
    rate = db.Column(db.Numeric(5, 2), nullable=False)  # النسبة المئوية
    
    # تطبيق على فئات/منتجات معينة
    applicable_categories = db.Column(db.JSON, nullable=True)
    applicable_products = db.Column(db.JSON, nullable=True)
    
    is_compound = db.Column(db.Boolean, default=False)  # ضريبة مركبة
    is_active = db.Column(db.Boolean, default=True)
    priority = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<TaxRate {self.name} {self.rate}%>'