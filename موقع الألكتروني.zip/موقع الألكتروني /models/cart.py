"""
======================================
🛒 Cart Model
======================================
نموذج سلة التسوق
"""

from datetime import datetime, timedelta
from app.extensions import db


class Cart(db.Model):
    """نموذج سلة التسوق"""
    
    __tablename__ = 'carts'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    # للزوار غير المسجلين
    session_id = db.Column(db.String(100), nullable=True, index=True)
    
    # ==========================================
    # 🏷️ Coupon
    # ==========================================
    coupon_id = db.Column(db.Integer, db.ForeignKey('coupons.id'), nullable=True)
    coupon_code = db.Column(db.String(50), nullable=True)
    coupon_discount = db.Column(db.Numeric(12, 2), default=0)
    
    # ==========================================
    # 📝 Notes
    # ==========================================
    notes = db.Column(db.Text, nullable=True)
    
    # ==========================================
    # ⏰ Timestamps
    # ==========================================
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)  # انتهاء صلاحية السلة للزوار
    
    # ==========================================
    # 🔗 Relationships
    # ==========================================
    items = db.relationship('CartItem', backref='cart', lazy='dynamic',
                           cascade='all, delete-orphan')
    coupon = db.relationship('Coupon', backref='carts')
    
    def __init__(self, **kwargs):
        super(Cart, self).__init__(**kwargs)
        # تعيين انتهاء الصلاحية للزوار (7 أيام)
        if not self.user_id:
            self.expires_at = datetime.utcnow() + timedelta(days=7)
    
    # ==========================================
    # 🛒 Item Management
    # ==========================================
    def add_item(self, product, quantity=1, variant_id=None):
        """إضافة منتج للسلة"""
        # التحقق من إمكانية الشراء
        can_buy, error = product.can_purchase(quantity)
        if not can_buy:
            return False, error
        
        # البحث عن المنتج في السلة
        existing_item = self.items.filter_by(
            product_id=product.id,
            variant_id=variant_id
        ).first()
        
        if existing_item:
            new_quantity = existing_item.quantity + quantity
            can_buy, error = product.can_purchase(new_quantity)
            if not can_buy:
                return False, error
            existing_item.quantity = new_quantity
            existing_item.update_price()
        else:
            item = CartItem(
                cart_id=self.id,
                product_id=product.id,
                variant_id=variant_id,
                quantity=quantity
            )
            item.update_price()
            db.session.add(item)
        
        self.updated_at = datetime.utcnow()
        return True, None
    
    def update_item_quantity(self, item_id, quantity):
        """تحديث كمية منتج"""
        item = self.items.filter_by(id=item_id).first()
        if not item:
            return False, "المنتج غير موجود في السلة"
        
        if quantity <= 0:
            return self.remove_item(item_id)
        
        can_buy, error = item.product.can_purchase(quantity)
        if not can_buy:
            return False, error
        
        item.quantity = quantity
        item.update_price()
        self.updated_at = datetime.utcnow()
        return True, None
    
    def remove_item(self, item_id):
        """إزالة منتج من السلة"""
        item = self.items.filter_by(id=item_id).first()
        if item:
            db.session.delete(item)
            self.updated_at = datetime.utcnow()
            return True, None
        return False, "المنتج غير موجود"
    
    def clear(self):
        """تفريغ السلة"""
        self.items.delete()
        self.coupon_id = None
        self.coupon_code = None
        self.coupon_discount = 0
        self.updated_at = datetime.utcnow()
    
    # ==========================================
    # 🏷️ Coupon Management
    # ==========================================
    def apply_coupon(self, coupon):
        """تطبيق كوبون خصم"""
        if not coupon.is_valid():
            return False, "الكوبون غير صالح أو منتهي"
        
        # التحقق من الحد الأدنى للطلب
        if coupon.minimum_amount and self.subtotal < float(coupon.minimum_amount):
            return False, f"الحد الأدنى للطلب هو {coupon.minimum_amount} د.ج"
        
        # التحقق من استخدام المستخدم للكوبون
        if self.user_id and coupon.has_user_used(self.user_id):
            return False, "لقد استخدمت هذا الكوبون من قبل"
        
        # حساب الخصم
        discount = coupon.calculate_discount(self.subtotal)
        
        self.coupon_id = coupon.id
        self.coupon_code = coupon.code
        self.coupon_discount = discount
        
        return True, f"تم تطبيق الخصم: {discount} د.ج"
    
    def remove_coupon(self):
        """إزالة الكوبون"""
        self.coupon_id = None
        self.coupon_code = None
        self.coupon_discount = 0
    
    # ==========================================
    # 💰 Price Calculations
    # ==========================================
    @property
    def items_count(self):
        """عدد المنتجات"""
        return sum(item.quantity for item in self.items)
    
    @property
    def unique_items_count(self):
        """عدد المنتجات الفريدة"""
        return self.items.count()
    
    @property
    def subtotal(self):
        """المجموع قبل الخصومات"""
        return sum(item.total_price for item in self.items)
    
    @property
    def discount_total(self):
        """إجمالي الخصومات"""
        items_discount = sum(item.discount_amount for item in self.items)
        return items_discount + float(self.coupon_discount or 0)
    
    @property
    def total(self):
        """المجموع النهائي"""
        return self.subtotal - float(self.coupon_discount or 0)
    
    @property
    def is_empty(self):
        """هل السلة فارغة؟"""
        return self.items.count() == 0
    
    # ==========================================
    # 🔄 Cart Operations
    # ==========================================
    def merge_with(self, other_cart):
        """دمج سلة أخرى (عند تسجيل الدخول)"""
        for item in other_cart.items:
            existing = self.items.filter_by(
                product_id=item.product_id,
                variant_id=item.variant_id
            ).first()
            
            if existing:
                existing.quantity += item.quantity
                existing.update_price()
            else:
                new_item = CartItem(
                    cart_id=self.id,
                    product_id=item.product_id,
                    variant_id=item.variant_id,
                    quantity=item.quantity
                )
                new_item.update_price()
                db.session.add(new_item)
        
        # حذف السلة القديمة
        db.session.delete(other_cart)
    
    def refresh_prices(self):
        """تحديث أسعار جميع المنتجات"""
        for item in self.items:
            item.update_price()
        
        # إعادة حساب خصم الكوبون
        if self.coupon:
            if self.coupon.is_valid():
                self.coupon_discount = self.coupon.calculate_discount(self.subtotal)
            else:
                self.remove_coupon()
    
    def validate_items(self):
        """التحقق من صلاحية جميع المنتجات"""
        issues = []
        
        for item in self.items:
            if not item.product.is_active:
                issues.append({
                    'item_id': item.id,
                    'product_name': item.product.display_name,
                    'issue': 'المنتج غير متاح حالياً'
                })
            elif not item.product.is_in_stock:
                issues.append({
                    'item_id': item.id,
                    'product_name': item.product.display_name,
                    'issue': 'المنتج نفد من المخزون'
                })
            elif item.product.stock_quantity < item.quantity:
                issues.append({
                    'item_id': item.id,
                    'product_name': item.product.display_name,
                    'issue': f'الكمية المتوفرة: {item.product.stock_quantity}',
                    'available': item.product.stock_quantity
                })
        
        return issues
    
    # ==========================================
    # 📤 Serialization
    # ==========================================
    def to_dict(self):
        return {
            'id': self.id,
            'items': [item.to_dict() for item in self.items],
            'items_count': self.items_count,
            'unique_items_count': self.unique_items_count,
            'subtotal': self.subtotal,
            'coupon': {
                'code': self.coupon_code,
                'discount': float(self.coupon_discount or 0)
            } if self.coupon_code else None,
            'discount_total': self.discount_total,
            'total': self.total,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @classmethod
    def get_or_create(cls, user_id=None, session_id=None):
        """الحصول على السلة أو إنشاء جديدة"""
        if user_id:
            cart = cls.query.filter_by(user_id=user_id).first()
            if not cart:
                cart = cls(user_id=user_id)
                db.session.add(cart)
                db.session.commit()
        elif session_id:
            cart = cls.query.filter_by(session_id=session_id).first()
            if not cart:
                cart = cls(session_id=session_id)
                db.session.add(cart)
                db.session.commit()
        else:
            return None
        
        return cart
    
    def __repr__(self):
        return f'<Cart {self.id}>'


class CartItem(db.Model):
    """نموذج عنصر في السلة"""
    
    __tablename__ = 'cart_items'
    
    id = db.Column(db.Integer, primary_key=True)
    cart_id = db.Column(db.Integer, db.ForeignKey('carts.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    variant_id = db.Column(db.Integer, db.ForeignKey('product_variants.id'), nullable=True)
    
    # ==========================================
    # 📦 Quantity
    # ==========================================
    quantity = db.Column(db.Integer, default=1, nullable=False)
    
    # ==========================================
    # 💰 Price (محفوظ وقت الإضافة)
    # ==========================================
    unit_price = db.Column(db.Numeric(12, 2), nullable=False)
    original_price = db.Column(db.Numeric(12, 2), nullable=True)  # السعر قبل الخصم
    discount_percentage = db.Column(db.Integer, default=0)
    
    # ==========================================
    # 📝 Notes
    # ==========================================
    notes = db.Column(db.String(500), nullable=True)
    
    # ==========================================
    # ⏰ Timestamps
    # ==========================================
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # ==========================================
    # 🔗 Relationships
    # ==========================================
    product = db.relationship('Product', backref='cart_items')
    variant = db.relationship('ProductVariant', backref='cart_items')
    
    # Unique constraint
    __table_args__ = (
        db.UniqueConstraint('cart_id', 'product_id', 'variant_id', name='unique_cart_item'),
    )
    
    def update_price(self):
        """تحديث السعر من المنتج"""
        if self.variant:
            self.unit_price = self.variant.final_price
            self.original_price = float(self.product.price) + float(self.variant.price_adjustment or 0)
        else:
            self.unit_price = self.product.current_price
            self.original_price = float(self.product.price)
        
        self.discount_percentage = self.product.discount_percentage
    
    @property
    def total_price(self):
        """السعر الإجمالي"""
        return float(self.unit_price) * self.quantity
    
    @property
    def original_total(self):
        """السعر الإجمالي الأصلي"""
        if self.original_price:
            return float(self.original_price) * self.quantity
        return self.total_price
    
    @property
    def discount_amount(self):
        """مقدار الخصم"""
        return self.original_total - self.total_price
    
    @property
    def is_on_sale(self):
        """هل عليه خصم؟"""
        return self.discount_percentage > 0
    
    def to_dict(self):
        return {
            'id': self.id,
            'product': {
                'id': self.product.id,
                'name': self.product.display_name,
                'slug': self.product.slug,
                'image_url': self.product.get_main_image(),
                'is_in_stock': self.product.is_in_stock,
                'stock_quantity': self.product.stock_quantity
            },
            'variant': self.variant.to_dict() if self.variant else None,
            'quantity': self.quantity,
            'unit_price': float(self.unit_price),
            'original_price': float(self.original_price) if self.original_price else None,
            'total_price': self.total_price,
            'discount_percentage': self.discount_percentage,
            'discount_amount': self.discount_amount,
            'is_on_sale': self.is_on_sale,
            'notes': self.notes
        }
    
    def __repr__(self):
        return f'<CartItem {self.product.name} x{self.quantity}>'