"""
======================================
🔔 Notification Model
======================================
نموذج الإشعارات
"""

from datetime import datetime
from app.extensions import db


class Notification(db.Model):
    """نموذج الإشعارات"""
    
    __tablename__ = 'notifications'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # ==========================================
    # 📝 Notification Content
    # ==========================================
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    
    # order, product, payment, account, promotion, system
    type = db.Column(db.String(50), default='system', nullable=False)
    
    # ==========================================
    # 🔗 Related Entity
    # ==========================================
    entity_type = db.Column(db.String(50), nullable=True)  # order, product, ticket
    entity_id = db.Column(db.Integer, nullable=True)
    
    # ==========================================
    # 🔗 Action
    # ==========================================
    action_url = db.Column(db.String(500), nullable=True)
    action_text = db.Column(db.String(100), nullable=True)
    
    # ==========================================
    # 📊 Status
    # ==========================================
    is_read = db.Column(db.Boolean, default=False)
    is_important = db.Column(db.Boolean, default=False)
    
    # ==========================================
    # 🖼️ Icon
    # ==========================================
    icon = db.Column(db.String(50), nullable=True)  # CSS icon class
    icon_color = db.Column(db.String(20), nullable=True)
    
    # ==========================================
    # ⏰ Timestamps
    # ==========================================
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    read_at = db.Column(db.DateTime, nullable=True)
    
    # ==========================================
    # 🔧 Type Configurations
    # ==========================================
    TYPE_CONFIG = {
        'order': {
            'icon': 'bi-box-seam',
            'color': 'primary'
        },
        'payment': {
            'icon': 'bi-credit-card',
            'color': 'success'
        },
        'product': {
            'icon': 'bi-tag',
            'color': 'info'
        },
        'account': {
            'icon': 'bi-person',
            'color': 'secondary'
        },
        'promotion': {
            'icon': 'bi-percent',
            'color': 'warning'
        },
        'system': {
            'icon': 'bi-bell',
            'color': 'dark'
        }
    }
    
    def __init__(self, **kwargs):
        super(Notification, self).__init__(**kwargs)
        # تعيين الأيقونة واللون تلقائياً
        if self.type and not self.icon:
            config = self.TYPE_CONFIG.get(self.type, {})
            self.icon = config.get('icon', 'bi-bell')
            self.icon_color = config.get('color', 'secondary')
    
    def mark_as_read(self):
        """تعيين كمقروء"""
        if not self.is_read:
            self.is_read = True
            self.read_at = datetime.utcnow()
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'message': self.message,
            'type': self.type,
            'icon': self.icon,
            'icon_color': self.icon_color,
            'action_url': self.action_url,
            'action_text': self.action_text,
            'is_read': self.is_read,
            'is_important': self.is_important,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'time_ago': self.time_ago
        }
    
    @property
    def time_ago(self):
        """الوقت المنقضي"""
        if not self.created_at:
            return ''
        
        delta = datetime.utcnow() - self.created_at
        seconds = delta.total_seconds()
        
        if seconds < 60:
            return 'الآن'
        elif seconds < 3600:
            minutes = int(seconds / 60)
            return f'منذ {minutes} دقيقة'
        elif seconds < 86400:
            hours = int(seconds / 3600)
            return f'منذ {hours} ساعة'
        elif seconds < 604800:
            days = int(seconds / 86400)
            return f'منذ {days} يوم'
        else:
            return self.created_at.strftime('%Y-%m-%d')
    
    # ==========================================
    # 🏭 Factory Methods
    # ==========================================
    @classmethod
    def create_order_notification(cls, user_id, order, notification_type='new'):
        """إنشاء إشعار طلب"""
        messages = {
            'new': ('طلب جديد', f'تم استلام طلبك #{order.order_number} بنجاح'),
            'confirmed': ('تم تأكيد الطلب', f'تم تأكيد طلبك #{order.order_number}'),
            'shipped': ('جاري التوصيل', f'طلبك #{order.order_number} في الطريق إليك'),
            'delivered': ('تم التسليم', f'تم تسليم طلبك #{order.order_number}'),
            'cancelled': ('تم إلغاء الطلب', f'تم إلغاء طلبك #{order.order_number}')
        }
        
        title, message = messages.get(notification_type, ('تحديث الطلب', f'تم تحديث طلبك #{order.order_number}'))
        
        notification = cls(
            user_id=user_id,
            title=title,
            message=message,
            type='order',
            entity_type='order',
            entity_id=order.id,
            action_url=f'/orders/{order.order_number}',
            action_text='عرض الطلب'
        )
        db.session.add(notification)
        return notification
    
    @classmethod
    def create_payment_notification(cls, user_id, order, is_success=True):
        """إنشاء إشعار دفع"""
        if is_success:
            notification = cls(
                user_id=user_id,
                title='تم الدفع بنجاح',
                message=f'تم استلام دفعتك للطلب #{order.order_number}',
                type='payment',
                entity_type='order',
                entity_id=order.id,
                action_url=f'/orders/{order.order_number}'
            )
        else:
            notification = cls(
                user_id=user_id,
                title='فشل عملية الدفع',
                message=f'لم نتمكن من معالجة دفعتك للطلب #{order.order_number}',
                type='payment',
                is_important=True,
                entity_type='order',
                entity_id=order.id,
                action_url=f'/orders/{order.order_number}/pay'
            )
        
        db.session.add(notification)
        return notification
    
    @classmethod
    def create_promo_notification(cls, user_id, title, message, action_url=None):
        """إنشاء إشعار ترويجي"""
        notification = cls(
            user_id=user_id,
            title=title,
            message=message,
            type='promotion',
            action_url=action_url
        )
        db.session.add(notification)
        return notification
    
    def __repr__(self):
        return f'<Notification {self.id} - {self.title}>'