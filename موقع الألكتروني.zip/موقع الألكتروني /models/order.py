"""
======================================
📋 Order Model
======================================
نموذج الطلبات والتتبع
"""

from datetime import datetime
from decimal import Decimal
import secrets
import json

from app.extensions import db


class Order(db.Model):
    """نموذج الطلب"""
    
    __tablename__ = 'orders'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # ==========================================
    # 🔑 Order Identification
    # ==========================================
    order_number = db.Column(db.String(30), unique=True, nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # ==========================================
    # 📊 Order Status
    # ==========================================
    # pending, confirmed, processing, shipped, delivered, cancelled, refunded
    status = db.Column(db.String(20), default='pending', nullable=False, index=True)
    
    # payment_pending, paid, failed, refunded
    payment_status = db.Column(db.String(20), default='payment_pending', nullable=False)
    
    # ==========================================
    # 💰 Pricing
    # ==========================================
    subtotal = db.Column(db.Numeric(12, 2), nullable=False)  # مجموع المنتجات
    discount_amount = db.Column(db.Numeric(12, 2), default=0)  # خصم الكوبون
    shipping_amount = db.Column(db.Numeric(12, 2), default=0)  # رسوم التوصيل
    tax_amount = db.Column(db.Numeric(12, 2), default=0)  # الضرائب
    total_amount = db.Column(db.Numeric(12, 2), nullable=False)  # المجموع النهائي
    
    # العملة
    currency = db.Column(db.String(3), default='DZD')
    
    # ==========================================
    # 🏷️ Coupon
    # ==========================================
    coupon_id = db.Column(db.Integer, db.ForeignKey('coupons.id'), nullable=True)
    coupon_code = db.Column(db.String(50), nullable=True)
    
    # ==========================================
    # 📍 Shipping Address
    # ==========================================
    shipping_address_id = db.Column(db.Integer, db.ForeignKey('user_addresses.id'), nullable=True)
    
    # نسخة من العنوان (للحفظ حتى لو تم تغيير العنوان الأصلي)
    shipping_name = db.Column(db.String(100), nullable=False)
    shipping_phone = db.Column(db.String(20), nullable=False)
    shipping_street = db.Column(db.String(255), nullable=False)
    shipping_street_2 = db.Column(db.String(255), nullable=True)
    shipping_city = db.Column(db.String(100), nullable=False)
    shipping_state = db.Column(db.String(100), nullable=False)  # الولاية
    shipping_postal_code = db.Column(db.String(20), nullable=True)
    shipping_country = db.Column(db.String(2), default='DZ')
    
    # الإحداثيات الجغرافية
    shipping_latitude = db.Column(db.Float, nullable=True)
    shipping_longitude = db.Column(db.Float, nullable=True)
    
    # ==========================================
    # 🚚 Shipping Details
    # ==========================================
    shipping_method = db.Column(db.String(50), nullable=True)  # standard, express
    shipping_zone_id = db.Column(db.Integer, db.ForeignKey('shipping_zones.id'), nullable=True)
    
    # معلومات الشحن
    tracking_number = db.Column(db.String(100), nullable=True)
    carrier = db.Column(db.String(50), nullable=True)  # شركة التوصيل
    estimated_delivery = db.Column(db.Date, nullable=True)
    
    shipped_at = db.Column(db.DateTime, nullable=True)
    delivered_at = db.Column(db.DateTime, nullable=True)
    
    # ==========================================
    # 💳 Payment Details
    # ==========================================
    payment_method = db.Column(db.String(50), nullable=True)  # chargily, cod
    payment_gateway = db.Column(db.String(50), nullable=True)  # chargily
    
    # Chargily Payment
    chargily_checkout_id = db.Column(db.String(100), nullable=True)
    chargily_payment_id = db.Column(db.String(100), nullable=True)
    
    paid_at = db.Column(db.DateTime, nullable=True)
    payment_details = db.Column(db.JSON, nullable=True)  # تفاصيل الدفع
    
    # ==========================================
    # 📝 Notes
    # ==========================================
    customer_notes = db.Column(db.Text, nullable=True)  # ملاحظات العميل
    admin_notes = db.Column(db.Text, nullable=True)  # ملاحظات المشرف (خاصة)
    
    # ==========================================
    # ❌ Cancellation
    # ==========================================
    cancelled_at = db.Column(db.DateTime, nullable=True)
    cancellation_reason = db.Column(db.String(500), nullable=True)
    cancelled_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    # ==========================================
    # 💸 Refund
    # ==========================================
    refund_amount = db.Column(db.Numeric(12, 2), nullable=True)
    refund_reason = db.Column(db.String(500), nullable=True)
    refunded_at = db.Column(db.DateTime, nullable=True)
    
    # ==========================================
    # 📊 Additional Info
    # ==========================================
    ip_address = db.Column(db.String(45), nullable=True)
    user_agent = db.Column(db.String(500), nullable=True)
    
    # ==========================================
    # ⏰ Timestamps
    # ==========================================
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, 
                          onupdate=datetime.utcnow, nullable=False)
    confirmed_at = db.Column(db.DateTime, nullable=True)
    
    # ==========================================
    # 🔗 Relationships
    # ==========================================
    items = db.relationship('OrderItem', backref='order', lazy='dynamic',
                           cascade='all, delete-orphan')
    status_history = db.relationship('OrderStatusHistory', backref='order', 
                                    lazy='dynamic', cascade='all, delete-orphan',
                                    order_by='OrderStatusHistory.created_at.desc()')
    shipping_zone = db.relationship('ShippingZone', backref='orders')
    coupon = db.relationship('Coupon', backref='orders')
    shipping_address = db.relationship('UserAddress', backref='orders')
    reviews = db.relationship('ProductReview', backref='order', lazy='dynamic')
    
    # ==========================================
    # 🔧 Indexes
    # ==========================================
    __table_args__ = (
        db.Index('idx_order_user_status', 'user_id', 'status'),
        db.Index('idx_order_created', 'created_at'),
    )
    
    def __init__(self, **kwargs):
        super(Order, self).__init__(**kwargs)
        if not self.order_number:
            self.order_number = self.generate_order_number()
    
    @staticmethod
    def generate_order_number():
        """توليد رقم طلب فريد"""
        timestamp = datetime.utcnow().strftime('%y%m%d')
        random_part = secrets.token_hex(4).upper()
        return f"ORD-{timestamp}-{random_part}"
    
    # ==========================================
    # 📊 Status Management
    # ==========================================
    STATUS_FLOW = {
        'pending': ['confirmed', 'cancelled'],
        'confirmed': ['processing', 'cancelled'],
        'processing': ['shipped', 'cancelled'],
        'shipped': ['delivered', 'cancelled'],
        'delivered': ['refunded'],
        'cancelled': [],
        'refunded': []
    }
    
    STATUS_LABELS = {
        'pending': 'قيد المراجعة',
        'confirmed': 'تم التأكيد',
        'processing': 'قيد التجهيز',
        'shipped': 'جاري التوصيل',
        'delivered': 'تم التسليم',
        'cancelled': 'ملغي',
        'refunded': 'مسترجع'
    }
    
    PAYMENT_STATUS_LABELS = {
        'payment_pending': 'في انتظار الدفع',
        'paid': 'مدفوع',
        'failed': 'فشل الدفع',
        'refunded': 'مسترجع'
    }
    
    def can_transition_to(self, new_status):
        """التحقق من إمكانية تغيير الحالة"""
        return new_status in self.STATUS_FLOW.get(self.status, [])
    
    def update_status(self, new_status, user_id=None, notes=None):
        """تحديث حالة الطلب"""
        if not self.can_transition_to(new_status):
            return False, f"لا يمكن تغيير الحالة من {self.status} إلى {new_status}"
        
        old_status = self.status
        self.status = new_status
        
        # تحديث التواريخ حسب الحالة
        now = datetime.utcnow()
        if new_status == 'confirmed':
            self.confirmed_at = now
        elif new_status == 'shipped':
            self.shipped_at = now
        elif new_status == 'delivered':
            self.delivered_at = now
            # تحديث إحصائيات المستخدم
            if self.user:
                self.user.update_statistics(float(self.total_amount))
        elif new_status == 'cancelled':
            self.cancelled_at = now
            self.cancelled_by = user_id
            self.cancellation_reason = notes
            # إرجاع المخزون
            self.restore_stock()
        
        # إضافة سجل الحالة
        history = OrderStatusHistory(
            order_id=self.id,
            old_status=old_status,
            new_status=new_status,
            changed_by=user_id,
            notes=notes
        )
        db.session.add(history)
        
        return True, "تم تحديث الحالة بنجاح"
    
    @property
    def status_label(self):
        """تسمية الحالة"""
        return self.STATUS_LABELS.get(self.status, self.status)
    
    @property
    def payment_status_label(self):
        """تسمية حالة الدفع"""
        return self.PAYMENT_STATUS_LABELS.get(self.payment_status, self.payment_status)
    
    @property
    def status_color(self):
        """لون الحالة للعرض"""
        colors = {
            'pending': 'warning',
            'confirmed': 'info',
            'processing': 'primary',
            'shipped': 'info',
            'delivered': 'success',
            'cancelled': 'danger',
            'refunded': 'secondary'
        }
        return colors.get(self.status, 'secondary')
    
    # ==========================================
    # 💳 Payment Methods
    # ==========================================
    def mark_as_paid(self, payment_id=None, payment_details=None):
        """تسجيل الدفع"""
        self.payment_status = 'paid'
        self.paid_at = datetime.utcnow()
        if payment_id:
            self.chargily_payment_id = payment_id
        if payment_details:
            self.payment_details = payment_details
        
        # تأكيد الطلب تلقائياً
        if self.status == 'pending':
            self.update_status('confirmed')
    
    def mark_payment_failed(self, error_details=None):
        """تسجيل فشل الدفع"""
        self.payment_status = 'failed'
        if error_details:
            self.payment_details = error_details
    
    # ==========================================
    # 📦 Stock Management
    # ==========================================
    def deduct_stock(self):
        """خصم المخزون"""
        for item in self.items:
            if item.product.track_inventory:
                item.product.update_stock(item.quantity, 'subtract')
                item.product.increment_sales(item.quantity)
    
    def restore_stock(self):
        """إرجاع المخزون (عند الإلغاء)"""
        for item in self.items:
            if item.product.track_inventory:
                item.product.update_stock(item.quantity, 'add')
    
    # ==========================================
    # 💸 Refund
    # ==========================================
    def process_refund(self, amount=None, reason=None):
        """معالجة الاسترجاع"""
        self.refund_amount = amount or self.total_amount
        self.refund_reason = reason
        self.refunded_at = datetime.utcnow()
        self.payment_status = 'refunded'
        self.status = 'refunded'
        
        # إرجاع المخزون
        self.restore_stock()
    
    # ==========================================
    # 📊 Statistics
    # ==========================================
    @property
    def items_count(self):
        """عدد المنتجات"""
        return sum(item.quantity for item in self.items)
    
    @property
    def can_cancel(self):
        """هل يمكن إلغاء الطلب؟"""
        return self.status in ['pending', 'confirmed']
    
    @property
    def can_refund(self):
        """هل يمكن استرجاع الطلب؟"""
        return self.status == 'delivered' and self.payment_status == 'paid'
    
    @property
    def is_paid(self):
        """هل الطلب مدفوع؟"""
        return self.payment_status == 'paid'
    
    @property
    def full_shipping_address(self):
        """العنوان الكامل"""
        parts = [self.shipping_street]
        if self.shipping_street_2:
            parts.append(self.shipping_street_2)
        parts.extend([self.shipping_city, self.shipping_state])
        if self.shipping_postal_code:
            parts.append(self.shipping_postal_code)
        return ', '.join(parts)
    
    # ==========================================
    # 📤 Serialization
    # ==========================================
    def to_dict(self, include_items=True, include_history=False):
        """تحويل إلى قاموس"""
        data = {
            'id': self.id,
            'order_number': self.order_number,
            'status': self.status,
            'status_label': self.status_label,
            'status_color': self.status_color,
            'payment_status': self.payment_status,
            'payment_status_label': self.payment_status_label,
            'payment_method': self.payment_method,
            'subtotal': float(self.subtotal),
            'discount_amount': float(self.discount_amount or 0),
            'shipping_amount': float(self.shipping_amount or 0),
            'tax_amount': float(self.tax_amount or 0),
            'total_amount': float(self.total_amount),
            'currency': self.currency,
            'items_count': self.items_count,
            'coupon_code': self.coupon_code,
            'shipping_address': {
                'name': self.shipping_name,
                'phone': self.shipping_phone,
                'street': self.shipping_street,
                'city': self.shipping_city,
                'state': self.shipping_state,
                'full_address': self.full_shipping_address,
                'latitude': self.shipping_latitude,
                'longitude': self.shipping_longitude
            },
            'shipping_method': self.shipping_method,
            'tracking_number': self.tracking_number,
            'carrier': self.carrier,
            'estimated_delivery': self.estimated_delivery.isoformat() if self.estimated_delivery else None,
            'customer_notes': self.customer_notes,
            'can_cancel': self.can_cancel,
            'can_refund': self.can_refund,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'confirmed_at': self.confirmed_at.isoformat() if self.confirmed_at else None,
            'shipped_at': self.shipped_at.isoformat() if self.shipped_at else None,
            'delivered_at': self.delivered_at.isoformat() if self.delivered_at else None,
            'paid_at': self.paid_at.isoformat() if self.paid_at else None
        }
        
        if include_items:
            data['items'] = [item.to_dict() for item in self.items]
        
        if include_history:
            data['status_history'] = [h.to_dict() for h in self.status_history]
        
        return data
    
    def __repr__(self):
        return f'<Order {self.order_number}>'


class OrderItem(db.Model):
    """نموذج عنصر في الطلب"""
    
    __tablename__ = 'order_items'
    
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    variant_id = db.Column(db.Integer, db.ForeignKey('product_variants.id'), nullable=True)
    
    # ==========================================
    # 📦 Product Snapshot (نسخة من بيانات المنتج)
    # ==========================================
    product_name = db.Column(db.String(200), nullable=False)
    product_sku = db.Column(db.String(50), nullable=True)
    product_image_url = db.Column(db.String(500), nullable=True)
    variant_name = db.Column(db.String(100), nullable=True)
    
    # ==========================================
    # 💰 Pricing
    # ==========================================
    quantity = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Numeric(12, 2), nullable=False)
    original_price = db.Column(db.Numeric(12, 2), nullable=True)
    discount_amount = db.Column(db.Numeric(12, 2), default=0)
    total_price = db.Column(db.Numeric(12, 2), nullable=False)
    
    # ==========================================
    # 📝 Notes
    # ==========================================
    notes = db.Column(db.String(500), nullable=True)
    
    # ==========================================
    # 🔗 Relationships
    # ==========================================
    product = db.relationship('Product', backref='order_items')
    variant = db.relationship('ProductVariant', backref='order_items')
    
    def __init__(self, **kwargs):
        super(OrderItem, self).__init__(**kwargs)
        # حفظ snapshot من المنتج
        if self.product:
            self.product_name = self.product.display_name
            self.product_sku = self.product.sku
            self.product_image_url = self.product.get_main_image()
        if self.variant:
            self.variant_name = self.variant.name
        # حساب المجموع
        if self.unit_price and self.quantity:
            self.total_price = float(self.unit_price) * self.quantity
    
    def to_dict(self):
        return {
            'id': self.id,
            'product_id': self.product_id,
            'product_name': self.product_name,
            'product_sku': self.product_sku,
            'product_image_url': self.product_image_url,
            'product_slug': self.product.slug if self.product else None,
            'variant_id': self.variant_id,
            'variant_name': self.variant_name,
            'quantity': self.quantity,
            'unit_price': float(self.unit_price),
            'original_price': float(self.original_price) if self.original_price else None,
            'discount_amount': float(self.discount_amount or 0),
            'total_price': float(self.total_price)
        }
    
    def __repr__(self):
        return f'<OrderItem {self.product_name} x{self.quantity}>'


class OrderStatusHistory(db.Model):
    """نموذج سجل تغييرات حالة الطلب"""
    
    __tablename__ = 'order_status_history'
    
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    
    old_status = db.Column(db.String(20), nullable=True)
    new_status = db.Column(db.String(20), nullable=False)
    
    changed_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship
    changed_by_user = db.relationship('User', backref='status_changes')
    
    @property
    def status_label(self):
        return Order.STATUS_LABELS.get(self.new_status, self.new_status)
    
    def to_dict(self):
        return {
            'id': self.id,
            'old_status': self.old_status,
            'new_status': self.new_status,
            'status_label': self.status_label,
            'changed_by': self.changed_by_user.full_name if self.changed_by_user else 'النظام',
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f'<OrderStatusHistory {self.old_status} -> {self.new_status}>'