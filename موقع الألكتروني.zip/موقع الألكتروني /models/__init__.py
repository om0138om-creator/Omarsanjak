"""
======================================
📊 Database Models
======================================
استيراد جميع النماذج
"""

from app.models.user import User, UserAddress, UserWishlist
from app.models.category import Category
from app.models.product import Product, ProductImage, ProductVariant, ProductReview
from app.models.cart import Cart, CartItem
from app.models.order import Order, OrderItem, OrderStatusHistory
from app.models.ticket import Ticket, TicketMessage
from app.models.settings import SiteSettings, ShippingZone, TaxRate
from app.models.notification import Notification
from app.models.coupon import Coupon, CouponUsage

__all__ = [
    'User', 'UserAddress', 'UserWishlist',
    'Category',
    'Product', 'ProductImage', 'ProductVariant', 'ProductReview',
    'Cart', 'CartItem',
    'Order', 'OrderItem', 'OrderStatusHistory',
    'Ticket', 'TicketMessage',
    'SiteSettings', 'ShippingZone', 'TaxRate',
    'Notification',
    'Coupon', 'CouponUsage'
]