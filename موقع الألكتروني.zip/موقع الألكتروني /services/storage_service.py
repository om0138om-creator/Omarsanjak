"""
======================================
☁️ Storage Service (Cloudflare R2)
======================================
خدمة رفع وإدارة الملفات على Cloudflare R2
"""

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
import os
import uuid
from datetime import datetime
from typing import Optional, Tuple, List, Dict
from io import BytesIO

from PIL import Image
from flask import current_app
from werkzeug.utils import secure_filename


class StorageService:
    """خدمة التخزين السحابي Cloudflare R2"""
    
    def __init__(self, app=None):
        self.app = app
        self.client = None
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """تهيئة الخدمة"""
        self.app = app
        
        # إعدادات R2
        self.account_id = app.config.get('R2_ACCOUNT_ID')
        self.access_key = app.config.get('R2_ACCESS_KEY_ID')
        self.secret_key = app.config.get('R2_SECRET_ACCESS_KEY')
        self.bucket_name = app.config.get('R2_BUCKET_NAME', 'ecommerce-images')
        self.public_url = app.config.get('R2_PUBLIC_URL')
        self.endpoint_url = app.config.get('R2_ENDPOINT_URL')
        
        # إعدادات الصور
        self.allowed_extensions = app.config.get('ALLOWED_IMAGE_EXTENSIONS', 
                                                  {'png', 'jpg', 'jpeg', 'gif', 'webp'})
        self.max_size = app.config.get('MAX_IMAGE_SIZE', 5 * 1024 * 1024)
        self.image_quality = app.config.get('IMAGE_QUALITY', 85)
        
        # إنشاء العميل
        self._create_client()
    
    def _create_client(self):
        """إنشاء عميل S3 لـ R2"""
        if not all([self.account_id, self.access_key, self.secret_key]):
            current_app.logger.warning('R2 credentials not configured')
            return
        
        self.client = boto3.client(
            's3',
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
            config=Config(
                signature_version='s3v4',
                retries={'max_attempts': 3}
            )
        )
    
    def _allowed_file(self, filename: str) -> bool:
        """التحقق من امتداد الملف"""
        if '.' not in filename:
            return False
        ext = filename.rsplit('.', 1)[1].lower()
        return ext in self.allowed_extensions
    
    def _generate_unique_filename(self, original_filename: str, folder: str = '') -> str:
        """توليد اسم ملف فريد"""
        ext = original_filename.rsplit('.', 1)[1].lower() if '.' in original_filename else 'jpg'
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        unique_id = uuid.uuid4().hex[:8]
        filename = f"{timestamp}_{unique_id}.{ext}"
        
        if folder:
            return f"{folder.strip('/')}/{filename}"
        return filename
    
    def _process_image(
        self,
        image_data: bytes,
        max_width: int = 1920,
        max_height: int = 1920,
        quality: int = None
    ) -> Tuple[bytes, int, int]:
        """
        معالجة الصورة (تغيير الحجم والضغط)
        
        Returns:
            Tuple[processed_data, width, height]
        """
        quality = quality or self.image_quality
        
        # فتح الصورة
        img = Image.open(BytesIO(image_data))
        
        # تحويل RGBA إلى RGB إذا لزم الأمر
        if img.mode in ('RGBA', 'LA', 'P'):
            background = Image.new('RGB', img.size, (255, 255, 255))
            if img.mode == 'P':
                img = img.convert('RGBA')
            background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
            img = background
        
        # تغيير الحجم إذا كانت الصورة كبيرة
        original_width, original_height = img.size
        
        if original_width > max_width or original_height > max_height:
            # حساب النسبة
            ratio = min(max_width / original_width, max_height / original_height)
            new_width = int(original_width * ratio)
            new_height = int(original_height * ratio)
            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        else:
            new_width, new_height = original_width, original_height
        
        # حفظ الصورة المعالجة
        output = BytesIO()
        img.save(output, format='JPEG', quality=quality, optimize=True)
        output.seek(0)
        
        return output.read(), new_width, new_height
    
    def _create_thumbnail(
        self,
        image_data: bytes,
        size: Tuple[int, int] = (300, 300)
    ) -> bytes:
        """إنشاء صورة مصغرة"""
        img = Image.open(BytesIO(image_data))
        
        # تحويل إلى RGB
        if img.mode in ('RGBA', 'LA', 'P'):
            background = Image.new('RGB', img.size, (255, 255, 255))
            if img.mode == 'P':
                img = img.convert('RGBA')
            background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
            img = background
        
        # إنشاء المصغرة (crop & resize)
        img.thumbnail(size, Image.Resampling.LANCZOS)
        
        output = BytesIO()
        img.save(output, format='JPEG', quality=80, optimize=True)
        output.seek(0)
        
        return output.read()
    
    def upload_file(
        self,
        file_data: bytes,
        filename: str,
        folder: str = 'uploads',
        content_type: str = 'image/jpeg',
        metadata: Optional[Dict] = None
    ) -> Optional[str]:
        """
        رفع ملف إلى R2
        
        Args:
            file_data: بيانات الملف
            filename: اسم الملف
            folder: المجلد
            content_type: نوع المحتوى
            metadata: بيانات وصفية
        
        Returns:
            رابط الملف أو None في حالة الفشل
        """
        if not self.client:
            current_app.logger.error('R2 client not initialized')
            return None
        
        try:
            key = self._generate_unique_filename(filename, folder)
            
            extra_args = {
                'ContentType': content_type,
                'CacheControl': 'max-age=31536000'  # 1 year cache
            }
            
            if metadata:
                extra_args['Metadata'] = metadata
            
            self.client.put_object(
                Bucket=self.bucket_name,
                Key=key,
                Body=file_data,
                **extra_args
            )
            
            # إرجاع الرابط العام
            url = f"{self.public_url}/{key}"
            current_app.logger.info(f'File uploaded: {url}')
            return url
            
        except ClientError as e:
            current_app.logger.error(f'R2 upload error: {e}')
            return None
    
    def upload_image(
        self,
        file,
        folder: str = 'products',
        create_thumbnail: bool = True,
        max_width: int = 1920,
        max_height: int = 1920
    ) -> Dict:
        """
        رفع صورة مع المعالجة
        
        Args:
            file: ملف الصورة (من request.files)
            folder: المجلد
            create_thumbnail: إنشاء صورة مصغرة
            max_width: أقصى عرض
            max_height: أقصى ارتفاع
        
        Returns:
            Dict with url, thumbnail_url, key, etc.
        """
        result = {
            'success': False,
            'url': None,
            'thumbnail_url': None,
            'key': None,
            'thumbnail_key': None,
            'width': None,
            'height': None,
            'file_size': None,
            'error': None
        }
        
        # التحقق من الملف
        if not file or not file.filename:
            result['error'] = 'لم يتم اختيار ملف'
            return result
        
        filename = secure_filename(file.filename)
        
        if not self._allowed_file(filename):
            result['error'] = 'نوع الملف غير مسموح'
            return result
        
        # قراءة البيانات
        file_data = file.read()
        
        if len(file_data) > self.max_size:
            result['error'] = f'حجم الملف يتجاوز {self.max_size // (1024*1024)}MB'
            return result
        
        try:
            # معالجة الصورة
            processed_data, width, height = self._process_image(
                file_data, max_width, max_height
            )
            
            # رفع الصورة الرئيسية
            key = self._generate_unique_filename(filename, folder)
            
            self.client.put_object(
                Bucket=self.bucket_name,
                Key=key,
                Body=processed_data,
                ContentType='image/jpeg',
                CacheControl='max-age=31536000'
            )
            
            result['url'] = f"{self.public_url}/{key}"
            result['key'] = key
            result['width'] = width
            result['height'] = height
            result['file_size'] = len(processed_data)
            
            # إنشاء ورفع المصغرة
            if create_thumbnail:
                thumbnail_data = self._create_thumbnail(processed_data)
                thumbnail_key = key.replace('.', '_thumb.')
                
                self.client.put_object(
                    Bucket=self.bucket_name,
                    Key=thumbnail_key,
                    Body=thumbnail_data,
                    ContentType='image/jpeg',
                    CacheControl='max-age=31536000'
                )
                
                result['thumbnail_url'] = f"{self.public_url}/{thumbnail_key}"
                result['thumbnail_key'] = thumbnail_key
            
            result['success'] = True
            current_app.logger.info(f'Image uploaded: {result["url"]}')
            
        except Exception as e:
            current_app.logger.error(f'Image upload error: {e}')
            result['error'] = 'فشل في رفع الصورة'
        
        return result
    
    def delete_file(self, key: str) -> bool:
        """حذف ملف من R2"""
        if not self.client or not key:
            return False
        
        try:
            # استخراج المفتاح من الرابط إذا لزم الأمر
            if key.startswith('http'):
                key = key.replace(f"{self.public_url}/", '')
            
            self.client.delete_object(
                Bucket=self.bucket_name,
                Key=key
            )
            
            current_app.logger.info(f'File deleted: {key}')
            return True
            
        except ClientError as e:
            current_app.logger.error(f'R2 delete error: {e}')
            return False
    
    def delete_files(self, keys: List[str]) -> int:
        """حذف عدة ملفات"""
        if not self.client or not keys:
            return 0
        
        try:
            # تحويل الروابط إلى مفاتيح
            objects = []
            for key in keys:
                if key.startswith('http'):
                    key = key.replace(f"{self.public_url}/", '')
                objects.append({'Key': key})
            
            response = self.client.delete_objects(
                Bucket=self.bucket_name,
                Delete={'Objects': objects}
            )
            
            deleted_count = len(response.get('Deleted', []))
            current_app.logger.info(f'Deleted {deleted_count} files')
            return deleted_count
            
        except ClientError as e:
            current_app.logger.error(f'R2 bulk delete error: {e}')
            return 0
    
    def get_file_url(self, key: str) -> str:
        """الحصول على رابط الملف"""
        if not key:
            return ''
        if key.startswith('http'):
            return key
        return f"{self.public_url}/{key}"
    
    def file_exists(self, key: str) -> bool:
        """التحقق من وجود الملف"""
        if not self.client or not key:
            return False
        
        try:
            self.client.head_object(Bucket=self.bucket_name, Key=key)
            return True
        except ClientError:
            return False
    
    def get_file_info(self, key: str) -> Optional[Dict]:
        """الحصول على معلومات الملف"""
        if not self.client or not key:
            return None
        
        try:
            response = self.client.head_object(
                Bucket=self.bucket_name,
                Key=key
            )
            
            return {
                'key': key,
                'size': response['ContentLength'],
                'content_type': response['ContentType'],
                'last_modified': response['LastModified'],
                'metadata': response.get('Metadata', {})
            }
            
        except ClientError:
            return None


# إنشاء instance
storage_service = StorageService()