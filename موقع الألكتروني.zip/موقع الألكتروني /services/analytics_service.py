"""
======================================
📊 Analytics Service
======================================
خدمة الإحصائيات والتقارير
"""

from datetime import datetime, timedelta
from typing import Dict, List, Optional
from sqlalchemy import func, desc, and_
from decimal import Decimal

from app.extensions import db
from app.models.order import Order, OrderItem
from app.models.product import Product
from app.models.user import User
from app.models.ticket import Ticket


class AnalyticsService:
    """خدمة الإحصائيات"""
    
    @staticmethod
    def get_dashboard_stats() -> Dict:
        """إحصائيات لوحة التحكم الرئيسية"""
        today = datetime.utcnow().date()
        yesterday = today - timedelta(days=1)
        week_ago = today - timedelta(days=7)
        month_ago = today - timedelta(days=30)
        
        # ==========================================
        # 📦 إحصائيات الطلبات
        # ==========================================
        
        # طلبات اليوم
        today_orders = Order.query.filter(
            func.date(Order.created_at) == today
        ).count()
        
        # طلبات الأمس
        yesterday_orders = Order.query.filter(
            func.date(Order.created_at) == yesterday
        ).count()
        
        # نسبة التغير
        orders_change = 0
        if yesterday_orders > 0:
            orders_change = ((today_orders - yesterday_orders) / yesterday_orders) * 100
        
        # الطلبات قيد المراجعة
        pending_orders = Order.query.filter_by(status='pending').count()
        
        # إجمالي الطلبات
        total_orders = Order.query.count()
        
        # ==========================================
        # 💰 إحصائيات الإيرادات
        # ==========================================
        
        # إيرادات اليوم
        today_revenue = db.session.query(
            func.sum(Order.total_amount)
        ).filter(
            func.date(Order.created_at) == today,
            Order.payment_status == 'paid'
        ).scalar() or 0
        
        # إيرادات الأمس
        yesterday_revenue = db.session.query(
            func.sum(Order.total_amount)
        ).filter(
            func.date(Order.created_at) == yesterday,
            Order.payment_status == 'paid'
        ).scalar() or 0
        
        # نسبة التغير
        revenue_change = 0
        if yesterday_revenue > 0:
            revenue_change = ((float(today_revenue) - float(yesterday_revenue)) / float(yesterday_revenue)) * 100
        
        # إيرادات الشهر
        month_revenue = db.session.query(
            func.sum(Order.total_amount)
        ).filter(
            func.date(Order.created_at) >= month_ago,
            Order.payment_status == 'paid'
        ).scalar() or 0
        
        # إجمالي الإيرادات
        total_revenue = db.session.query(
            func.sum(Order.total_amount)
        ).filter(
            Order.payment_status == 'paid'
        ).scalar() or 0
        
        # ==========================================
        # 👥 إحصائيات المستخدمين
        # ==========================================
        
        # مستخدمون جدد اليوم
        today_users = User.query.filter(
            func.date(User.created_at) == today
        ).count()
        
        # مستخدمون جدد الأسبوع
        week_users = User.query.filter(
            func.date(User.created_at) >= week_ago
        ).count()
        
        # إجمالي المستخدمين
        total_users = User.query.filter_by(is_admin=False).count()
        
        # المستخدمون النشطون (لديهم طلبات)
        active_users = db.session.query(
            func.count(func.distinct(Order.user_id))
        ).filter(
            func.date(Order.created_at) >= month_ago
        ).scalar() or 0
        
        # ==========================================
        # 📦 إحصائيات المنتجات
        # ==========================================
        
        # إجمالي المنتجات
        total_products = Product.query.filter_by(is_active=True).count()
        
        # منتجات نفدت من المخزون
        out_of_stock = Product.query.filter(
            Product.is_active == True,
            Product.stock_quantity <= 0,
            Product.track_inventory == True
        ).count()
        
        # منتجات منخفضة المخزون
        low_stock = Product.query.filter(
            Product.is_active == True,
            Product.stock_quantity > 0,
            Product.stock_quantity <= Product.low_stock_threshold,
            Product.track_inventory == True
        ).count()
        
        # ==========================================
        # 🎫 إحصائيات الدعم
        # ==========================================
        
        # تذاكر مفتوحة
        open_tickets = Ticket.query.filter(
            Ticket.status.in_(['open', 'in_progress', 'waiting_customer'])
        ).count()
        
        # تذاكر اليوم
        today_tickets = Ticket.query.filter(
            func.date(Ticket.created_at) == today
        ).count()
        
        return {
            'orders': {
                'today': today_orders,
                'yesterday': yesterday_orders,
                'change': round(orders_change, 1),
                'pending': pending_orders,
                'total': total_orders
            },
            'revenue': {
                'today': float(today_revenue),
                'yesterday': float(yesterday_revenue),
                'change': round(revenue_change, 1),
                'month': float(month_revenue),
                'total': float(total_revenue)
            },
            'users': {
                'today': today_users,
                'week': week_users,
                'active': active_users,
                'total': total_users
            },
            'products': {
                'total': total_products,
                'out_of_stock': out_of_stock,
                'low_stock': low_stock
            },
            'support': {
                'open_tickets': open_tickets,
                'today_tickets': today_tickets
            }
        }
    
    @staticmethod
    def get_revenue_chart(days: int = 30) -> Dict:
        """بيانات مخطط الإيرادات"""
        end_date = datetime.utcnow().date()
        start_date = end_date - timedelta(days=days)
        
        # استعلام الإيرادات اليومية
        daily_revenue = db.session.query(
            func.date(Order.created_at).label('date'),
            func.sum(Order.total_amount).label('revenue'),
            func.count(Order.id).label('orders')
        ).filter(
            func.date(Order.created_at) >= start_date,
            Order.payment_status == 'paid'
        ).group_by(
            func.date(Order.created_at)
        ).all()
        
        # تحويل إلى قاموس
        revenue_dict = {str(r.date): {'revenue': float(r.revenue), 'orders': r.orders} 
                        for r in daily_revenue}
        
        # ملء الأيام الفارغة
        labels = []
        revenue_data = []
        orders_data = []
        
        current_date = start_date
        while current_date <= end_date:
            date_str = str(current_date)
            labels.append(current_date.strftime('%m/%d'))
            
            if date_str in revenue_dict:
                revenue_data.append(revenue_dict[date_str]['revenue'])
                orders_data.append(revenue_dict[date_str]['orders'])
            else:
                revenue_data.append(0)
                orders_data.append(0)
            
            current_date += timedelta(days=1)
        
        return {
            'labels': labels,
            'revenue': revenue_data,
            'orders': orders_data
        }
    
    @staticmethod
    def get_top_products(limit: int = 10, days: int = 30) -> List[Dict]:
        """أفضل المنتجات مبيعاً"""
        start_date = datetime.utcnow() - timedelta(days=days)
        
        top_products = db.session.query(
            Product.id,
            Product.name,
            Product.main_image_url,
            func.sum(OrderItem.quantity).label('total_sold'),
            func.sum(OrderItem.total_price).label('total_revenue')
        ).join(
            OrderItem, OrderItem.product_id == Product.id
        ).join(
            Order, Order.id == OrderItem.order_id
        ).filter(
            Order.created_at >= start_date,
            Order.status.notin_(['cancelled', 'refunded'])
        ).group_by(
            Product.id
        ).order_by(
            desc('total_sold')
        ).limit(limit).all()
        
        return [{
            'id': p.id,
            'name': p.name,
            'image_url': p.main_image_url,
            'total_sold': p.total_sold,
            'total_revenue': float(p.total_revenue)
        } for p in top_products]
    
    @staticmethod
    def get_orders_by_status() -> Dict:
        """توزيع الطلبات حسب الحالة"""
        statuses = db.session.query(
            Order.status,
            func.count(Order.id).label('count')
        ).group_by(Order.status).all()
        
        return {s.status: s.count for s in statuses}
    
    @staticmethod
    def get_recent_orders(limit: int = 10) -> List[Dict]:
        """أحدث الطلبات"""
        orders = Order.query.order_by(
            Order.created_at.desc()
        ).limit(limit).all()
        
        return [order.to_dict() for order in orders]
    
    @staticmethod
    def get_top_customers(limit: int = 10) -> List[Dict]:
        """أفضل العملاء"""
        customers = db.session.query(
            User.id,
            User.first_name,
            User.last_name,
            User.email,
            User.total_orders,
            User.total_spent
        ).filter(
            User.is_admin == False
        ).order_by(
            desc(User.total_spent)
        ).limit(limit).all()
        
        return [{
            'id': c.id,
            'name': f'{c.first_name} {c.last_name}',
            'email': c.email,
            'total_orders': c.total_orders,
            'total_spent': float(c.total_spent)
        } for c in customers]
    
    @staticmethod
    def get_category_sales(days: int = 30) -> List[Dict]:
        """مبيعات حسب الفئة"""
        from app.models.category import Category
        
        start_date = datetime.utcnow() - timedelta(days=days)
        
        sales = db.session.query(
            Category.id,
            Category.name,
            func.sum(OrderItem.quantity).label('total_sold'),
            func.sum(OrderItem.total_price).label('total_revenue')
        ).join(
            Product, Product.category_id == Category.id
        ).join(
            OrderItem, OrderItem.product_id == Product.id
        ).join(
            Order, Order.id == OrderItem.order_id
        ).filter(
            Order.created_at >= start_date,
            Order.status.notin_(['cancelled', 'refunded'])
        ).group_by(
            Category.id
        ).order_by(
            desc('total_revenue')
        ).all()
        
        return [{
            'id': s.id,
            'name': s.name,
            'total_sold': s.total_sold,
            'total_revenue': float(s.total_revenue)
        } for s in sales]


# إنشاء instance
analytics_service = AnalyticsService()