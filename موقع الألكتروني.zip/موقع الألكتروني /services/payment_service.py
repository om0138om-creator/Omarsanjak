"""
======================================
💳 Payment Service (Chargily Pay)
======================================
خدمة الدفع عبر بوابة Chargily
"""

import requests
import hmac
import hashlib
import json
from typing import Optional, Dict, Tuple
from datetime import datetime
from decimal import Decimal

from flask import current_app, url_for, request


class ChargilyPayment:
    """خدمة الدفع Chargily Pay"""
    
    API_URL = 'https://pay.chargily.net/api/v2'
    
    def __init__(self, app=None):
        self.app = app
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """تهيئة الخدمة"""
        self.app = app
        self.api_key = app.config.get('CHARGILY_API_KEY')
        self.secret_key = app.config.get('CHARGILY_SECRET_KEY')
        self.mode = app.config.get('CHARGILY_MODE', 'test')
    
    def _get_headers(self) -> Dict:
        """الحصول على headers الطلب"""
        return {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict] = None
    ) -> Tuple[bool, Dict]:
        """
        إرسال طلب للـ API
        
        Returns:
            Tuple[success, response_data]
        """
        url = f"{self.API_URL}/{endpoint}"
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=self._get_headers(), timeout=30)
            elif method == 'POST':
                response = requests.post(
                    url,
                    headers=self._get_headers(),
                    json=data,
                    timeout=30
                )
            else:
                return False, {'error': 'Invalid method'}
            
            response_data = response.json()
            
            if response.status_code in [200, 201]:
                return True, response_data
            else:
                current_app.logger.error(f'Chargily API error: {response_data}')
                return False, response_data
                
        except requests.exceptions.RequestException as e:
            current_app.logger.error(f'Chargily request error: {e}')
            return False, {'error': str(e)}
    
    def create_checkout(
        self,
        order,
        success_url: Optional[str] = None,
        failure_url: Optional[str] = None,
        webhook_url: Optional[str] = None
    ) -> Tuple[bool, Dict]:
        """
        إنشاء جلسة دفع جديدة
        
        Args:
            order: كائن الطلب
            success_url: رابط النجاح
            failure_url: رابط الفشل
            webhook_url: رابط الـ webhook
        
        Returns:
            Tuple[success, checkout_data]
        """
        # إعداد الروابط
        if not success_url:
            success_url = url_for(
                'payment.success',
                order_number=order.order_number,
                _external=True
            )
        
        if not failure_url:
            failure_url = url_for(
                'payment.failure',
                order_number=order.order_number,
                _external=True
            )
        
        if not webhook_url:
            webhook_url = url_for('payment.webhook', _external=True)
        
        # بيانات الدفع
        data = {
            'amount': int(float(order.total_amount)),  # Chargily يتطلب integer
            'currency': 'dzd',
            'payment_method': 'edahabia',  # edahabia, cib
            'success_url': success_url,
            'failure_url': failure_url,
            'webhook_endpoint': webhook_url,
            'description': f'طلب رقم {order.order_number}',
            'locale': 'ar',
            'metadata': {
                'order_id': order.id,
                'order_number': order.order_number,
                'user_id': order.user_id,
                'user_email': order.user.email
            },
            'customer': {
                'name': order.shipping_name,
                'email': order.user.email,
                'phone': order.shipping_phone,
                'address': {
                    'address': order.shipping_street,
                    'city': order.shipping_city,
                    'state': order.shipping_state,
                    'country': 'DZ'
                }
            }
        }
        
        success, response = self._make_request('POST', 'checkouts', data)
        
        if success:
            # حفظ معرف الجلسة في الطلب
            order.chargily_checkout_id = response.get('id')
            order.payment_gateway = 'chargily'
            
            current_app.logger.info(
                f'Chargily checkout created: {response.get("id")} for order {order.order_number}'
            )
            
            return True, {
                'checkout_id': response.get('id'),
                'checkout_url': response.get('checkout_url'),
                'status': response.get('status')
            }
        else:
            return False, response
    
    def get_checkout(self, checkout_id: str) -> Tuple[bool, Dict]:
        """الحصول على تفاصيل جلسة الدفع"""
        return self._make_request('GET', f'checkouts/{checkout_id}')
    
    def verify_webhook_signature(self, payload: bytes, signature: str) -> bool:
        """
        التحقق من صحة توقيع Webhook
        
        Args:
            payload: بيانات الطلب الخام
            signature: التوقيع من الـ header
        
        Returns:
            bool: صحة التوقيع
        """
        if not signature or not self.secret_key:
            return False
        
        expected_signature = hmac.new(
            self.secret_key.encode('utf-8'),
            payload,
            hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(expected_signature, signature)
    
    def process_webhook(self, payload: Dict) -> Tuple[bool, str]:
        """
        معالجة Webhook من Chargily
        
        Args:
            payload: بيانات الـ webhook
        
        Returns:
            Tuple[success, message]
        """
        from app.models.order import Order
        from app.models.notification import Notification
        from app.extensions import db
        
        event_type = payload.get('type')
        checkout_data = payload.get('data', {})
        
        checkout_id = checkout_data.get('id')
        status = checkout_data.get('status')
        metadata = checkout_data.get('metadata', {})
        
        order_id = metadata.get('order_id')
        
        if not order_id:
            return False, 'Order ID not found in metadata'
        
        order = Order.query.get(order_id)
        if not order:
            return False, f'Order not found: {order_id}'
        
        # التحقق من تطابق checkout_id
        if order.chargily_checkout_id != checkout_id:
            return False, 'Checkout ID mismatch'
        
        # معالجة حسب نوع الحدث
        if event_type == 'checkout.paid':
            # تم الدفع بنجاح
            order.mark_as_paid(
                payment_id=checkout_data.get('invoice_id'),
                payment_details={
                    'checkout_id': checkout_id,
                    'payment_method': checkout_data.get('payment_method'),
                    'paid_at': checkout_data.get('paid_at'),
                    'amount': checkout_data.get('amount'),
                    'fee': checkout_data.get('fee')
                }
            )
            
            # خصم المخزون
            order.deduct_stock()
            
            # إرسال إشعار
            Notification.create_payment_notification(
                order.user_id, order, is_success=True
            )
            
            db.session.commit()
            
            # إرسال بريد إلكتروني
            from app.services.email_service import email_service
            email_service.send_payment_success(order)
            
            current_app.logger.info(f'Payment successful for order {order.order_number}')
            return True, 'Payment processed successfully'
        
        elif event_type == 'checkout.failed':
            # فشل الدفع
            order.mark_payment_failed({
                'checkout_id': checkout_id,
                'failure_reason': checkout_data.get('failure_reason'),
                'failed_at': datetime.utcnow().isoformat()
            })
            
            # إرسال إشعار
            Notification.create_payment_notification(
                order.user_id, order, is_success=False
            )
            
            db.session.commit()
            
            current_app.logger.warning(f'Payment failed for order {order.order_number}')
            return True, 'Payment failure recorded'
        
        elif event_type == 'checkout.expired':
            # انتهت صلاحية الجلسة
            if order.payment_status == 'payment_pending':
                order.payment_status = 'failed'
                db.session.commit()
            
            return True, 'Checkout expired'
        
        else:
            current_app.logger.info(f'Unhandled webhook event: {event_type}')
            return True, f'Event {event_type} acknowledged'
    
    def create_payment_link(
        self,
        amount: float,
        name: str,
        description: str = '',
        is_active: bool = True
    ) -> Tuple[bool, Dict]:
        """
        إنشاء رابط دفع قابل لإعادة الاستخدام
        
        Args:
            amount: المبلغ
            name: اسم المنتج/الخدمة
            description: الوصف
            is_active: نشط أم لا
        
        Returns:
            Tuple[success, link_data]
        """
        data = {
            'amount': int(amount),
            'currency': 'dzd',
            'name': name,
            'description': description,
            'is_active': is_active,
            'pass_fees_to_customer': False
        }
        
        return self._make_request('POST', 'payment-links', data)
    
    def get_balance(self) -> Tuple[bool, Dict]:
        """الحصول على رصيد الحساب"""
        return self._make_request('GET', 'balance')
    
    def refund_payment(
        self,
        payment_id: str,
        amount: Optional[float] = None
    ) -> Tuple[bool, Dict]:
        """
        استرداد دفعة
        
        Args:
            payment_id: معرف الدفعة
            amount: المبلغ (اختياري، للاسترداد الجزئي)
        """
        data = {'payment_id': payment_id}
        if amount:
            data['amount'] = int(amount)
        
        return self._make_request('POST', 'refunds', data)


# إنشاء instance
chargily_payment = ChargilyPayment()