"""
======================================
📧 Email Service
======================================
خدمة إرسال البريد الإلكتروني عبر Gmail SMTP
"""

import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from typing import List, Optional, Dict
from datetime import datetime
import os

from flask import current_app, render_template, url_for
from threading import Thread


class EmailService:
    """خدمة البريد الإلكتروني"""
    
    def __init__(self, app=None):
        self.app = app
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """تهيئة الخدمة مع التطبيق"""
        self.app = app
        self.server = app.config.get('MAIL_SERVER', 'smtp.gmail.com')
        self.port = app.config.get('MAIL_PORT', 587)
        self.use_tls = app.config.get('MAIL_USE_TLS', True)
        self.username = app.config.get('MAIL_USERNAME')
        self.password = app.config.get('MAIL_PASSWORD')
        self.default_sender = app.config.get('MAIL_DEFAULT_SENDER')
    
    def _get_smtp_connection(self):
        """إنشاء اتصال SMTP"""
        context = ssl.create_default_context()
        
        if self.use_tls:
            server = smtplib.SMTP(self.server, self.port)
            server.starttls(context=context)
        else:
            server = smtplib.SMTP_SSL(self.server, self.port, context=context)
        
        server.login(self.username, self.password)
        return server
    
    def send_email(
        self,
        to: str | List[str],
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
        sender: Optional[str] = None,
        cc: Optional[List[str]] = None,
        bcc: Optional[List[str]] = None,
        attachments: Optional[List[Dict]] = None,
        async_send: bool = True
    ) -> bool:
        """
        إرسال بريد إلكتروني
        
        Args:
            to: المستلم أو قائمة المستلمين
            subject: عنوان الرسالة
            html_body: محتوى HTML
            text_body: محتوى نصي (اختياري)
            sender: المرسل (اختياري)
            cc: نسخة كربونية
            bcc: نسخة كربونية مخفية
            attachments: قائمة المرفقات
            async_send: إرسال في الخلفية
        
        Returns:
            bool: نجاح الإرسال
        """
        if async_send:
            thread = Thread(
                target=self._send_email_async,
                args=(to, subject, html_body, text_body, sender, cc, bcc, attachments)
            )
            thread.start()
            return True
        else:
            return self._send_email_sync(
                to, subject, html_body, text_body, sender, cc, bcc, attachments
            )
    
    def _send_email_async(self, *args):
        """إرسال في الخلفية"""
        with self.app.app_context():
            self._send_email_sync(*args)
    
    def _send_email_sync(
        self,
        to: str | List[str],
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
        sender: Optional[str] = None,
        cc: Optional[List[str]] = None,
        bcc: Optional[List[str]] = None,
        attachments: Optional[List[Dict]] = None
    ) -> bool:
        """إرسال متزامن"""
        try:
            # إنشاء الرسالة
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = sender or self.default_sender
            msg['To'] = to if isinstance(to, str) else ', '.join(to)
            
            if cc:
                msg['Cc'] = ', '.join(cc)
            
            # إضافة المحتوى النصي
            if text_body:
                msg.attach(MIMEText(text_body, 'plain', 'utf-8'))
            
            # إضافة محتوى HTML
            msg.attach(MIMEText(html_body, 'html', 'utf-8'))
            
            # إضافة المرفقات
            if attachments:
                for attachment in attachments:
                    part = MIMEBase('application', 'octet-stream')
                    part.set_payload(attachment['data'])
                    encoders.encode_base64(part)
                    part.add_header(
                        'Content-Disposition',
                        f'attachment; filename={attachment["filename"]}'
                    )
                    msg.attach(part)
            
            # تجميع قائمة المستلمين
            recipients = [to] if isinstance(to, str) else to
            if cc:
                recipients.extend(cc)
            if bcc:
                recipients.extend(bcc)
            
            # إرسال
            server = self._get_smtp_connection()
            server.sendmail(self.default_sender, recipients, msg.as_string())
            server.quit()
            
            current_app.logger.info(f'Email sent to {to}: {subject}')
            return True
            
        except Exception as e:
            current_app.logger.error(f'Failed to send email: {e}')
            return False
    
    # ==========================================
    # 📨 قوالب البريد الجاهزة
    # ==========================================
    
    def send_verification_email(self, user) -> bool:
        """إرسال رابط تأكيد البريد الإلكتروني"""
        token = user.generate_email_token()
        verify_url = url_for('auth.verify_email', token=token, _external=True)
        
        html_body = render_template(
            'emails/verify_email.html',
            user=user,
            verify_url=verify_url,
            expiry_hours=24
        )
        
        return self.send_email(
            to=user.email,
            subject='تأكيد البريد الإلكتروني - ' + current_app.config['STORE_NAME'],
            html_body=html_body
        )
    
    def send_password_reset_email(self, user) -> bool:
        """إرسال رابط إعادة تعيين كلمة المرور"""
        token = user.generate_reset_token()
        reset_url = url_for('auth.reset_password', token=token, _external=True)
        
        html_body = render_template(
            'emails/reset_password.html',
            user=user,
            reset_url=reset_url,
            expiry_hours=1
        )
        
        return self.send_email(
            to=user.email,
            subject='إعادة تعيين كلمة المرور - ' + current_app.config['STORE_NAME'],
            html_body=html_body
        )
    
    def send_welcome_email(self, user) -> bool:
        """إرسال رسالة ترحيب"""
        html_body = render_template(
            'emails/welcome.html',
            user=user,
            store_name=current_app.config['STORE_NAME']
        )
        
        return self.send_email(
            to=user.email,
            subject='مرحباً بك في ' + current_app.config['STORE_NAME'],
            html_body=html_body
        )
    
    def send_order_confirmation(self, order) -> bool:
        """إرسال تأكيد الطلب"""
        html_body = render_template(
            'emails/order_confirmation.html',
            order=order,
            user=order.user,
            items=order.items.all()
        )
        
        return self.send_email(
            to=order.user.email,
            subject=f'تأكيد الطلب #{order.order_number}',
            html_body=html_body
        )
    
    def send_order_shipped(self, order) -> bool:
        """إرسال إشعار الشحن"""
        html_body = render_template(
            'emails/order_shipped.html',
            order=order,
            user=order.user,
            tracking_number=order.tracking_number
        )
        
        return self.send_email(
            to=order.user.email,
            subject=f'طلبك #{order.order_number} في الطريق إليك',
            html_body=html_body
        )
    
    def send_order_delivered(self, order) -> bool:
        """إرسال إشعار التسليم"""
        html_body = render_template(
            'emails/order_delivered.html',
            order=order,
            user=order.user
        )
        
        return self.send_email(
            to=order.user.email,
            subject=f'تم تسليم طلبك #{order.order_number}',
            html_body=html_body
        )
    
    def send_order_cancelled(self, order) -> bool:
        """إرسال إشعار الإلغاء"""
        html_body = render_template(
            'emails/order_cancelled.html',
            order=order,
            user=order.user,
            reason=order.cancellation_reason
        )
        
        return self.send_email(
            to=order.user.email,
            subject=f'تم إلغاء طلبك #{order.order_number}',
            html_body=html_body
        )
    
    def send_payment_success(self, order) -> bool:
        """إرسال تأكيد الدفع"""
        html_body = render_template(
            'emails/payment_success.html',
            order=order,
            user=order.user
        )
        
        return self.send_email(
            to=order.user.email,
            subject=f'تم استلام دفعتك للطلب #{order.order_number}',
            html_body=html_body
        )
    
    def send_ticket_reply(self, ticket, message) -> bool:
        """إرسال إشعار رد على التذكرة"""
        html_body = render_template(
            'emails/ticket_reply.html',
            ticket=ticket,
            message=message,
            user=ticket.user
        )
        
        return self.send_email(
            to=ticket.user.email,
            subject=f'رد جديد على تذكرتك #{ticket.ticket_number}',
            html_body=html_body
        )
    
    def send_admin_new_order(self, order) -> bool:
        """إشعار المشرف بطلب جديد"""
        admin_email = current_app.config['ADMIN_EMAIL']
        
        html_body = render_template(
            'emails/admin_new_order.html',
            order=order,
            admin_url=url_for('admin.order_detail', order_id=order.id, _external=True)
        )
        
        return self.send_email(
            to=admin_email,
            subject=f'🛒 طلب جديد #{order.order_number}',
            html_body=html_body
        )
    
    def send_admin_new_ticket(self, ticket) -> bool:
        """إشعار المشرف بتذكرة جديدة"""
        admin_email = current_app.config['ADMIN_EMAIL']
        
        html_body = render_template(
            'emails/admin_new_ticket.html',
            ticket=ticket,
            admin_url=url_for('admin.ticket_detail', ticket_id=ticket.id, _external=True)
        )
        
        return self.send_email(
            to=admin_email,
            subject=f'🎫 تذكرة دعم جديدة #{ticket.ticket_number}',
            html_body=html_body
        )


# إنشاء instance
email_service = EmailService()